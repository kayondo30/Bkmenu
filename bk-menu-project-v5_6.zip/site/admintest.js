/* BK menu v5.6, batch D: the admin test sitting (F80) inside the staff screen: More > Admin test.
   Part 1 runs by itself and only READS (it never saves, never tries a PIN, so it cannot lock anyone out).
   Part 2 is a short tick list of the things only a person can check; ticks are kept on this phone.
   Part 3 tests the shake on this phone. "Copy the result" puts the report on the clipboard so it can be sent. */
(function(){
const KEY='bk_test_ticks',VER='5.6';
const MANUAL=[
 ['login','Log in with each staff account (both emails) and unlock with the PIN'],
 ['adddrink','Add a test drink: type "Test Latte", see Coffee and Espresso & Milk Coffees picked for you, set Show on the menu now OFF, add it, then delete it'],
 ['addfood','Add a test food: type "Test Burger", see a Food page picked, Show on the menu now OFF, add it, then delete it'],
 ['price','Change one price, save, look at the guest menu, change it back'],
 ['sold','Mark one drink Sold out today, see the badge on the guest menu, switch it off again'],
 ['notice','Save a notice, see it on the guest menu, remove it'],
 ['special','Make a special, see it in the carousel, then untick Show to guests'],
 ['preview','More > See the celebrations > Eritrea Independence Day: the card says Shake your phone to celebrate with us'],
 ['shake','On that preview, shake the phone: confetti and the full decoration appear (or tap Tap to celebrate)'],
 ['offline','Switch on flight mode and open the menu: it still opens'],
 ['lock','Leave the staff screen 5 minutes: it locks and asks for the PIN']
];
const read=()=>{try{return JSON.parse(localStorage.getItem(KEY)||'{}')}catch(e){return{}}};
const write=o=>{try{localStorage.setItem(KEY,JSON.stringify(o))}catch(e){}};
const P=(id,t,d)=>({id,ok:'pass',t,d:d||''}),W=(id,t,d)=>({id,ok:'warn',t,d:d||''}),F=(id,t,d)=>({id,ok:'fail',t,d:d||''});
const loadScript=src=>new Promise(res=>{if(document.querySelector('script[src="'+src+'"]'))return res(true);const s=document.createElement('script');s.src=src;s.onload=()=>res(true);s.onerror=()=>res(false);document.head.appendChild(s)});
/* the automatic part. ctx = {B (config), D (loaded data), em (signed in email), api (GET helper)} */
async function checks(ctx){const R=[],B=ctx.B||{},D=ctx.D||{};
 /* 1. configuration and connection */
 R.push(B.url&&B.key?P('cfg','Company settings (config.js) found'):F('cfg','Company settings missing','url or key is empty in config.js'));
 R.push(B.key&&/^eyJ|^sb_publishable_/.test(B.key)?P('key','The key is a publishable key'):W('key','The key looks unusual','It should start with sb_publishable_ or eyJ. Never use the secret key.'));
 try{const t0=Date.now(),r=await ctx.api('/rest/v1/settings?select=key&limit=1');R.push(Array.isArray(r)?P('net','Connected to the database','answered in '+(Date.now()-t0)+' ms'):F('net','The database did not answer properly',String((r&&r.message)||'')));}catch(e){R.push(F('net','No connection to the database','Check the internet and try again'))}
 /* 2. data */
 R.push(D.it&&D.it.length?P('menu',D.it.length+' menu items loaded'):F('menu','No menu items loaded','Run v2.sql, or the menu table is empty'));
 if(D.it&&D.it.length){const pages=[...new Set(D.it.map(i=>i.grp))],hid=D.it.filter(i=>i.hidden).length,so=D.it.filter(i=>i.sold_out).length;
  R.push(P('pages',pages.length+' pages: '+pages.join(', '),hid+' hidden, '+so+' sold out'));
  const noPrice=D.it.filter(i=>!String(i.price||'').trim()&&!String(i.note||'').trim()).length;/* an item with no price of its own is fine when its section note carries the price ("Every milkshake · UGX 14,000") */R.push(noPrice?W('price',noPrice+' items have no price','They show without a price on the menu'):P('price','Every item has a price'));
  const dup=new Set();let d2=0;D.it.forEach(i=>{const k=(i.grp+'|'+i.sec+'|'+i.name+'|'+(i.variant||'')).toLowerCase();if(dup.has(k))d2++;dup.add(k)});R.push(d2?W('dup',d2+' items appear twice with the same name and size','Check the staff list, delete the extra one'):P('dup','No item is repeated by mistake'))}
 R.push(D.sp?P('sp','Specials table is ready ('+D.sp.length+' saved)'):W('sp','Specials table not set up','Run v3.sql'));
 R.push(D.se?P('se','Seasons table is ready ('+D.se.length+' saved)'):W('se','Seasons table not set up','Run v3.5.sql'));
 const me=(D.sf||[]).find(s=>s.email&&ctx.em&&s.email.toLowerCase()===ctx.em.toLowerCase());
 R.push(ctx.em?P('who','Signed in as '+ctx.em):F('who','Not signed in'));
 R.push(D.sf&&D.sf.length?P('staff',D.sf.length+' staff accounts: '+D.sf.map(s=>s.email+(s.pin_set?'':' (no PIN)')).join(', ')):W('staff','Staff list not available','Run v3.1.sql and v3.5.sql'));
 if(me)R.push(me.pin_set?(me.locked?W('pin','Your PIN is locked for now','3 wrong tries lock it for 15 minutes'):P('pin','Your PIN is set')):W('pin','Your PIN is not set yet','More > Set or change PIN'));
 /* 3. the new things in this version */
 if(window.BKDET){const T=[['Test Latte','drink','Coffee'],['Smirnoff Ice','drink','Spirits'],['Passion Mojito','drink','Cocktails'],['Test Burger','food',null],['Coffee Cake','food',null]];let bad=[];
  T.forEach(t=>{const r=BKDET.detect(t[0],D.it||[],'');if(r.type!==t[1]||(t[2]&&r.grp!==t[2]))bad.push(t[0]+' gave '+(r.type||'nothing')+' / '+(r.grp||'-'))});
  R.push(bad.length?F('det','Drink or food detection gave unexpected answers',bad.join('; ')):P('det','Drink or food detection works','5 sample names gave the expected kind and page'))}
 else R.push(F('det','detect.js did not load','Upload the site files again'));
 if(window.BKS){let n=0;const keep=BKS.state;BKS.on(()=>{n++});BKS.fake(3);BKS.on(null);BKS.reset();R.push(n===1?P('shk','Shake detection works','3 strong movements counted as 1 shake'):F('shk','Shake detection did not trigger','Counted '+n));
  R.push(BKS.supported?(BKS.needsTap?P('sens','This phone has a motion sensor (it asks permission on a tap)'):P('sens','This phone has a motion sensor')):W('sens','No motion sensor here','On this device guests use the Tap to celebrate button'))}
 else R.push(F('shk','shake.js did not load','Upload the site files again'));
 /* 4. celebrations: the calendar and the cards */
 const ok=await loadScript('deco.js');
 if(ok&&window.BKD){const k=BKD.keys,miss=k.filter(x=>!BKD.G[x]||!BKD.ART[x]||!BKD.NAME[x]);R.push(miss.length?F('cel','A celebration is missing its card or drawing',miss.join(', ')):P('cel',k.length+' celebrations have a greeting, a drawing and a name'));
  const now=new Date(),y=now.getFullYear(),ev=BKD.events(y).filter(e=>BKD.allowed(e.k));R.push(ev.length?P('cal',ev.length+' celebrations are on the calendar for '+y):W('cal','No celebration for '+y+' with these company settings'));
  const eid=BKD.events(y).filter(e=>e.k=='fitr'||e.k=='adha').length;if(!eid)R.push(W('eid','The Eid dates for '+y+' are not in the table','Extend the EID table in deco.js'));
  const g=BKD.geez(now);R.push(P('geez',"Today in the Eritrean calendar: "+g.en));
  const p=BKD.pick(now);R.push(P('today',p?('Today: '+BKD.NAME[p.k]+' ('+(p.lv=='day'?'the day: shake to celebrate':'the season: light garland')+')'):'No celebration today'));
  const noTi=BKD.keys.filter(x=>!BKD.G[x][1]);if(noTi.length)R.push(W('ti','No Tigrinya greeting yet for: '+noTi.map(x=>BKD.NAME[x]).join(', '),'Ask the owner for the words; they show in English until then'))}
 else R.push(F('cel','deco.js did not load'));
 /* 5. offline and storage */
 try{localStorage.setItem('bk_probe','1');localStorage.removeItem('bk_probe');R.push(P('ls','This phone can save settings'))}catch(e){R.push(W('ls','This phone blocks saving settings','Private mode? The PIN and theme will not be remembered'))}
 if('serviceWorker' in navigator){try{const reg=await navigator.serviceWorker.getRegistration('./');const ks=window.caches?await caches.keys():[];const cur=ks.find(k=>k==='bk-menu-v'+VER);
   R.push(reg?(cur?P('sw','Offline copy is current (bk-menu-v'+VER+')'):W('sw','Offline copy is an older version','Open the menu once with internet; it updates itself. Found: '+(ks.join(', ')||'none'))):W('sw','The menu is not saved for offline yet','Open the guest menu once with internet'))}catch(e){R.push(W('sw','Could not check the offline copy'))}}
 else R.push(W('sw','This browser cannot save the menu for offline'));
 R.push(navigator.onLine===false?W('on','You are offline now','Saving needs internet'):P('on','Online'));
 return R}
const icon={pass:'✓',warn:'!',fail:'✕'};
function report(R,ticks){const p=R.filter(x=>x.ok=='pass').length,w=R.filter(x=>x.ok=='warn').length,f=R.filter(x=>x.ok=='fail').length,d=MANUAL.filter(m=>ticks[m[0]]).length;
 return'BK admin test, version '+VER+', '+new Date().toLocaleString()+'\n'+p+' passed, '+w+' to look at, '+f+' failed. Checklist '+d+' of '+MANUAL.length+' done.\n'+R.map(x=>icon[x.ok]+' '+x.t+(x.d?' ('+x.d+')':'')).join('\n')+'\n\nChecklist:\n'+MANUAL.map(m=>(ticks[m[0]]?'[x] ':'[ ] ')+m[1]).join('\n')}
/* the sheet. ctx adds: sheet(html), $, esc, say */
async function open(ctx){const {sheet,$,esc,say}=ctx;let ticks=read();
 sheet('<h3>Admin test</h3><p class="nt">Part 1 checks the app by itself and only reads: nothing is saved. Please wait a moment.</p><div id="atr"></div>');
 const R=await checks(ctx);
 const draw=()=>{const p=R.filter(x=>x.ok=='pass').length,w=R.filter(x=>x.ok=='warn').length,f=R.filter(x=>x.ok=='fail').length,d=MANUAL.filter(m=>ticks[m[0]]).length;
  $('#shc').innerHTML=`<h3>Admin test</h3><p class="nt"><b>${p} passed</b>${w?` · ${w} to look at`:''}${f?` · <span style="color:var(--bad)">${f} failed</span>`:''}. Checklist ${d} of ${MANUAL.length}.</p>
<h2>Part 1: the app checks itself</h2>${R.map(x=>`<div class="row"><span><b style="color:${x.ok=='pass'?'var(--ok)':x.ok=='warn'?'var(--ac)':'var(--bad)'}">${icon[x.ok]}</b> ${esc(x.t)}${x.d?`<small style="display:block">${esc(x.d)}</small>`:''}</span></div>`).join('')}
<h2>Part 2: please check these yourself</h2><p class="nt">Tap to tick. Ticks stay on this phone.</p>${MANUAL.map(m=>`<label class="sw"><span>${esc(m[1])}</span><input type="checkbox" data-t="${m[0]}" ${ticks[m[0]]?'checked':''}></label>`).join('')}
<h2>Part 3: test the shake on this phone</h2><p class="nt" id="atsk">Tap the button, then shake the phone.</p><button class="btn gh" id="atsb" type="button">Start the shake test</button>
<div class="acts"><button class="btn" id="atcp">Copy the result</button><button class="btn gh" id="atrs">Clear ticks</button><button class="btn gh" data-x>Close</button></div>`;
  $('#shc').querySelectorAll('input[data-t]').forEach(i=>i.onchange=()=>{ticks[i.dataset.t]=i.checked;write(ticks);draw2()});
  $('#atrs').onclick=()=>{ticks={};write(ticks);draw()};
  $('#atcp').onclick=async()=>{const t=report(R,ticks);try{await navigator.clipboard.writeText(t);say('Copied. You can paste it in a message')}catch(e){say('Could not copy on this phone')}};
  $('#atsb').onclick=async()=>{const t=$('#atsk');if(!window.BKS||!BKS.supported){t.textContent='This phone has no motion sensor here. Guests will use the Tap to celebrate button.';return}
   const ok=await BKS.arm();if(!ok){t.textContent='The phone did not allow motion. On iPhone tap Allow when asked, or check Settings > Safari > Motion & Orientation Access.';return}
   let n=0;BKS.on(()=>{n++;t.textContent='Shake detected ✓ ('+n+'). Your phone is ready for the celebration days.';BKS.confetti();if(!ticks.shake){ticks.shake=true;write(ticks)}});t.textContent='Listening... shake the phone now (three quick shakes).'}};
 /* ticking a box updates the counter without redrawing the whole list (keeps your place on the screen) */
 const draw2=()=>{const d=MANUAL.filter(m=>ticks[m[0]]).length;const n=$('#shc').querySelector('.nt');if(n)n.innerHTML=n.innerHTML.replace(/Checklist \d+ of \d+/,'Checklist '+d+' of '+MANUAL.length)};
 draw()}
const api={checks,open,report,MANUAL,version:VER};
(typeof window!=='undefined'?window:globalThis).BKT=api;if(typeof module!=='undefined')module.exports=api;
})();
