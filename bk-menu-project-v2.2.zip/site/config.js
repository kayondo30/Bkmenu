// Public project address and public (publishable) key. Safe to be public.
window.BK={url:'https://qeudronebisrlcqerwvz.supabase.co',key:'sb_publishable_9PPL1dg6NpQ6sIjrGuEETQ_Y8h90CJO'};
