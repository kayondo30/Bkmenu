// node tools/test_detect.js : checks the item detection against the real menu.json
const fs=require('fs'),path=require('path');
const D=require('../site/detect.js');
const m=JSON.parse(fs.readFileSync(path.join(__dirname,'../site/menu.json'),'utf8'));
const items=[];m.pages.forEach(p=>p.sections.forEach(s=>s.items.forEach(i=>items.push({name:i.n||i.name||i[0],grp:p.g,sec:s.t}))));
let bad=0,n=0;
const T=(name,kind,exp)=>{n++;const r=D.detect(name,items,kind);const ok=Object.keys(exp).every(k=>r[k]===exp[k]);if(!ok){bad++;console.log('FAIL',name,JSON.stringify(r),'expected',JSON.stringify(exp))}else console.log('ok  ',name.padEnd(26),'->',r.type,'|',r.grp,'|',r.sec,'|',r.why)};
console.log('items on the menu:',items.length,'sample',JSON.stringify(items[0]));
T('Caramel Latte','',{type:'drink',grp:'Coffee',sec:'Espresso & Milk Coffees'});
T('Hot Chocolate Deluxe','',{type:'drink',grp:'Coffee',sec:'Hot Chocolate'});
T('Spiced Masala Chai','',{type:'drink',grp:'Tea'});
T('Iced Mocha','',{type:'drink',grp:'Iced',sec:'Iced Coffee'});
T('Mixed Fruit Smoothie','',{type:'drink',grp:'Shakes & Smoothies',sec:'Smoothies'});
T('Oreo Milkshake','',{type:'drink',grp:'Shakes & Smoothies',sec:'Milkshakes'});
T('Tamarind Juice','',{type:'drink',grp:'Juices'});
T('Tusker Lite','',{type:'drink',grp:'Beer & Soft',sec:'Beer & Cider'});
T('Sprite 300ml','',{type:'drink',grp:'Beer & Soft',sec:'Soft Drinks & Mixers'});
T('Johnnie Walker Green Label','',{type:'drink',grp:'Whisky'});
T('Glenfiddich 12','',{type:'drink',grp:'Whisky',sec:'Single Malt'});
T('Smirnoff Ice','',{type:'drink',grp:'Spirits',sec:'Vodka'});
T('Hennessy VS','',{type:'drink',grp:'Spirits',sec:'Brandy & Cognac'});
T('Moet Rose','',{type:'drink',grp:'Wine & Bubbly',sec:'Champagne & Other'});
T('House Red Wine','',{type:'drink',grp:'Wine & Bubbly',sec:'Wine'});
T('Passion Mojito','',{type:'drink',grp:'Cocktails',newPage:true});
T('Cocktail Juice','',{type:'drink',grp:'Juices'});
T('Mocha Milkshake','',{type:'drink',grp:'Shakes & Smoothies',sec:'Milkshakes'});
T('Mint Dawa Tea','',{type:'drink',grp:'Tea',sec:'Dawa Teas'});
T('Chicken Burger','',{type:'food',grp:'Food',sec:'Burgers & Sandwiches',newPage:true});
T('Chips and Chicken Wings','',{type:'food',sec:'Snacks & Bites'});
T('Coffee Cake','',{type:'food',sec:'Cakes & Pastries'});
T('Beef Pilau','',{type:'food',sec:'Meals'});
T('Greek Salad','',{type:'food',sec:'Salads & Soups'});
T('Zigni with Injera','',{type:'food',sec:'Meals'});
T('Mystery Thing','food',{type:'food',grp:'Food',newPage:true});
T('Mystery Thing','drink',{type:'drink',grp:''});
T('Mystery Thing','',{type:'',grp:''});
// a menu that already has a Food page: new food goes there, not to a second page
const it2=items.concat([{name:'Samosa',grp:'Snacks',sec:'Starters'},{name:'Rice and Beans',grp:'Snacks',sec:'Mains'}]);
let r=D.detect('Beef Samosa',it2,'');n++;if(r.grp!=='Snacks'){bad++;console.log('FAIL existing food page',JSON.stringify(r))}else console.log('ok   Beef Samosa -> existing page',r.grp,r.sec,r.why);
r=D.detect('Veg Pilau',it2,'');n++;if(r.grp!=='Snacks'||r.newPage){bad++;console.log('FAIL existing page reuse',JSON.stringify(r))}else console.log('ok   Veg Pilau ->',r.grp,r.sec);
/* v6.2 cost + margin maths (margin on the selling price, nearest 500) */
{const S=(c,p,e)=>{n++;const r=D.suggest(c,p);if(r!==e){bad++;console.log('FAIL suggest',c,p,r,'expected',e)}};
S(2000,50,4000);S('2,000',50,4000);S(2500,50,5000);S(3000,50,6000);S(1000,40,1500);S(1800,35,3000);S(0,50,0);S('',50,0);S(2000,95,0);S(100,50,500);
n++;const f=D.profit('4,000',2000);if(!f||f.amt!==2000||f.pct!==50){bad++;console.log('FAIL profit',f)}
n++;if(D.profit('4,000 / 6,000',2000)!==null){bad++;console.log('FAIL profit two sizes')}}
{const E=(a,b)=>{if(a!==b){console.log('FAIL scan',a,b);bad++;n++}};
E(D.sizeFrom('70 cl'),'700ml');E(D.sizeFrom('1 L'),'1L');E(D.sizeFrom('0,75 l'),'750ml');E(D.sizeFrom('750 ml'),'750ml');E(D.sizeFrom('20cl'),'200ml');E(D.sizeFrom('6 x 33 cl'),'330ml');E(D.sizeFrom('a bottle'),'');
E(D.nameFrom('The Glenlivet','Single Malt Scotch 12 Year Old'),'The Glenlivet Single Malt Scotch 12 Year Old');E(D.nameFrom('Jameson','Jameson Irish Whiskey'),'Jameson Irish Whiskey');E(D.nameFrom('SMIRNOFF,Diageo','VODKA'),'Smirnoff Vodka');E(D.nameFrom('','Tusker Lager'),'Tusker Lager');console.log('scan helpers checked')}
/* v6.4 price check */
{const its=[{id:1,name:'Black Label',grp:'Whisky',price:'8,000'},{id:2,name:'Latte',grp:'Coffee',price:'4,000'},{id:3,name:'Gin',grp:'Spirits',price:'5,000 / 8,000'},{id:4,name:'Tea',grp:'Tea',price:'2,000'},{id:5,name:'Water',grp:'Beer & Soft',price:'1,000'},{id:6,name:'Cheap',grp:'Coffee',price:'3,000'}];
const co={1:6000,2:2000,3:2000,4:1900,6:2000};const r=D.priceCheck(its,co,g=>50);
n++;if(r.low.length!==3||r.low[0].id!==4||r.low[1].id!==1){bad++;console.log('FAIL priceCheck order',JSON.stringify(r.low))}
n++;if(r.low.find(x=>x.id===1).sug!==12000){bad++;console.log('FAIL priceCheck suggestion')}
n++;if(r.low.find(x=>x.id===2)||r.low.find(x=>x.id===3)){bad++;console.log('FAIL priceCheck should skip ok and two-size items')}
n++;if(r.noCost!==1||r.odd!==1||r.ok!==1){bad++;console.log('FAIL priceCheck counts',r.noCost,r.odd,r.ok)}
n++;if(D.priceCheck(its,co,g=>g==='Whisky'?20:50).low.find(x=>x.id===1)){bad++;console.log('FAIL priceCheck own page %')}}
console.log(bad?`\n${bad} of ${n} FAILED`:`\nall ${n} checks passed`);process.exit(bad?1:0);
