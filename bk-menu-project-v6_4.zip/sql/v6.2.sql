-- BK menu v6.2: staff-only COST per item + MARGIN % (one default, optional per page) for price suggestions.
-- Run once in Supabase > SQL Editor (new query tab). "Success. No rows returned" is normal.
-- Check: select proname from pg_proc where proname in ('staff_set_cost','staff_set_margin');   -> 2 rows
-- Costs live in their OWN tables: only staff can read them. Guests cannot (menu_items is public, so no cost column there).
-- Nothing in your menu data is changed.
create table if not exists item_costs(item_id int primary key references menu_items(id) on delete cascade, cost int not null check (cost>=0));
create table if not exists margin_rules(grp text primary key, pct int not null check (pct>=0 and pct<=90));
alter table item_costs enable row level security; alter table margin_rules enable row level security;
drop policy if exists ic_read on item_costs; create policy ic_read on item_costs for select using (is_staff());
drop policy if exists mr_read on margin_rules; create policy mr_read on margin_rules for select using (is_staff());
insert into margin_rules(grp,pct) values ('*',50) on conflict (grp) do nothing;
-- c = null or 0 removes the cost
create or replace function staff_set_cost(i int,c int,pin text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; begin w:=chk_pin(pin); if w<>'ok' then return w; end if;
 if c is null or c<=0 then delete from item_costs where item_id=i;
 else insert into item_costs(item_id,cost) values(i,c) on conflict (item_id) do update set cost=excluded.cost; end if;
 insert into audit_log(who,action,detail) values(auth.uid(),'item '||i,case when c is null or c<=0 then 'cost removed' else 'cost set' end);
 return 'ok'; end $$;
-- g = '*' is the default for every page; pct = null on a page goes back to the default
create or replace function staff_set_margin(g text,pct int,pin text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; begin w:=chk_pin(pin); if w<>'ok' then return w; end if;
 if g='*' and pct is null then return 'need_value'; end if;
 if pct is null then delete from margin_rules where margin_rules.grp=g;
 else insert into margin_rules(grp,pct) values(g,least(greatest(pct,0),90)) on conflict (grp) do update set pct=excluded.pct; end if;
 insert into audit_log(who,action,detail) values(auth.uid(),'margin '||g,'margin percent '||coalesce(pct::text,'back to default'));
 return 'ok'; end $$;
grant execute on function staff_set_cost(int,int,text) to authenticated;
grant execute on function staff_set_margin(text,int,text) to authenticated;
