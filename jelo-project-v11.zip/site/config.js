// ===== ONE PLACE FOR EACH BUSINESS (v5.5) =====
// A new client: change the lines in "brand" below, replace logo.png and the two icons, edit manifest.webmanifest (name, short_name),
// put their drinks in menu.json and their Supabase address and publishable key here. Nothing else needs changing. See NEW-CLIENT.md.
window.BK={
  // Public Supabase project address and publishable key (safe to be public; never put the secret or service_role key here)
 url:'https://vjzfqrliwfjvzlzmriyq.supabase.co',
 key:'sb_publishable_q3erWWoZI5RIaOfvH9z4hQ_P2MsK6uy',
 usd:4350,                                   // dollar rate used until the live rate loads (CHECK today's rate)
 brand:{
  short:"JeLo's",                             // short name (staff page title "JeLo's staff")
  full:"JeLo's Cafe", // full company name: logo text for screen readers, signature on message cards
  title:"JeLo's Cafe Drinks Menu",                  // browser tab, share, install name
  motto:'',             // first footer line (empty = none)
  footer:"JeLo's Cafe • Drinks Menu", // second footer line
  share:"Our drinks menu",                   // text sent with the Share button

  celebrate:['general','uganda'] // celebration sets: eritrea (Lidet, Timket, Fasika, Independence, Geez New Year, Meskel), general (Christmas, New Year, Easter, Valentine's), islam (both Eids), uganda (Independence 9 Oct); [] = none
 }
};
