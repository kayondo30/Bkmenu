# BK Beverage Menu - change log
Short list, newest first. Full detail for each version is in README.md. "SQL" = a file to run once in Supabase.

| Version | Date | What changed | SQL |
|---|---|---|---|
| v6.2 | 2026-11-03 | Cost + margin price suggestions: staff-only Cost per item (Add a drink and the tap-a-drink sheet), a cost chip in FRONT of the usual price chips, Profit line, Margin % in More (one default, optional per page) | v6.2.sql (run once) |
| v6.1.2 | 2026-11-03 | Prompt only: decided that the current price chips stay and the cost chip is added in front | none |
| v6.1.1 | 2026-11-03 | Prompt only: cost + margin price suggestions saved as PLANNED (not built, waiting for my answers) | none |
| v6.1 | 2026-11-03 | Staff how-to video updated to the current features (97 s, 11 steps) and built into the staff screen: More > Watch the how-to video | none |
| v6.0 | 2026-11-03 | Hiding an item needs a REASON; the reason, who and when show in Who changed what (HIDDEN / shown again) | v6.0.sql (run once) |
| v5.9 | 2026-11-03 | Item name now at the top of the tap-a-drink sheet and saved with the main Save; price hint reworded | none |
| v5.8 | 2026-11-03 | Staff page, More: "Who changed what" = who (login name), what and when, newest first, See all 100 | v5.8.sql (read-only, run once) |
| v5.7.1 | 2026-11-03 | This change log added (project zip only, site files unchanged) | none |
| v5.7 | 2026-11-03 | Price suggestion chips in Add a drink or food (closest relative, most used prices in the section) | none |
| v5.6 | 2026-11-03 | Add drink OR food with automatic page/section; shake to celebrate; Admin test (23 checks); staff how-to video. Confirmed live on my phone | none |
| v5.5 | 2026-11-01 | Richer special card; ONE config.js per client (template); NEW-CLIENT.md | none |
| v5.4 | 2026-11-01 | Staff messages visible over sheets; login renewed on save. Confirmed deployed | none |
| v5.3 | 2026-11-01 | Specials follow the language switch; Suggest Tigrinya button (machine translation, to be checked) | none |
| v5.2 | 2026-11-01 | Celebrations by the Eritrean and Gregorian calendar; featured carousel; deco.js | none |
| v5.1 | 2026-11-01 | Simple staff page (4 tabs); add drinks in the app; prices written 4,000/= | v5.1.sql (run 2026-11-01) |
| v5.0 | 2026-11-01 | Whole menu and staff screen remade to the FHG Calm standard | none |
| v4.1 | 2026-10-29 | USD/UGX switch | none |
| v4.0 | 2026-10-29 | Leading icons on chips and rows | none |
| v3.9 | 2026-10-29 | Hotel-style menu reorganisation (9 pages) | v3.9.sql (optional, not run; undo file exists) |
| v3.8 | 2026-10-29 | Bottom toolbar, calm look | none |
| v3.7 | 2026-10-29 | Follows phone light/dark; logo header; cover photo removed | none |
| v3.6 | 2026-10-26 | Decoration, photo carousel and photo slots | none |
| v3.5 | 2026-10-26 | Today tiles, staff list, scheduled specials, seasons | v3.5.sql (run 2026-10-26) |
| v3.4 | 2026-10-26 | Customer vs staff detection | none |
| v3.3 | 2026-10-26 | PIN-only lock screen | none |
| v3.2 | 2026-10-26 | Staff view on the same address | none |
| v3.1 | 2026-10-26 | Logout, signed-in bar | v3.1.sql (run 2026-10-26) |
| v3 | 2026-10-25 | Specials and share | v3.sql (run) |
| v2.2 | 2026-10-25 | Config file | none |
| v2.1 | 2026-10-25 | Key fix | none |
| v2 | 2026-10-25 | Staff control (login, prices, Sold out, Hold, PIN, banner) | v2.sql (run) |
| v1.1 | 2026-10-25 | Logo | none |
| v1 | 2026-10-25 | First menu | none |

RULE: add a line here at every version (together with README.md and the prompt).
