// node tools/test_waiter.js : runs waiter.html and the admin Waiters sheet in headless Chrome with a pretend Supabase (v7.1, part 7b).
const {chromium}=require(process.env.PW||'/home/claude/.npm-global/lib/node_modules/playwright');
const http=require('http'),fs=require('fs'),path=require('path');
const SITE=path.join(__dirname,'../site');
const MIME={'.html':'text/html','.js':'text/javascript','.json':'application/json','.png':'image/png','.woff':'font/woff'};
const srv=http.createServer((q,r)=>{let u=decodeURIComponent(q.url.split('?')[0]);const f=path.join(SITE,u);fs.readFile(f,(e,b)=>{if(e){r.writeHead(404);r.end();return}r.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});r.end(b)})});
let pass=0,fail=0;const ok=(c,m)=>{if(c){pass++;console.log('  ok  ',m)}else{fail++;console.log('  FAIL',m)}};
const b64=o=>Buffer.from(JSON.stringify(o)).toString('base64url');
(async()=>{await new Promise(r=>srv.listen(0,r));const base='http://localhost:'+srv.address().port;
 const br=await chromium.launch(),ctx=await br.newContext({viewport:{width:390,height:800}}),pg=await ctx.newPage();
 const calls=[];let tables=[];let logged=false;
 await pg.route('https://qeudronebisrlcqerwvz.supabase.co/**',async route=>{const u=new URL(route.request().url()),m=route.request().method(),fn=u.pathname.split('/').pop();
  const J=b=>route.fulfill({status:200,headers:{'access-control-allow-origin':'*','content-type':'application/json'},body:JSON.stringify(b)});
  if(m==='OPTIONS')return route.fulfill({status:204,headers:{'access-control-allow-origin':'*','access-control-allow-headers':'*','access-control-allow-methods':'*'}});
  const body=route.request().postData()?JSON.parse(route.request().postData()):{};calls.push([fn,body]);
  if(fn==='waiter_login')return J(body.pin==='1234'?{r:'ok',token:'11111111-1111-1111-1111-111111111111',name:'Sara'}:{r:'bad_login'});
  if(fn==='waiter_tables')return J({r:'ok',tables});
  if(fn==='waiter_open_table'){if(body.tbl==='9')return J({r:'table_busy'});tables.push({id:7,table_label:body.tbl,code:'4719',opened_at:new Date().toISOString(),total:0,guests:[]});return J({r:'ok',id:7,code:'4719'})}
  if(fn==='waiter_close_table'){tables=[];return J('ok')}
  if(fn==='waiter_logout')return J('ok');
  return J([]);});
 await pg.goto(base+'/waiter.html');
 ok(await pg.locator('#n').count()===1,'login screen shows');
 await pg.fill('#n','Sara');await pg.fill('#p','0000');await pg.click('#g');await pg.waitForTimeout(300);
 ok(/Wrong name or PIN/.test(await pg.textContent('#msg')),'wrong PIN is refused');
 await pg.fill('#p','1234');await pg.click('#g');await pg.waitForSelector('#tn');
 ok(/Hello, Sara/.test(await pg.textContent('#a')),'login works');
 await pg.fill('#tn','9');await pg.click('#op');await pg.waitForTimeout(300);
 ok(/already open/.test(await pg.textContent('#msg')),'busy table message');
 await pg.fill('#tn','5');await pg.click('#op');await pg.waitForSelector('.code');
 ok((await pg.textContent('.code'))==='4719'&&/Table 5/.test(await pg.textContent('#ls')),'code and table shown');
 await pg.click('[data-c]');ok(await pg.locator('[data-c]').count()===1&&!calls.some(c=>c[0]==='waiter_close_table'),'first tap only asks to confirm');
 await pg.click('[data-c]');await pg.waitForFunction(()=>/No open tables/.test(document.querySelector('#ls').textContent));
 ok(calls.some(c=>c[0]==='waiter_close_table'),'second tap closes the table');
 await pg.reload();await pg.waitForSelector('#tn');ok(/Hello, Sara/.test(await pg.textContent('#a')),'stays logged in after reload');
 await pg.click('#lo');await pg.waitForSelector('#n');ok(true,'log out returns to login');
 // admin Waiters sheet
 const JWT='x.'+b64({email:'a@b.c',role:'authenticated'})+'.y';
 const ap=await ctx.newPage();let wl=[{id:1,name:'Sara',active:true}];const ac=[];
 await ap.route('https://qeudronebisrlcqerwvz.supabase.co/**',async route=>{const u=new URL(route.request().url()),m=route.request().method(),p=u.pathname;
  const J=b=>route.fulfill({status:200,headers:{'access-control-allow-origin':'*','content-type':'application/json'},body:JSON.stringify(b)});
  if(m==='OPTIONS')return route.fulfill({status:204,headers:{'access-control-allow-origin':'*','access-control-allow-headers':'*','access-control-allow-methods':'*'}});
  const fn=p.split('/').pop(),body=route.request().postData()?JSON.parse(route.request().postData()):{};
  if(p.includes('/auth/v1/token'))return J({access_token:JWT,refresh_token:'r'});
  if(fn==='list_waiters')return J(wl);if(fn==='verify_pin')return J('ok');
  if(fn==='staff_add_waiter'){ac.push(fn);wl.push({id:2,name:body.nm,active:true});return J('ok')}
  if(fn==='staff_set_waiter_active'){ac.push(fn);wl[0].active=body.act;return J('ok')}
  if(fn==='staff_reset_waiter_pin'){ac.push(fn);return J('bad_waiter_pin')}
  if(p.endsWith('/menu_items'))return J([{id:1,grp:'Beer',sec:'Beer',name:'X',variant:'',price:'4000',sort:1}]);
  if(p.includes('/rpc/'))return J([]);return J([]);});
 await ap.goto(base+'/admin.html');await ap.waitForSelector('#a');
 await ap.evaluate(t=>{T=t;return panel()},JWT);await ap.waitForSelector('#add');
 await ap.evaluate(()=>{TAB='m';draw()});await ap.waitForSelector('#wtb',{timeout:4000}).catch(()=>{});
 ok(await ap.locator('#wtb').count()===1,'More shows the Waiters card');
 await ap.click('#wtb');ok(/Sara/.test(await ap.textContent('#shc')),'sheet lists waiters');
 await ap.click('#wta');await ap.fill('#wn','Tesfay');await ap.fill('#wp','5566');await ap.click('#wsv');
 await ap.waitForFunction(()=>document.querySelector('#pd[open]'));await ap.fill('#pdi','1111');await ap.click('#pdok');
 await ap.waitForFunction(()=>/Tesfay/.test(document.querySelector('#shc').textContent));ok(true,'add waiter then list shows Tesfay');
 await ap.click('[data-w="1"]');await ap.click('#wac');await ap.waitForFunction(()=>/Paused/.test(document.querySelector('#shc').textContent));ok(ac.includes('staff_set_waiter_active'),'pause works');
 await ap.click('[data-w="1"]');await ap.fill('#wp2','12');await ap.click('#wrp');await ap.waitForTimeout(300);
 ok(/4 to 8/.test(await ap.textContent('#msg')),'bad new PIN message');
 await br.close();srv.close();console.log(pass+' passed, '+fail+' failed');process.exit(fail?1:0)})();
