-- Undo BK menu v7.0 part 7a (Table ordering database). Removes the waiter and ordering tables and functions.
-- WARNING: deletes every waiter, table and order saved by the ordering feature. Menu, prices, costs, specials and happy hours are untouched.
drop function if exists waiter_login(text,text), waiter_logout(uuid), waiter_open_table(uuid,text), waiter_tables(uuid),
  waiter_order_step(uuid,int,text), waiter_close_table(uuid,int), guest_join(text), guest_status(uuid),
  guest_send_order(uuid,jsonb), guest_set_pay(uuid,text), staff_add_waiter(text,text,text), staff_set_waiter_active(int,bool,text),
  staff_reset_waiter_pin(int,text,text), list_waiters(), admin_closed_tables(int), w_of(uuid), g_of(uuid) cascade;
drop table if exists order_lines, orders, sitting_guests, sittings, waiter_sessions, waiters, join_tries cascade;
drop function if exists lock_closed() cascade;
