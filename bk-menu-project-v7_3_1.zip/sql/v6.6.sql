-- BK menu v6.6 part 1 of 4 (HAPPY HOUR): the database only. The app does not use it yet (parts 2 and 3).
-- Run once in Supabase > SQL Editor (new query tab). "Success. No rows returned" is normal.
-- Check:  select proname from pg_proc where proname in ('staff_save_happy','staff_set_happy_active','staff_delete_happy');   -> 3 rows
-- Check:  select table_name from information_schema.tables where table_name in ('happy_hours','happy_hour_rules');            -> 2 rows
-- Nothing in your menu, prices, costs or specials is changed. Undo = sql/v6.6-undo.sql.
--
-- HOW IT WORKS
-- happy_hours      = one row per happy hour: name, days (0 = Sunday ... 6 = Saturday, same as the phone), start and end
--                    as minutes after midnight on the guest's phone clock (e.g. 17:00 = 1020), on/off.
--                    If the end is not later than the start, it runs past midnight into the next day.
-- happy_hour_rules = what gets cheaper: a whole PAGE by a percentage (grp + pct), or ONE ITEM by a percentage (item_id + pct)
--                    or by a fixed happy price (item_id + price; for items with one price).
-- Guests read only the ones that are switched on; staff read all. Only staff with the PIN can change them.
-- The real menu price is never changed: the guest menu works out the happy price while a happy hour is live.

create table if not exists happy_hours(
  id serial primary key,
  name text not null,
  days int[] not null,
  start_min int not null check (start_min>=0 and start_min<=1439),
  end_min int not null check (end_min>=1 and end_min<=1440 and end_min<>start_min),
  active bool not null default true,
  created_at timestamptz default now()
);
create table if not exists happy_hour_rules(
  id serial primary key,
  hh_id int not null references happy_hours(id) on delete cascade,
  grp text,
  item_id int references menu_items(id) on delete cascade,
  pct int check (pct>=1 and pct<=90),
  price int check (price>0),
  check ((grp is not null)::int + (item_id is not null)::int = 1),
  check ((pct is not null)::int + (price is not null)::int = 1),
  check (grp is null or pct is not null)
);
create index if not exists happy_hour_rules_hh on happy_hour_rules(hh_id);

alter table happy_hours enable row level security;
alter table happy_hour_rules enable row level security;
drop policy if exists hh_read on happy_hours;
create policy hh_read on happy_hours for select using (active or is_staff());
drop policy if exists hhr_read on happy_hour_rules;
create policy hhr_read on happy_hour_rules for select using (
  is_staff() or exists(select 1 from happy_hours h where h.id=hh_id and h.active));

-- Save one happy hour and ALL its rules in one go. i = 0 adds a new one, i = its id edits it (the rules are replaced).
-- rules = JSON list, e.g. [{"grp":"Beer & Soft","pct":20},{"item_id":92,"price":8000}]
-- Returns 'ok' or: bad_pin / locked / not_set / denied (PIN problems), need_name, need_days, bad_time, need_rule, bad_rule, not_found
create or replace function staff_save_happy(i int, nm text, dys int[], s int, e int, act bool, rules jsonb, pin text)
returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; n text := left(trim(coalesce(nm,'')),60); x jsonb; g text; it int; pc int; pr int; hid int; dd int[];
begin
 w:=chk_pin(pin); if w<>'ok' then return w; end if;
 if n='' then return 'need_name'; end if;
 if dys is null or cardinality(dys)=0 or not (dys <@ array[0,1,2,3,4,5,6]) then return 'need_days'; end if;
 if s is null or e is null or s<0 or s>1439 or e<1 or e>1440 or s=e then return 'bad_time'; end if;
 if rules is null or jsonb_typeof(rules)<>'array' or jsonb_array_length(rules)=0 then return 'need_rule'; end if;
 if jsonb_array_length(rules)>60 then return 'bad_rule'; end if;
 begin
  for x in select * from jsonb_array_elements(rules) loop
   g:=nullif(trim(coalesce(x->>'grp','')),''); it:=nullif(x->>'item_id','')::int;
   pc:=nullif(x->>'pct','')::int; pr:=nullif(x->>'price','')::int;
   if (g is not null)::int + (it is not null)::int <> 1 then return 'bad_rule'; end if;
   if (pc is not null)::int + (pr is not null)::int <> 1 then return 'bad_rule'; end if;
   if pc is not null and (pc<1 or pc>90) then return 'bad_rule'; end if;
   if pr is not null and pr<=0 then return 'bad_rule'; end if;
   if g is not null and (pc is null or not exists(select 1 from menu_items where grp=g)) then return 'bad_rule'; end if;
   if it is not null and not exists(select 1 from menu_items where id=it) then return 'bad_rule'; end if;
  end loop;
 exception when others then return 'bad_rule';
 end;
 select coalesce(array_agg(d order by d),'{}') into dd from (select distinct unnest(dys) as d) q;
 if i is null or i=0 then
  insert into happy_hours(name,days,start_min,end_min,active) values(n,dd,s,e,coalesce(act,true)) returning id into hid;
 else
  update happy_hours set name=n,days=dd,start_min=s,end_min=e,active=coalesce(act,true) where id=i returning id into hid;
  if hid is null then return 'not_found'; end if;
  delete from happy_hour_rules where hh_id=hid;
 end if;
 insert into happy_hour_rules(hh_id,grp,item_id,pct,price)
  select hid, nullif(trim(coalesce(y->>'grp','')),''), nullif(y->>'item_id','')::int, nullif(y->>'pct','')::int, nullif(y->>'price','')::int
  from jsonb_array_elements(rules) y;
 insert into audit_log(who,action,detail) values(auth.uid(),'happy '||hid,
  'happy hour "'||n||'" saved, '||case when coalesce(act,true) then 'on' else 'paused' end||', '||jsonb_array_length(rules)||' rule(s)');
 return 'ok'; end $$;

-- Switch one happy hour on or off (paused ones are hidden from guests and keep their settings).
create or replace function staff_set_happy_active(i int, act bool, pin text)
returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; n text; begin w:=chk_pin(pin); if w<>'ok' then return w; end if;
 update happy_hours set active=coalesce(act,false) where id=i returning name into n;
 if n is null then return 'not_found'; end if;
 insert into audit_log(who,action,detail) values(auth.uid(),'happy '||i,'happy hour "'||n||'" '||case when coalesce(act,false) then 'switched ON' else 'PAUSED' end);
 return 'ok'; end $$;

-- Delete one happy hour and its rules.
create or replace function staff_delete_happy(i int, pin text)
returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; n text; begin w:=chk_pin(pin); if w<>'ok' then return w; end if;
 delete from happy_hours where id=i returning name into n;
 if n is null then return 'not_found'; end if;
 insert into audit_log(who,action,detail) values(auth.uid(),'happy '||i,'happy hour "'||n||'" DELETED');
 return 'ok'; end $$;

grant execute on function staff_save_happy(int,text,int[],int,int,bool,jsonb,text) to authenticated;
grant execute on function staff_set_happy_active(int,bool,text) to authenticated;
grant execute on function staff_delete_happy(int,text) to authenticated;
