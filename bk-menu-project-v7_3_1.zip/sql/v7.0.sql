-- BK menu v7.0 part 7a of 7 (TABLE ORDERING): the database only. The app does not use it yet (parts 7b to 7g).
-- Run once in Supabase > SQL Editor (new query tab). "Success. No rows returned" is normal.
-- Check:  select proname from pg_proc where proname in ('waiter_login','waiter_open_table','waiter_tables','waiter_order_step','waiter_close_table','guest_join','guest_status','guest_send_order','guest_set_pay','staff_add_waiter','staff_set_waiter_active','staff_reset_waiter_pin','list_waiters','admin_closed_tables');   -> 14 rows
-- Nothing in your menu, prices, costs, specials or happy hours is changed. Undo = sql/v7.0-undo.sql.
--
-- HOW IT WORKS
-- Waiters are NOT Supabase logins. The admin adds a waiter by the name he is known by and the 4 to 8 digit PIN the waiter chose.
-- A waiter logs in with name + PIN and gets a session key (12 hours). Guests never log in.
-- The waiter seats a table: picks the table number, the app makes a 4 digit code. Up to 5 phones join with that code
-- (Guest 1 to Guest 5, no names). The code works until the waiter closes the table.
-- A guest sends a list (an order). The waiter confirms it by mouth, then moves it along: Received > Preparing > On the way > Served.
-- Privacy is enforced HERE: all tables are locked (no direct reading); everything goes through the functions below.
--   Admin: sees CLOSED tables only (admin_closed_tables). Never an open table, code or live order.
--   Waiter: sees only his own open tables. Closed tables can not be changed or deleted (trigger).

create table if not exists waiters(
  id serial primary key,
  name text not null,
  pin_hash text not null,
  active bool not null default true,
  tries int not null default 0,
  locked_until timestamptz,
  created_at timestamptz default now()
);
create unique index if not exists waiters_name_uq on waiters(lower(name));

create table if not exists waiter_sessions(
  token uuid primary key default gen_random_uuid(),
  waiter_id int not null references waiters(id) on delete cascade,
  expires_at timestamptz not null default now()+interval '12 hours'
);

create table if not exists sittings(
  id serial primary key,
  waiter_id int not null references waiters(id),
  waiter_name text not null,
  table_label text not null,
  code text not null,
  status text not null default 'open' check (status in ('open','closed')),
  opened_at timestamptz not null default now(),
  closed_at timestamptz
);
create unique index if not exists sittings_open_code on sittings(code) where status='open';
create unique index if not exists sittings_open_table on sittings(lower(table_label)) where status='open';

create table if not exists sitting_guests(
  id serial primary key,
  sitting_id int not null references sittings(id) on delete cascade,
  num int not null check (num between 1 and 5),
  token uuid not null unique default gen_random_uuid(),
  pay text check (pay in ('Cash','MTN MoMo','Airtel Money','Card (Visa machine)')),
  joined_at timestamptz default now(),
  unique (sitting_id,num)
);

create table if not exists orders(
  id serial primary key,
  sitting_id int not null references sittings(id) on delete cascade,
  guest_id int not null references sitting_guests(id) on delete cascade,
  status text not null default 'sent' check (status in ('sent','received','preparing','on_the_way','served')),
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);
create index if not exists orders_sitting on orders(sitting_id);

create table if not exists order_lines(
  id serial primary key,
  order_id int not null references orders(id) on delete cascade,
  item_id int,
  name text not null,
  price int not null check (price>0),
  qty int not null check (qty between 1 and 20)
);
create index if not exists order_lines_order on order_lines(order_id);

create table if not exists join_tries(at timestamptz not null default now());

-- Everything locked: row security on, NO policies = no direct reading or writing from the app.
alter table waiters enable row level security;
alter table waiter_sessions enable row level security;
alter table sittings enable row level security;
alter table sitting_guests enable row level security;
alter table orders enable row level security;
alter table order_lines enable row level security;
alter table join_tries enable row level security;

-- A closed table can not be changed or deleted by anyone.
create or replace function lock_closed() returns trigger language plpgsql as $$
declare sid int; st text;
begin
 if tg_table_name='sittings' then
  if old.status='closed' then raise exception 'table is closed'; end if;
  return case when tg_op='DELETE' then old else new end;
 end if;
 if tg_table_name='order_lines' then
  select o.sitting_id into sid from orders o where o.id=coalesce(new.order_id,old.order_id);
 else
  sid:=coalesce(new.sitting_id,old.sitting_id);
 end if;
 select status into st from sittings where id=sid;
 if st='closed' then raise exception 'table is closed'; end if;
 return case when tg_op='DELETE' then old else new end;
end $$;
drop trigger if exists lock_sittings on sittings;
create trigger lock_sittings before update or delete on sittings for each row execute function lock_closed();
drop trigger if exists lock_guests on sitting_guests;
create trigger lock_guests before insert or update or delete on sitting_guests for each row execute function lock_closed();
drop trigger if exists lock_orders on orders;
create trigger lock_orders before insert or update or delete on orders for each row execute function lock_closed();
drop trigger if exists lock_lines on order_lines;
create trigger lock_lines before insert or update or delete on order_lines for each row execute function lock_closed();

-- Helpers (not callable from the app).
create or replace function w_of(tok uuid) returns int language sql security definer stable set search_path=public as $$
 select s.waiter_id from waiter_sessions s join waiters w on w.id=s.waiter_id
 where s.token=tok and s.expires_at>now() and w.active $$;
create or replace function g_of(tok uuid) returns int language sql security definer stable set search_path=public as $$
 select g.id from sitting_guests g join sittings s on s.id=g.sitting_id where g.token=tok and s.status='open' $$;
revoke all on function w_of(uuid) from public, anon, authenticated;
revoke all on function g_of(uuid) from public, anon, authenticated;

-- ===== WAITER =====
-- Log in with name + PIN. Replies {"r":"ok","token":"...","name":"..."} or {"r":"bad_login"|"locked"}.
create or replace function waiter_login(nm text, pin text)
returns jsonb language plpgsql security definer set search_path=public,extensions as $$
declare w waiters%rowtype; t uuid;
begin
 select * into w from waiters where lower(name)=lower(trim(coalesce(nm,''))) and active;
 if not found then return jsonb_build_object('r','bad_login'); end if;
 if w.locked_until>now() then return jsonb_build_object('r','locked'); end if;
 if w.pin_hash<>crypt(coalesce(pin,''),w.pin_hash) then
  update waiters set locked_until=case when tries+1>=3 then now()+interval '15 minutes' end,
         tries=case when tries+1>=3 then 0 else tries+1 end where id=w.id;
  return jsonb_build_object('r','bad_login');
 end if;
 update waiters set tries=0,locked_until=null where id=w.id;
 delete from waiter_sessions where expires_at<now();
 insert into waiter_sessions(waiter_id) values(w.id) returning token into t;
 return jsonb_build_object('r','ok','token',t,'name',w.name);
end $$;

create or replace function waiter_logout(tok uuid) returns text language sql security definer set search_path=public as $$
 delete from waiter_sessions where token=tok returning 'ok' $$;

-- Seat a table: makes a fresh 4 digit code. Replies {"r":"ok","id":..,"code":".."} or {"r":"no_login"|"need_table"|"table_busy"|"try_again"}.
create or replace function waiter_open_table(tok uuid, tbl text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; lbl text := left(trim(coalesce(tbl,'')),20); c text; sid int; k int := 0; nm text;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 if lbl='' then return jsonb_build_object('r','need_table'); end if;
 if exists(select 1 from sittings where status='open' and lower(table_label)=lower(lbl)) then return jsonb_build_object('r','table_busy'); end if;
 select name into nm from waiters where id=w;
 loop
  c:=lpad((floor(random()*10000))::int::text,4,'0');
  begin
   insert into sittings(waiter_id,waiter_name,table_label,code) values(w,nm,lbl,c) returning id into sid;
   return jsonb_build_object('r','ok','id',sid,'code',c);
  exception when unique_violation then
   k:=k+1; if k>25 then return jsonb_build_object('r','try_again'); end if;
  end;
 end loop;
end $$;

-- The waiter's own OPEN tables with guests, orders, lines and totals.
create or replace function waiter_tables(tok uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; r jsonb;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 select coalesce(jsonb_agg(to_jsonb(t) order by t.opened_at),'[]'::jsonb) into r from (
  select s.id, s.table_label, s.code, s.opened_at,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('num',g.num,'pay',g.pay,'orders',
      (select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'at',o.created_at,'lines',
         (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price) order by l.id),'[]'::jsonb)
          from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb)
       from orders o where o.guest_id=g.id)) order by g.num),'[]'::jsonb)
    from sitting_guests g where g.sitting_id=s.id) as guests
  from sittings s where s.waiter_id=w and s.status='open') t;
 return jsonb_build_object('r','ok','tables',r);
end $$;

-- Move an order along. st = received (confirmed by mouth) | preparing | on_the_way | served.
create or replace function waiter_order_step(tok uuid, ord_id int, st text)
returns text language plpgsql security definer set search_path=public as $$
declare w int; n int;
begin
 w:=w_of(tok); if w is null then return 'no_login'; end if;
 if st not in ('received','preparing','on_the_way','served') then return 'bad_step'; end if;
 update orders o set status=st, updated_at=now()
  from sittings s where o.id=ord_id and s.id=o.sitting_id and s.waiter_id=w and s.status='open';
 get diagnostics n=row_count;
 if n=0 then return 'not_found'; end if;
 return 'ok';
end $$;

-- Close the table: the code stops working, the table is locked for ever, the waiter's name stays on it.
create or replace function waiter_close_table(tok uuid, sid int)
returns text language plpgsql security definer set search_path=public as $$
declare w int; n int;
begin
 w:=w_of(tok); if w is null then return 'no_login'; end if;
 update sittings set status='closed', closed_at=now() where id=sid and waiter_id=w and status='open';
 get diagnostics n=row_count;
 if n=0 then return 'not_found'; end if;
 return 'ok';
end $$;

-- ===== GUEST (no login) =====
-- Join with the waiter's code. Replies {"r":"ok","gtoken":"..","num":1,"table":".."} or {"r":"bad_code"|"full"|"slow_down"}.
create or replace function guest_join(cd text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare s sittings%rowtype; g sitting_guests%rowtype; k int; c text := regexp_replace(coalesce(cd,''),'\D','','g');
begin
 delete from join_tries where at<now()-interval '10 minutes';
 select count(*) into k from join_tries where at>now()-interval '1 minute';
 if k>=30 then return jsonb_build_object('r','slow_down'); end if;
 select * into s from sittings where code=c and status='open';
 if not found then insert into join_tries default values; return jsonb_build_object('r','bad_code'); end if;
 select count(*) into k from sitting_guests where sitting_id=s.id;
 if k>=5 then return jsonb_build_object('r','full'); end if;
 insert into sitting_guests(sitting_id,num) values(s.id,k+1) returning * into g;
 return jsonb_build_object('r','ok','gtoken',g.token,'num',g.num,'table',s.table_label);
exception when unique_violation then
 return jsonb_build_object('r','slow_down');
end $$;

-- The guest's own screen: connected or not, his list with progress, his total, how he plans to pay.
create or replace function guest_status(gt uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype; s sittings%rowtype;
begin
 select * into g from sitting_guests where token=gt;
 if not found then return jsonb_build_object('connected',false); end if;
 select * into s from sittings where id=g.sitting_id;
 return jsonb_build_object('connected',s.status='open','closed',s.status='closed','num',g.num,'table',s.table_label,'pay',g.pay,
  'total',(select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.guest_id=g.id),
  'orders',(select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'lines',
      (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price) order by l.id),'[]'::jsonb)
       from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb) from orders o where o.guest_id=g.id));
end $$;

-- Send a list: lines = [{"item_id":12,"qty":2,"price":4000}, ...]. The price must be one of the item's real prices.
-- Replies ok | not_connected | empty | bad_line | too_many
create or replace function guest_send_order(gt uuid, lines jsonb)
returns text language plpgsql security definer set search_path=public as $$
declare g int; sid int; x jsonb; it int; q int; pr int; nm text; new_id int; cnt int;
begin
 g:=g_of(gt); if g is null then return 'not_connected'; end if;
 if lines is null or jsonb_typeof(lines)<>'array' or jsonb_array_length(lines)=0 then return 'empty'; end if;
 if jsonb_array_length(lines)>30 then return 'bad_line'; end if;
 select count(*) into cnt from orders where guest_id=g; if cnt>=20 then return 'too_many'; end if;
 select sitting_id into sid from sitting_guests where id=g;
 insert into orders(sitting_id,guest_id) values(sid,g) returning id into new_id;
 begin
  for x in select * from jsonb_array_elements(lines) loop
   it:=(x->>'item_id')::int; q:=(x->>'qty')::int; pr:=(x->>'price')::int;
   if q is null or q<1 or q>20 or pr is null or pr<=0 then raise exception 'bad'; end if;
   select m.name||case when coalesce(m.variant,'')<>'' then ' ('||m.variant||')' else '' end into nm
    from menu_items m
    where m.id=it and not coalesce(m.hidden,false) and not coalesce(m.sold_out,false)
      and exists(select 1 from regexp_matches(replace(coalesce(m.price,''),',',''),'\d+','g') r where r[1]::int=pr);
   if nm is null then raise exception 'bad'; end if;
   insert into order_lines(order_id,item_id,name,price,qty) values(new_id,it,nm,pr,q);
  end loop;
 exception when others then
  delete from orders where id=new_id;
  return 'bad_line';
 end;
 return 'ok';
end $$;

-- The guest tells his waiter how he plans to pay (a notice only; the app never takes money). NULL clears it.
create or replace function guest_set_pay(gt uuid, method text)
returns text language plpgsql security definer set search_path=public as $$
declare g int;
begin
 g:=g_of(gt); if g is null then return 'not_connected'; end if;
 if method is not null and method not in ('Cash','MTN MoMo','Airtel Money','Card (Visa machine)') then return 'bad_method'; end if;
 update sitting_guests set pay=method where id=g;
 return 'ok';
end $$;

-- ===== ADMIN (staff login + Action PIN, as everywhere else) =====
-- Add a waiter: name he is known by + the PIN (4 to 8 digits) he chose.
create or replace function staff_add_waiter(nm text, wpin text, pin text)
returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; n text := left(trim(coalesce(nm,'')),30); id1 int;
begin
 w:=chk_pin(pin); if w<>'ok' then return w; end if;
 if length(n)<2 then return 'need_name'; end if;
 if coalesce(wpin,'') !~ '^[0-9]{4,8}$' then return 'bad_waiter_pin'; end if;
 if exists(select 1 from waiters where lower(name)=lower(n)) then return 'name_taken'; end if;
 insert into waiters(name,pin_hash) values(n,crypt(wpin,gen_salt('bf'))) returning id into id1;
 insert into audit_log(who,action,detail) values(auth.uid(),'waiter '||id1,'waiter "'||n||'" added');
 return 'ok';
end $$;

create or replace function staff_set_waiter_active(i int, act bool, pin text)
returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; n text;
begin
 w:=chk_pin(pin); if w<>'ok' then return w; end if;
 update waiters set active=coalesce(act,false) where id=i returning name into n;
 if n is null then return 'not_found'; end if;
 if not coalesce(act,false) then delete from waiter_sessions where waiter_id=i; end if;
 insert into audit_log(who,action,detail) values(auth.uid(),'waiter '||i,'waiter "'||n||'" '||case when coalesce(act,false) then 'switched ON' else 'PAUSED' end);
 return 'ok';
end $$;

create or replace function staff_reset_waiter_pin(i int, wpin text, pin text)
returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; n text;
begin
 w:=chk_pin(pin); if w<>'ok' then return w; end if;
 if coalesce(wpin,'') !~ '^[0-9]{4,8}$' then return 'bad_waiter_pin'; end if;
 update waiters set pin_hash=crypt(wpin,gen_salt('bf')),tries=0,locked_until=null where id=i returning name into n;
 if n is null then return 'not_found'; end if;
 delete from waiter_sessions where waiter_id=i;
 insert into audit_log(who,action,detail) values(auth.uid(),'waiter '||i,'waiter "'||n||'" PIN reset');
 return 'ok';
end $$;

-- Waiter list for the admin: names and on/off only (never anything about open tables).
create or replace function list_waiters()
returns jsonb language plpgsql security definer set search_path=public as $$
begin
 if not is_staff() then return '[]'::jsonb; end if;
 return (select coalesce(jsonb_agg(jsonb_build_object('id',id,'name',name,'active',active) order by name),'[]'::jsonb) from waiters);
end $$;

-- CLOSED tables only, newest first: "Table 5, served and closed by <waiter>".
create or replace function admin_closed_tables(n int default 50)
returns jsonb language plpgsql security definer set search_path=public as $$
begin
 if not is_staff() then return '[]'::jsonb; end if;
 return (select coalesce(jsonb_agg(to_jsonb(t) order by t.closed_at desc),'[]'::jsonb) from (
  select s.id, s.table_label, s.waiter_name, s.opened_at, s.closed_at,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price) order by l.id),'[]'::jsonb)
      from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as lines
  from sittings s where s.status='closed' order by s.closed_at desc limit least(coalesce(n,50),200)) t);
end $$;

-- Who may call what.
revoke all on function waiter_login(text,text), waiter_logout(uuid), waiter_open_table(uuid,text), waiter_tables(uuid),
  waiter_order_step(uuid,int,text), waiter_close_table(uuid,int), guest_join(text), guest_status(uuid),
  guest_send_order(uuid,jsonb), guest_set_pay(uuid,text), staff_add_waiter(text,text,text), staff_set_waiter_active(int,bool,text),
  staff_reset_waiter_pin(int,text,text), list_waiters(), admin_closed_tables(int) from public;
grant execute on function waiter_login(text,text), waiter_logout(uuid), waiter_open_table(uuid,text), waiter_tables(uuid),
  waiter_order_step(uuid,int,text), waiter_close_table(uuid,int), guest_join(text), guest_status(uuid),
  guest_send_order(uuid,jsonb), guest_set_pay(uuid,text) to anon, authenticated;
grant execute on function staff_add_waiter(text,text,text), staff_set_waiter_active(int,bool,text),
  staff_reset_waiter_pin(int,text,text), list_waiters(), admin_closed_tables(int) to authenticated;
