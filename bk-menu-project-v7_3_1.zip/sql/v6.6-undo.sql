-- BK menu v6.6 UNDO: removes the happy hour tables and functions (only them). Run in Supabase > SQL Editor.
drop function if exists staff_save_happy(int,text,int[],int,int,bool,jsonb,text);
drop function if exists staff_set_happy_active(int,bool,text);
drop function if exists staff_delete_happy(int,text);
drop table if exists happy_hour_rules;
drop table if exists happy_hours;
