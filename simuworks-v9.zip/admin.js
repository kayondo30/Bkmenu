// ================================================================
// SIMU WORKS - admin.js  (Stage 3, me only)
// 1. Log in with my Supabase account (email + password).
// 2. Read all bookings (the database checks the login is mine).
// 3. Every change asks for my Action PIN (checked by the database,
//    5 wrong tries = locked 15 minutes).
// ================================================================
(function () {
  var C = window.SIMU;
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); };
  var KEY = "simu-admin-session";
  var session = null, bookings = [], filter = "active", pinCache = null, pinTimer = null;

  var STATUS = C.statuses.concat([{ id: "cancelled", label: "Closed" }]);
  var label = function (id) { var s = STATUS.filter(function (x) { return x.id === id; })[0]; return s ? s.label : id; };

  // ---------- Talking to Supabase ----------
  function api(path, body, auth) {
    var h = { "apikey": C.supabaseKey, "Content-Type": "application/json" };
    if (auth && session) h.Authorization = "Bearer " + session.access_token;
    return fetch(C.supabaseUrl + path, { method: "POST", headers: h, body: JSON.stringify(body || {}) })
      .then(function (r) {
        return r.json().catch(function () { return null; }).then(function (d) {
          if (!r.ok) { var e = new Error((d && (d.message || d.error_description || d.msg)) || "server"); e.status = r.status; throw e; }
          return d;
        });
      }, function () { throw new Error("offline"); });
  }
  function save(s) {
    session = s ? { access_token: s.access_token, refresh_token: s.refresh_token, expires_at: Date.now() + (s.expires_in - 60) * 1000 } : null;
    try { s ? localStorage.setItem(KEY, JSON.stringify(session)) : localStorage.removeItem(KEY); } catch (e) {}
  }
  function fresh() { // make sure the login has not expired
    if (!session) return Promise.reject(new Error("login"));
    if (Date.now() < session.expires_at) return Promise.resolve();
    return api("/auth/v1/token?grant_type=refresh_token", { refresh_token: session.refresh_token })
      .then(save, function () { save(null); throw new Error("login"); });
  }
  function rpc(name, body) {
    return fresh().then(function () { return api("/rest/v1/rpc/" + name, body, true); })
      .catch(function (e) {
        if (e.message === "login" || e.status === 401 || /JWT/i.test(e.message)) { save(null); show("login"); }
        throw e;
      });
  }
  var nice = function (e) {
    return ({ offline: "No internet connection.", not_admin: "This login is not the Simu Works admin.",
      wrong_pin: "Wrong PIN.", locked: "Too many wrong PINs. Locked for 15 minutes.", login: "Please log in again.",
      bad_pin: "The PIN must be 4 to 8 digits." })[e.message] || "Something went wrong. Try again.";
  };

  // ---------- Screens ----------
  function show(v) {
    ["login", "pin", "list"].forEach(function (x) { $("v-" + x).hidden = x !== v; });
    $("logout").hidden = $("refresh").hidden = v === "login";
    if (v === "login") $("login-form").elements.email.value = $("login-form").elements.email.value || C.email;
  }

  // ---------- 1. Log in ----------
  $("login-form").addEventListener("submit", function (ev) {
    ev.preventDefault();
    var f = this.elements, msg = $("login-msg"); msg.textContent = "";
    api("/auth/v1/token?grant_type=password", { email: f.email.value.trim(), password: f.password.value })
      .then(function (s) { save(s); f.password.value = ""; start(); })
      .catch(function (e) { msg.textContent = e.message === "offline" ? nice(e) : "Wrong email or password."; });
  });
  $("logout").addEventListener("click", function () {
    var t = session && session.access_token; save(null); pinCache = null; show("login");
    if (t) fetch(C.supabaseUrl + "/auth/v1/logout", { method: "POST", headers: { apikey: C.supabaseKey, Authorization: "Bearer " + t } }).catch(function () {});
  });
  $("refresh").addEventListener("click", function () { load(); });

  // ---------- 2. PIN ----------
  $("pin-form").addEventListener("submit", function (ev) {
    ev.preventDefault();
    var f = this.elements, msg = $("pin-msg"); msg.textContent = "";
    if (!/^\d{4,8}$/.test(f.pin1.value)) { msg.textContent = nice({ message: "bad_pin" }); return; }
    if (f.pin1.value !== f.pin2.value) { msg.textContent = "The two PINs are not the same."; return; }
    rpc("admin_set_pin", { p_new: f.pin1.value, p_old: null })
      .then(function (r) { if (r !== "ok") throw new Error(r); f.pin1.value = f.pin2.value = ""; show("list"); load(); })
      .catch(function (e) { msg.textContent = nice(e); });
  });

  // Ask for the PIN (remembered for 5 minutes on this screen only).
  function askPin(title) {
    if (pinCache) return Promise.resolve(pinCache);
    return new Promise(function (res, rej) {
      var d = $("pin-dialog"), inp = $("ask-pin");
      $("ask-title").textContent = title; $("ask-msg").textContent = ""; inp.value = "";
      d.showModal(); setTimeout(function () { inp.focus(); }, 50);
      $("ask-form").onsubmit = function (ev) {
        ev.preventDefault();
        if (!/^\d{4,8}$/.test(inp.value)) { $("ask-msg").textContent = "4 to 8 digits."; return; }
        d.close(); res(inp.value);
      };
      $("ask-cancel").onclick = function () { d.close(); rej(new Error("cancel")); };
    });
  }
  function rememberPin(p) {
    pinCache = p; clearTimeout(pinTimer);
    pinTimer = setTimeout(function () { pinCache = null; }, 5 * 60 * 1000);
  }

  // ---------- 3. Bookings ----------
  var groups = [
    { id: "active", label: "Open", test: function (b) { return b.status !== "live" && b.status !== "cancelled"; } },
    { id: "received", label: "Received" }, { id: "quoted", label: "Quoted" },
    { id: "in_progress", label: "In progress" }, { id: "live", label: "Live" },
    { id: "cancelled", label: "Closed" }, { id: "all", label: "All", test: function () { return true; } }
  ];
  var inGroup = function (g, b) { return g.test ? g.test(b) : b.status === g.id; };

  function load() {
    $("list-msg").textContent = "";
    $("list").innerHTML = '<p class="muted">Loading…</p>';
    rpc("admin_list_bookings").then(function (rows) { bookings = rows || []; draw(); })
      .catch(function (e) { $("list").innerHTML = ""; $("list-msg").textContent = nice(e); });
  }

  function draw() {
    $("chips").innerHTML = groups.map(function (g) {
      var n = bookings.filter(function (b) { return inGroup(g, b); }).length;
      return '<button type="button" role="tab" class="chip' + (g.id === filter ? " on" : "") + '" data-g="' + g.id + '">' +
        esc(g.label) + " <span>" + n + "</span></button>";
    }).join("");
    var g = groups.filter(function (x) { return x.id === filter; })[0];
    var rows = bookings.filter(function (b) { return inGroup(g, b); });
    if (!rows.length) { $("list").innerHTML = '<p class="muted empty">No bookings here.</p>'; return; }
    $("list").innerHTML = rows.map(card).join("");
  }

  function card(b) {
    var when = new Date(b.created_at).toLocaleString("en-GB", { day: "numeric", month: "short", hour: "2-digit", minute: "2-digit" });
    var hello = "Hello " + b.name + ", this is Simu Works about your booking " + b.code + " for " + b.business + ".";
    return '<article class="bk" data-id="' + b.id + '">' +
      '<div class="bk-top"><div><h3>' + esc(b.business) + '</h3><p class="muted">' + esc(b.code) + " · " + esc(b.package) + " · " + esc(when) + "</p></div>" +
      '<span class="tag tag-' + esc(b.status) + '">' + esc(label(b.status)) + "</span></div>" +
      "<p><b>" + esc(b.name) + "</b> · +" + esc(b.phone) + "</p>" +
      (b.note ? '<p class="bk-note">' + esc(b.note) + "</p>" : "") +
      '<div class="bk-actions"><a class="btn btn-wa small" target="_blank" rel="noopener" href="https://wa.me/' + esc(b.phone) +
        "?text=" + encodeURIComponent(hello) + '">WhatsApp</a><a class="btn btn-ghost small" href="tel:+' + esc(b.phone) + '">Call</a></div>' +
      '<div class="bk-edit"><label>Status<select class="f-status">' +
        STATUS.map(function (s) { return '<option value="' + s.id + '"' + (s.id === b.status ? " selected" : "") + ">" + esc(s.label) + "</option>"; }).join("") +
      '</select></label><label>Note the client sees <span class="opt">Optional</span><textarea class="f-note" rows="2" maxlength="300">' +
        esc(b.client_note || "") + "</textarea></label>" +
      '<p class="form-msg f-msg" role="alert"></p>' +
      '<div class="bk-actions"><button class="btn btn-main small f-save" type="button">Save</button>' +
      '<button class="btn btn-ghost small danger f-del" type="button">Delete</button></div></div></article>';
  }

  // Run a change that needs the PIN; ask again if the PIN was wrong.
  function withPin(title, run, msgEl) {
    return askPin(title).then(function (pin) {
      return run(pin).then(function (r) {
        if (r === "ok") { rememberPin(pin); return r; }
        pinCache = null;
        msgEl.textContent = nice({ message: r });
        throw new Error(r);
      });
    });
  }

  $("chips").addEventListener("click", function (ev) {
    var b = ev.target.closest(".chip"); if (b) { filter = b.dataset.g; draw(); }
  });
  $("list").addEventListener("click", function (ev) {
    var el = ev.target, art = el.closest(".bk"); if (!art) return;
    var id = Number(art.dataset.id), msg = art.querySelector(".f-msg");
    if (el.classList.contains("f-save")) {
      msg.textContent = "";
      var status = art.querySelector(".f-status").value, note = art.querySelector(".f-note").value;
      el.disabled = true;
      withPin("Save this change?", function (pin) {
        return rpc("admin_update_booking", { p_id: id, p_status: status, p_client_note: note, p_pin: pin });
      }, msg).then(function () {
        var b = bookings.filter(function (x) { return x.id === id; })[0];
        b.status = status; b.client_note = note.trim() || null; draw();
      }).catch(function (e) { if (e.message !== "cancel" && !msg.textContent) msg.textContent = nice(e); })
        .then(function () { el.disabled = false; });
    }
    if (el.classList.contains("f-del")) {
      msg.textContent = "";
      if (!confirm("Delete this booking for good? This cannot be undone.")) return;
      pinCache = null; // always ask the PIN to delete
      withPin("Delete for good?", function (pin) {
        return rpc("admin_delete_booking", { p_id: id, p_pin: pin });
      }, msg).then(function () {
        bookings = bookings.filter(function (x) { return x.id !== id; }); draw();
      }).catch(function (e) { if (e.message !== "cancel" && !msg.textContent) msg.textContent = nice(e); });
    }
  });

  // ---------- Start ----------
  function start() {
    rpc("admin_has_pin").then(function (has) {
      if (has) { show("list"); load(); } else show("pin");
    }).catch(function (e) {
      if (session) { show("login"); $("login-msg").textContent = nice(e); }
    });
  }
  try { session = JSON.parse(localStorage.getItem(KEY)); } catch (e) { session = null; }
  if (session) start(); else show("login");
})();
