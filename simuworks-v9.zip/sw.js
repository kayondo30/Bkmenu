// SIMU WORKS - sw.js (service worker)
// It lets phones install the site as an app. It does NOT store old
// copies of the site, so every upload to Cloudflare shows at once.
self.addEventListener("install", function () { self.skipWaiting(); });
self.addEventListener("activate", function (e) { e.waitUntil(self.clients.claim()); });
self.addEventListener("fetch", function () { /* always use the network */ });
