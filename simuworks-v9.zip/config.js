// ================================================================
// SIMU WORKS - config.js
// ALL wording, numbers and prices live here. To change the site,
// change this file only, then upload the site again.
// ================================================================
window.SIMU = {
  version: 9,   // raise by 1 at every change (rule in the prompt file)
  name: "Simu Works",
  tagline: "Phone-first menus and apps for Ugandan businesses.",
  intro: "Your customers scan a QR code and see your menu on their phone. You change a price in 10 seconds from your own phone, so you never reprint a menu.",
  siteUrl: "https://simuworks.pages.dev",

  // Supabase (Stage 2 bookings). The publishable key is SAFE to be here:
  // the database only lets it add a booking or check one with code + phone.
  // NEVER put the secret / service_role key or the database password here.
  supabaseUrl: "https://srlksusvcvqrgdgrcasd.supabase.co",
  supabaseKey: "sb_publishable_7fQN6dURrXsoLP07UgakgA_sdpLZ0c-",

  // Contacts. Numbers are written twice: "show" is what people read,
  // "link" is digits only with 256 in front (no + and no spaces).
  whatsappMain:   { show: "+256 785 104 465", link: "256785104465" },
  whatsappSecond: { show: "+256 705 814 221", link: "256705814221" },
  email: "kayondo30@gmail.com",
  whatsappHello: "Hello Simu Works, I would like to know more about a digital menu for my business.",

  // What a business gets (Home section)
  benefits: [
    { title: "Change prices yourself", text: "A private staff page on your phone. Edit a price or mark an item sold out, and the menu updates for every customer at once." },
    { title: "No app to install", text: "Customers scan your QR code and the menu opens in their phone's browser. It works on cheap phones and slow data." },
    { title: "Your name, your look", text: "Your logo, your colours and your items. It feels like your own menu, not a template." }
  ],

  // Work (showcase)
  work: [
    { name: "BK menu", type: "Demo restaurant menu", text: "Our working demo: a live menu with a staff page for prices, specials, two languages and a dollar switch. Your menu can work the same way.", link: "https://bkmenu-b5g.pages.dev/", button: "Try the demo menu" },
    // No link = shows "In progress" instead of a button. Add link + button when it is ready to show.
    { name: "FHG FX Signals", type: "Our own app, in progress", text: "A phone-first app for forex traders: trading signals and alerts in a calm, easy-to-read design. Still under construction." }
  ],

  // Prices (UGX). "highlight: true" marks the package we recommend.
  packages: [
    { name: "Basic", price: 600000, note: "one-time setup", items: ["Your menu and logo", "One language", "Staff page to change prices", "QR code"] },
    { name: "Standard", price: 1000000, note: "one-time setup", highlight: true, items: ["Everything in Basic", "Two languages", "Specials and messages", "Celebrations", "Dollar price switch"] },
    { name: "Premium", price: 1500000, note: "one-time setup", items: ["Everything in Standard", "Photos of your items", "Your own web address", "Designed QR table cards", "Staff training"] }
  ],
  care: { name: "Monthly care", price: 50000, per: "a month", yearly: 500000, text: "Optional, and recommended. Changes on request, keeping it running, and fixes." },
  offer: "Launch offer: the first 3 businesses get 30% off in return for a short review and permission to show their menu.",

  // Booking status names, in order (the database uses the left side)
  statuses: [
    { id: "received",    label: "Received",    text: "We have your request and will contact you soon." },
    { id: "quoted",      label: "Quoted",      text: "We have sent you a price and plan." },
    { id: "in_progress", label: "In progress", text: "We are building your menu." },
    { id: "live",        label: "Live",        text: "Your menu is live for customers." }
  ],

  // How it works (a real sequence)
  steps: [
    { title: "Chat on WhatsApp", text: "Tell us your business and what you need. We agree on a package." },
    { title: "Pay 50% to start", text: "By mobile money, with a short written agreement." },
    { title: "We build and you check", text: "You see your menu on your phone before anyone else does." },
    { title: "Pay 50% when live", text: "Your QR code goes on the tables and you change prices yourself." }
  ]
};
