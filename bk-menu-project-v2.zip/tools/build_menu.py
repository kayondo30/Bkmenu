import re,json,base64,sys
from bs4 import BeautifulSoup
h=open('frame.html',encoding='utf8').read()
s=BeautifulSoup(h,'html.parser')
open('site/cover.jpg','wb').write(base64.b64decode(s.find('img',id='cv')['src'].split(',',1)[1]))
pages={};order=[]
for a in s.select('article.pg'):
    for sec in a.select('section'):
        g=sec.get('data-g',a['data-g'])
        if g not in pages: pages[g]={'g':g,'pg':[],'sections':[]};order.append(g)
        if a['data-n'] not in pages[g]['pg']: pages[g]['pg'].append(a['data-n'])
        h2=sec.find('h2'); ti=h2.span.extract().get_text(strip=True) if h2.span else ''
        note=sec.select_one('.note'); items=[]
        for it in sec.select('.it'):
            n=it.select_one('.n'); em=n.em.extract().get_text(strip=True) if n.em else ''
            d=it.select_one('.d'); dt=it.select_one('.dt'); p=it.select_one('.p')
            items.append({'n':n.get_text(strip=True),'v':em,'d':d.get_text(strip=True) if d else '','t':dt.get_text(strip=True) if dt else '','p':p.get_text(strip=True) if p else ''})
        pages[g]['sections'].append({'t':h2.get_text(strip=True).title().replace('&','&'),'ti':ti,'note':note.get_text(strip=True) if note else '','items':items})
for g in pages.values():
    for sec in g['sections']:
        for i in sec['items']:
            if i['n']=='Bonfire Whisky': i['v']='200ml'
json.dump({'v':1,'cur':'UGX','pages':[pages[g] for g in order]},open('site/menu.json','w',encoding='utf8'),ensure_ascii=False,separators=(',',':'))
for g in order: print(g,pages[g]['pg'],[(x['t'],len(x['items'])) for x in pages[g]['sections']])
from PIL import Image,ImageDraw,ImageFont
for z in (192,512):
    im=Image.new('RGB',(z,z),'#121110');d=ImageDraw.Draw(im)
    try: f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSerif-Bold.ttf',int(z*.42))
    except: f=ImageFont.load_default()
    d.text((z/2,z/2),'BK',font=f,fill='#D4A94B',anchor='mm');im.save(f'site/icon-{z}.png')
def L(c):
    c=[int(c[i:i+2],16)/255 for i in(1,3,5)];c=[x/12.92 if x<=.03928 else((x+.055)/1.055)**2.4 for x in c];return .2126*c[0]+.7152*c[1]+.0722*c[2]
def cr(a,b):
    x,y=sorted([L(a),L(b)],reverse=True);return round((x+.05)/(y+.05),1)
for n,a,b in[('gold dark','#D4A94B','#121110'),('red dark','#E8776A','#121110'),('green dark','#6FBF8B','#121110'),('gold light','#7A5710','#F7F3EA'),('red light','#A32A1F','#F7F3EA'),('green light','#1E6B3F','#F7F3EA'),('muted dark','#A9A196','#121110'),('muted light','#5E574C','#F7F3EA')]:print(n,cr(a,b))
