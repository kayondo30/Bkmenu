# BK Beverage Menu

## v2 (2026-10-25)
Staff control: admin.html (login, edit price, Sold out, Hold, Action PIN, notice banner, recent changes), sql/v2.sql, config.js.
Set up: 1) Supabase new project. 2) Run sql/v2.sql, reply "done". 3) Authentication > Users: add owner and staff. 4) Run the last commented line of v2.sql with their emails. 5) Put Project URL and anon key in config.js, upload site zip. 6) Open /admin.html, log in, set the PIN once.
Until config.js is filled, the menu runs from menu.json and admin.html says "not set up yet".
Left for v3: today tiles, staff list screen, scheduled release, specials, share, push alerts, QR.

## v1.1 (2026-10-25)
Real BK logo: app icons (192, 512) and splash screen. Cache name bk-menu-v1.1.

## v1 (2026-10-25)
Public bilingual (English / Tigrinya / both) beverage menu, PWA, works offline.
Built features: F01 F02 F03 F04 F06 F07 F08 F70 F50 F55 (9 pages with prev/next and phone Back) F90 F91 (menu.json) F94 (print/PDF) F95 (chips and dots).
Not in v1: QR code (needs the live address), SQL (menu is static until v2), staff features (v2), extras (v3).
Edit prices now: change menu.json, then raise the version in sw.js (cache name) and upload the site zip.
Rebuild data from the old menu: tools/build_menu.py.
Host: Cloudflare Pages, upload the site zip contents. _headers keeps sw.js, index.html and menu.json fresh.
