// Fill in after running sql/v2.sql. Leave empty to run from menu.json.
window.BK={url:'',key:''};
