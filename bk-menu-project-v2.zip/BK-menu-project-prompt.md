# BK Beverage Menu - project prompt (v2, 2026-10-25)
Uses the Reusable Feature Library (kept separate). Locked answers: admin = owner + one staff; customers never log in; dark + gold with light/dark toggle; offline yes; host Cloudflare Pages + Supabase; Bonfire Whisky shown as 200ml at 10,000.
Languages: English, Tigrinya, both (default both). Currency UGX. Brand line: DRINK - RELAX - ENJOY.
Build order: v1 menu (DONE) / v2 F20 F21 F92 F93 F28 F29 F36 F27 F39-lite = Hold (BUILT lean; tiles F35 and staff list F37 not yet) (menu moved to Supabase, SQL in migration file, wait for my "done") / v3 F15 F17 F16 F51 F45 F46 and QR code.
Rules: number every version, change sw.js cache name each time, three files each time, test sitting (F80) after builds, never replace live logo or icon names.
Version: v1.1 (real logo from sc.png in icons and splash; icon file names stay the same, links carry ?v=2).
Known: cover.jpg is from the original menu; Tigrinya text taken as given, not re-checked.
