// ================================================================
// SIMU WORKS - app.js
// Reads config.js and fills the page. You normally never edit this.
// ================================================================
(function () {
  var C = window.SIMU;
  var ugx = function (n) { return "UGX " + Number(n).toLocaleString("en-US"); };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); };
  var get = function (path) { return path.split(".").reduce(function (o, k) { return o && o[k]; }, C); };
  var waLink = function (which) {
    var n = which === "second" ? C.whatsappSecond : C.whatsappMain;
    return "https://wa.me/" + n.link + "?text=" + encodeURIComponent(C.whatsappHello);
  };

  // 1. Simple texts
  document.querySelectorAll("[data-text]").forEach(function (el) {
    var v = get(el.dataset.text); if (v) el.textContent = v;
  });

  // 2. WhatsApp, call and email links
  document.querySelectorAll("[data-wa]").forEach(function (a) {
    a.href = waLink(a.dataset.wa); a.target = "_blank"; a.rel = "noopener";
  });
  document.querySelectorAll("[data-call]").forEach(function (a) {
    var n = a.dataset.call === "second" ? C.whatsappSecond : C.whatsappMain;
    a.href = "tel:+" + n.link;
  });
  document.querySelectorAll("[data-mail]").forEach(function (a) {
    a.href = "mailto:" + C.email + "?subject=" + encodeURIComponent("Enquiry from the website");
  });

  // 3. Benefits
  document.querySelector(".benefits").innerHTML = C.benefits.map(function (b) {
    return '<div class="benefit"><h3>' + esc(b.title) + "</h3><p>" + esc(b.text) + "</p></div>";
  }).join("");

  // 4. Work
  document.querySelector(".work-list").innerHTML = C.work.map(function (w) {
    return '<article class="work"><div><p class="work-type">' + esc(w.type) + "</p><h3>" + esc(w.name) +
      "</h3><p>" + esc(w.text) + '</p></div>' + (w.link
        ? '<a class="btn btn-ghost" href="' + esc(w.link) + '" target="_blank" rel="noopener">' + esc(w.button || "Open it") + '</a>'
        : '<p class="soon">In progress</p>') + '</article>';
  }).join("");

  // 5. Prices
  document.querySelector(".packages").innerHTML = C.packages.map(function (p) {
    return '<article class="pack' + (p.highlight ? " pick" : "") + '">' +
      (p.highlight ? '<p class="pick-tag">Recommended</p>' : "") +
      "<h3>" + esc(p.name) + '</h3><p class="amount">' + ugx(p.price) + '</p><p class="note">' + esc(p.note) +
      "</p><ul>" + p.items.map(function (i) { return "<li>" + esc(i) + "</li>"; }).join("") + "</ul>" +
      '<a class="btn btn-ghost pack-book" href="#book" data-pkg="' + esc(p.name) + '">Book ' + esc(p.name) + "</a></article>";
  }).join("");
  document.querySelector(".care").innerHTML =
    "<div><h3>" + esc(C.care.name) + "</h3><p>" + esc(C.care.text) + '</p></div><p class="care-price"><b>' +
    ugx(C.care.price) + "</b> " + esc(C.care.per) + "<br><span>or " + ugx(C.care.yearly) + " a year</span></p>";

  // 6. Steps
  document.querySelector(".steps").innerHTML = C.steps.map(function (s) {
    return "<li><h3>" + esc(s.title) + "</h3><p>" + esc(s.text) + "</p></li>";
  }).join("");

  // 7. Footer year
  document.getElementById("year").textContent = "© " + new Date().getFullYear() + "  ·  v" + C.version;

  // 8. Light / dark switch (remembers the choice on this phone)
  document.getElementById("theme").addEventListener("click", function () {
    var root = document.documentElement;
    var dark = root.dataset.theme ? root.dataset.theme === "dark" : matchMedia("(prefers-color-scheme: dark)").matches;
    root.dataset.theme = dark ? "light" : "dark";
    try { localStorage.setItem("simu-theme", root.dataset.theme); } catch (e) {}
  });
})();
