// ================================================================
// SIMU WORKS - bookings.js  (Stage 2)
// Talks to Supabase through two "doors" only:
//   create_booking -> saves a request, returns a code like SW-7KQ2M
//   check_booking  -> shows ONE booking, only with code + same phone
// ================================================================
(function () {
  var C = window.SIMU;
  var $ = function (id) { return document.getElementById(id); };
  var esc = function (s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); };

  // Call a database door. Returns the answer, or throws a short reason.
  function door(name, body) {
    return fetch(C.supabaseUrl + "/rest/v1/rpc/" + name, {
      method: "POST",
      headers: { "apikey": C.supabaseKey, "Content-Type": "application/json" },
      body: JSON.stringify(body)
    }).then(function (r) {
      return r.json().catch(function () { return null; }).then(function (data) {
        if (!r.ok) throw new Error((data && data.message) || "server");
        return data;
      });
    }, function () { throw new Error("offline"); });
  }

  var reasons = {
    bad_phone: "That phone number does not look right. Use a number like 0785 104 465.",
    too_many: "This phone has already sent 3 requests today. Message us on WhatsApp instead.",
    busy: "We are receiving many requests right now. Please try again in an hour, or message us on WhatsApp.",
    offline: "No internet connection. Check your data or Wi-Fi and try again.",
    server: "Something went wrong on our side. Please try again, or message us on WhatsApp."
  };
  var reason = function (e) { return reasons[e.message] || reasons.server; };

  // Phone: keep digits and a leading +, need at least 9 digits.
  var phoneOk = function (p) { return p.replace(/\D/g, "").length >= 9; };

  // ---------- Package list (filled from config.js) ----------
  var sel = $("book-package");
  var names = C.packages.map(function (p) { return p.name; }).concat([C.care.name, "Not sure yet"]);
  sel.innerHTML = names.map(function (n) {
    var p = C.packages.filter(function (x) { return x.name === n; })[0];
    var label = p ? n + " (UGX " + Number(p.price).toLocaleString("en-US") + ")" : n;
    return '<option value="' + esc(n) + '">' + esc(label) + "</option>";
  }).join("");
  var rec = C.packages.filter(function (p) { return p.highlight; })[0];
  if (rec) sel.value = rec.name;

  // "Book Standard" buttons on the price cards choose that package.
  document.querySelectorAll("[data-pkg]").forEach(function (a) {
    a.addEventListener("click", function () { sel.value = a.dataset.pkg; });
  });

  // ---------- Book a call ----------
  var form = $("book-form"), msg = $("book-msg"), btn = $("book-btn");
  form.addEventListener("submit", function (ev) {
    ev.preventDefault();
    msg.textContent = "";
    var f = form.elements, bad = null;
    [f.name, f.business, f.phone].forEach(function (el) { el.classList.remove("invalid"); });
    if (f.name.value.trim().length < 2) bad = bad || f.name;
    if (f.business.value.trim().length < 2) bad = bad || f.business;
    if (!phoneOk(f.phone.value)) bad = bad || f.phone;
    if (bad) {
      bad.classList.add("invalid"); bad.focus();
      msg.textContent = bad === f.phone ? reasons.bad_phone : "Please fill in your name and business name.";
      return;
    }
    btn.disabled = true; btn.textContent = "Sending…";
    door("create_booking", {
      p_package: sel.value, p_name: f.name.value, p_business: f.business.value,
      p_phone: f.phone.value, p_note: f.note.value
    }).then(function (code) {
      var wa = "https://wa.me/" + C.whatsappMain.link + "?text=" + encodeURIComponent(
        "Hello Simu Works, I just sent a booking request. Code: " + code + ". Business: " +
        f.business.value.trim() + ". Package: " + sel.value + ".");
      $("book-done").innerHTML =
        "<h3>Request received</h3><p>Your booking code is</p>" +
        '<p class="code-big" id="the-code">' + esc(code) + "</p>" +
        '<p class="muted">Save this code. With your phone number, it lets you check your booking below.</p>' +
        '<div class="buttons"><a class="btn btn-wa" target="_blank" rel="noopener" href="' + wa +
        '">Send it to us on WhatsApp</a><button class="btn btn-ghost" type="button" id="copy-code">Copy code</button></div>';
      form.hidden = true; $("book-done").hidden = false;
      $("book-done").scrollIntoView({ behavior: "smooth", block: "start" });
      $("copy-code").addEventListener("click", function () {
        var b = this;
        (navigator.clipboard ? navigator.clipboard.writeText(code) : Promise.reject()).then(
          function () { b.textContent = "Copied"; },
          function () { b.textContent = "Press and hold the code to copy"; });
      });
      // Fill the check form, so they can try it straight away.
      var cf = $("check-form").elements; cf.code.value = code; cf.phone.value = f.phone.value;
    }).catch(function (e) {
      msg.textContent = reason(e);
    }).then(function () { btn.disabled = false; btn.textContent = "Send booking request"; });
  });

  // ---------- Check a booking ----------
  var cform = $("check-form"), cmsg = $("check-msg"), cbtn = $("check-btn"), out = $("check-result");
  var cleanCode = function (s) {
    s = s.toUpperCase().replace(/[^A-Z0-9]/g, "");
    if (s.indexOf("SW") === 0) s = s.slice(2);
    return "SW-" + s;
  };
  cform.addEventListener("submit", function (ev) {
    ev.preventDefault();
    cmsg.textContent = ""; out.hidden = true;
    var f = cform.elements, code = cleanCode(f.code.value);
    if (code.length !== 8) { cmsg.textContent = "A booking code looks like SW-7KQ2M (5 letters or numbers after SW-)."; f.code.focus(); return; }
    if (!phoneOk(f.phone.value)) { cmsg.textContent = reasons.bad_phone; f.phone.focus(); return; }
    cbtn.disabled = true; cbtn.textContent = "Checking…";
    door("check_booking", { p_code: code, p_phone: f.phone.value }).then(function (rows) {
      var b = rows && rows[0];
      if (!b) { cmsg.textContent = "No booking matches this code and phone number. Check both and try again."; return; }
      var at = C.statuses.map(function (s) { return s.id; }).indexOf(b.status);
      var when = new Date(b.created_at).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
      var track = b.status === "cancelled"
        ? '<p class="client-note">This request was closed. Message us on WhatsApp if you would like to start again.</p>'
        : '<ol class="track">' + C.statuses.map(function (s, i) {
            return '<li class="' + (i < at ? "passed" : i === at ? "now" : "") + '"><b>' + esc(s.label) + "</b>" +
              (i === at ? "<span>" + esc(s.text) + "</span>" : "") + "</li>";
          }).join("") + "</ol>";
      out.innerHTML = "<h3>" + esc(b.business) + "</h3>" +
        '<p class="muted">' + esc(b.code) + ", " + esc(b.package) + ", sent " + esc(when) + "</p>" +
        track + (b.client_note ? '<p class="client-note"><b>Note from Simu Works:</b> ' + esc(b.client_note) + "</p>" : "");
      out.hidden = false;
    }).catch(function (e) {
      cmsg.textContent = reason(e);
    }).then(function () { cbtn.disabled = false; cbtn.textContent = "Check booking"; });
  });
})();
