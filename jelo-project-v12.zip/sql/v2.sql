-- Menu v2 migration for JeLo's Cafe (own Supabase project). Run once in Supabase > SQL Editor, then reply "done".
create table if not exists staff(user_id uuid primary key references auth.users on delete cascade, role text default 'staff', pin_hash text, tries int default 0, locked_until timestamptz);
create table if not exists menu_items(id serial primary key, grp text, sec text, sec_ti text, note text, name text, variant text default '', d text default '', t text default '', price text default '', sold_out bool default false, hidden bool default false, sort int);
create table if not exists settings(key text primary key, value text);
create table if not exists audit_log(id serial primary key, at timestamptz default now(), who uuid, action text, detail text);
alter table staff enable row level security; alter table menu_items enable row level security; alter table settings enable row level security; alter table audit_log enable row level security;
create or replace function is_staff() returns bool language sql security definer stable as $$ select exists(select 1 from staff where user_id=auth.uid()) $$;
drop policy if exists mi_read on menu_items; create policy mi_read on menu_items for select using (not hidden or is_staff());
drop policy if exists st_read on settings; create policy st_read on settings for select using (true);
drop policy if exists al_read on audit_log; create policy al_read on audit_log for select using (is_staff());
create or replace function chk_pin(pin text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare s staff%rowtype; begin
 select * into s from staff where user_id=auth.uid(); if not found then return 'denied'; end if;
 if s.pin_hash is null then return 'not_set'; end if;
 if s.locked_until>now() then return 'locked'; end if;
 if s.pin_hash<>crypt(pin,s.pin_hash) then
  update staff set locked_until=case when tries+1>=3 then now()+interval '15 minutes' end, tries=case when tries+1>=3 then 0 else tries+1 end where user_id=auth.uid(); return 'bad_pin'; end if;
 update staff set tries=0 where user_id=auth.uid(); return 'ok'; end $$;
create or replace function set_pin(p text) returns text language plpgsql security definer set search_path=public,extensions as $$
begin if not is_staff() then return 'denied'; end if; if length(p)<4 then return 'invalid'; end if;
 if exists(select 1 from staff where user_id=auth.uid() and pin_hash is not null) then return 'reauth'; end if;
 update staff set pin_hash=crypt(p,gen_salt('bf')),tries=0 where user_id=auth.uid(); return 'ok'; end $$;
create or replace function staff_update_item(i int,p text,sold bool,hid bool,pin text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; begin w:=chk_pin(pin); if w<>'ok' then return w; end if;
 update menu_items set price=p,sold_out=sold,hidden=hid where id=i;
 insert into audit_log(who,action,detail) values(auth.uid(),'item '||i,'price '||p||', sold out '||sold||', hold '||hid); return 'ok'; end $$;
create or replace function set_banner(txt text,pin text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; begin w:=chk_pin(pin); if w<>'ok' then return w; end if;
 insert into settings values('banner',txt) on conflict (key) do update set value=excluded.value;
 insert into audit_log(who,action,detail) values(auth.uid(),'banner',txt); return 'ok'; end $$;
insert into menu_items(grp,sec,sec_ti,note,name,variant,d,t,price,sort) select * from (values
('Coffee','Espresso & Milk Coffees','','','Espresso','Single / Double','Boiling water is forced under pressure through finely ground coffee beans.','','7,000 / 9,000',1),
('Coffee','Espresso & Milk Coffees','','','Macchiato','Single / Double','An espresso based coffee topped with milk foam.','','8,000 / 10,000',2),
('Coffee','Espresso & Milk Coffees','','','Cappuccino','Single / Double','An espresso based coffee prepared with well steamed milk.','','10,000 / 12,000',3),
('Coffee','Espresso & Milk Coffees','','','Caffe Latte','Single / Double','Freshly well brewed espresso coffee and less foam of steamed milk.','','8,000 / 10,000',4),
('Coffee','Espresso & Milk Coffees','','','Mocha','Single / Double','Chocolate sauce or drinking chocolate, espresso shot and well steamed milk with less foam.','','10,000 / 12,000',5),
('Coffee','Espresso & Milk Coffees','','','Vanilla Latte','','Freshly well brewed espresso coffee and less foam of steamed milk and vanilla syrup.','','13,000',6),
('Coffee','Espresso & Milk Coffees','','','Cortado','','Freshly well brewed espresso coffee with steamed milk.','','10,000',7),
('Coffee','Espresso & Milk Coffees','','','Lungo','','Freshly longer brewed espresso coffee.','','10,000',8),
('Coffee','Espresso & Milk Coffees','','','Affogato','','Freshly well brewed espresso coffee and vanilla ice cream.','','15,000',9),
('Coffee','Brewed Coffee','','','Black Coffee','','Freshly brewed coffee and well steamed water served with sugar or honey.','','9,000',10),
('Coffee','Brewed Coffee','','','African Coffee','','Freshly brewed coffee and well prepared milk served with sugar or honey.','','12,000',11),
('Coffee','Hot Chocolate','','','Hot Chocolate','','Whipped cream, well steamed milk with less foam and drinking chocolate or chocolate sauce.','','12,000',12),
('Tea','Teas','','','African Tea','','Well prepared hot milk with or without spices, Ugandan tea leaves served with sugar or honey.','','10,000',13),
('Tea','Teas','','','Black Tea','','Well prepared hot water with or without spices, Ugandan tea leaves served with sugar or honey.','','7,000',14),
('Tea','Teas','','','Lemon Tea','','Hot water with lemon served with honey.','','10,000',15),
('Tea','Teas','','','Hibiscus Tea','','Hot water with hibiscus served with honey.','','8,000',16),
('Tea','Teas','','','Ginger Tea','','Hot water with ginger served with honey.','','8,000',17),
('Tea','Teas','','','Mint Tea','','Hot water with mint served with honey.','','10,000',18),
('Tea','Dawa Teas','','','Classic Dawa Tea','','Honey, lemon, black pepper, ginger and hot water.','','10,000',19),
('Tea','Dawa Teas','','','Cinnamon Garlic Dawa Tea','','Honey, lemon, black pepper, garlic, cinnamon and hot water.','','12,000',20),
('Tea','Dawa Teas','','','Mint Dawa Tea','','Mix of fresh ginger, fresh mint and lemon served with honey.','','10,000',21),
('Iced','Iced Coffee','','','Iced Americano','','Well iced water with freshly brewed coffee served with sugar or honey.','','15,000',22),
('Iced','Iced Coffee','','','Iced Black Coffee','','Well iced water with freshly brewed coffee served with sugar or honey.','','15,000',23),
('Iced','Iced Coffee','','','Iced Cafe Latte','','Freshly well brewed espresso coffee and foam of steamed milk, with a flavour of choice and ice cubes.','','16,000',24),
('Iced','Iced Coffee','','','Iced Mocha','','Chocolate sauce or drinking chocolate, espresso shot and well steamed milk with less foam and ice cubes.','','16,000',25),
('Iced','Iced Coffee','','','Iced Chocolate','','Whipped cream, well steamed milk with less foam, drinking chocolate and ice cubes.','','17,000',26),
('Iced','Iced Tea','','','Iced Lemon Tea','','Boiled water with lemon and honey, served chilled with ice cubes.','','17,000',27),
('Iced','Iced Tea','','','Iced Pineapple Tea','','Boiled water with pineapple cubes and honey, served chilled with ice cubes.','','17,000',28),
('Juices','Pure Juices','','','Pure Apple','','A blend of pure apple fruit juice and a dash of water.','','14,000',29),
('Juices','Pure Juices','','','Pure Orange','','A blend of pure orange fruit juice and water.','','14,000',30),
('Juices','Pure Juices','','','Passion Juice','','A blend of pure passion fruit juice and water.','','10,000',31),
('Juices','Pure Juices','','','Water Melon Juice','','Pure watermelon fruit juice and water.','','10,000',32),
('Juices','Pure Juices','','','Pineapple Juice','','','','13,000',33),
('Juices','Pure Juices','','','Mango Juice','','','','10,000',34),
('Juices','Pure Juices','','','Lemon Juice','','','','10,000',35),
('Juices','Pure Juices','','','Carrot Juice','','','','10,000',36),
('Juices','Pure Juices','','','Kiwi Juice','','','','16,000',37),
('Juices','Pure Juices','','','Hibiscus Juice','','A quality blend of hibiscus and water.','','10,000',38),
('Juices','Blends & Mixes','','','Mango Blast','','A blend of pure mango fruit juice and a dash of milk or ice cream.','','15,000',39),
('Juices','Blends & Mixes','','','Passion Mix','','A quality blend of passion, mango, ginger and lemon.','','13,000',40),
('Juices','Blends & Mixes','','','Beetroot Mix','','Beetroot, ginger, watermelon and passion.','','14,000',41),
('Juices','Blends & Mixes','','','Cocktail Juice','','A blend of pure orange, apple, pineapple and passion fruit juices.','','16,000',42),
('Juices','Blends & Mixes','','','Red Rush','','','','16,000',43),
('Shakes & Smoothies','Milkshakes','','','Vanilla Milkshake','','A blend of premium vanilla ice cream and milk with a garnish of syrup.','','20,000',44),
('Shakes & Smoothies','Milkshakes','','','Strawberry Milkshake','','A blend of premium strawberry ice cream and milk with a garnish of syrup.','','20,000',45),
('Shakes & Smoothies','Milkshakes','','','Chocolate Milkshake','','A blend of premium chocolate ice cream and milk with a garnish of syrup.','','20,000',46),
('Shakes & Smoothies','Milkshakes','','','Oreo Milkshake','','A blend of premium vanilla ice cream, milk and Oreo cookies with a garnish of syrup.','','20,000',47),
('Shakes & Smoothies','Milkshakes','','','Caramel Milkshake','','A blend of premium caramel ice cream with milk and chocolate sauce.','','20,000',48),
('Shakes & Smoothies','Milkshakes','','','Mocha Milkshake','','A blend of premium vanilla ice cream with coffee (espresso) and chocolate sauce.','','20,000',49),
('Shakes & Smoothies','Milkshakes','','','Banana Milkshake','','A blend of vanilla ice cream and caramel syrup.','','20,000',50),
('Shakes & Smoothies','Milkshakes','','','Mango Milkshake','','A blend of ice cream, mangoes, milk and a garnish of syrup.','','20,000',51),
('Shakes & Smoothies','Milkshakes','','','Tropical Milkshake','','A blend of ice cream, banana, mangoes, passion and a garnish of syrup.','','20,000',52),
('Shakes & Smoothies','Smoothies','','A smoothie is a thick, cold drink made from fruit and often yoghurt or ice cream, mixed together until smooth.','Vanilla Smoothie','','A blend of yoghurt with vanilla ice cream and a garnish of syrup.','','25,000',53),
('Shakes & Smoothies','Smoothies','','A smoothie is a thick, cold drink made from fruit and often yoghurt or ice cream, mixed together until smooth.','Strawberry Smoothie','','A blend of yoghurt with ice cream and fresh strawberries.','','25,000',54),
('Shakes & Smoothies','Smoothies','','A smoothie is a thick, cold drink made from fruit and often yoghurt or ice cream, mixed together until smooth.','Oreo Smoothie','','A blend of yoghurt with vanilla ice cream and Oreo cookies.','','25,000',55),
('Shakes & Smoothies','Smoothies','','A smoothie is a thick, cold drink made from fruit and often yoghurt or ice cream, mixed together until smooth.','Mango Smoothie','','A blend of yoghurt with vanilla ice cream and mango juice.','','25,000',56),
('Shakes & Smoothies','Smoothies','','A smoothie is a thick, cold drink made from fruit and often yoghurt or ice cream, mixed together until smooth.','Banana Smoothie','','A blend of yoghurt with vanilla ice cream and banana.','','25,000',57),
('Shakes & Smoothies','Smoothies','','A smoothie is a thick, cold drink made from fruit and often yoghurt or ice cream, mixed together until smooth.','Tropical Smoothie','','A blend of yoghurt with vanilla ice cream, banana, mangoes, passion and a garnish of syrup.','','25,000',58),
('Shakes & Smoothies','Signature Smoothies','','','Sweet Dreams','','A blend of banana, mangoes, strawberry, almond milk and plain yoghurt with a garnish of syrup.','','25,000',59),
('Shakes & Smoothies','Signature Smoothies','','','Princess Moana','','A blend of mango, vanilla ice cream, yoghurt, banana, almond milk and honey.','','25,000',60),
('Shakes & Smoothies','Signature Smoothies','','','Green Goddess','','A blend of banana, spinach, avocado milk and plain yoghurt.','','25,000',61),
('Mojitos','Mojitos','','','Virgin Mojito','','Refreshing beverage made with muddled lime wedges and fresh mint leaves with crushed ice, flavoured with lemon juice.','','15,000',62),
('Mojitos','Mojitos','','','Passion Mojito','','Refreshing beverage made with muddled lime wedges and fresh mint leaves with crushed ice, flavoured with premium passion syrup.','','15,000',63),
('Mojitos','Mojitos','','','Strawberry Mojito','','A colourful presentation of lemon, sprite, strawberries, mint leaves and ice cubes.','','15,000',64),
('Mojitos','Mojitos','','','Watermelon Mojito','','Refreshing beverage made with muddled lime wedges and fresh mint leaves with crushed ice, flavoured with premium watermelon syrup.','','15,000',65),
('Mojitos','Mojitos','','','Mint Lemonade','','','','15,000',66)) as v(grp,sec,sec_ti,note,name,variant,d,t,price,sort) where not exists (select 1 from menu_items);
-- After creating the staff users in Authentication > Users, make them staff:
-- insert into staff(user_id,role) select id,'admin' from auth.users where email in ('OWNER@EMAIL','STAFF@EMAIL');
