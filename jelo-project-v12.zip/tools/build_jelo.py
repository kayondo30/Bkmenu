# Builds site/menu.json and sql/v2.sql seed for JeLo's Cafe from the owner's menu photos (2026-11-02). Prices UGX.
import json,re
S=lambda n,p,d='',v='':dict(n=n,v=v,d=d,t='',p=p)
D=lambda n,s,dbl,d='':dict(n=n,v='Single / Double',d=d,t='',p=f'{s} / {dbl}')
M=[
('Coffee',[('Espresso & Milk Coffees','',[
 D('Espresso','7,000','9,000','Boiling water is forced under pressure through finely ground coffee beans.'),
 D('Macchiato','8,000','10,000','An espresso based coffee topped with milk foam.'),
 D('Cappuccino','10,000','12,000','An espresso based coffee prepared with well steamed milk.'),
 D('Caffe Latte','8,000','10,000','Freshly well brewed espresso coffee and less foam of steamed milk.'),
 D('Mocha','10,000','12,000','Chocolate sauce or drinking chocolate, espresso shot and well steamed milk with less foam.'),
 S('Vanilla Latte','13,000','Freshly well brewed espresso coffee and less foam of steamed milk and vanilla syrup.'),
 S('Cortado','10,000','Freshly well brewed espresso coffee with steamed milk.'),
 S('Lungo','10,000','Freshly longer brewed espresso coffee.'),
 S('Affogato','15,000','Freshly well brewed espresso coffee and vanilla ice cream.')]),
 ('Brewed Coffee','',[
 S('Black Coffee','9,000','Freshly brewed coffee and well steamed water served with sugar or honey.'),
 S('African Coffee','12,000','Freshly brewed coffee and well prepared milk served with sugar or honey.')]),
 ('Hot Chocolate','',[
 S('Hot Chocolate','12,000','Whipped cream, well steamed milk with less foam and drinking chocolate or chocolate sauce.')])]),
('Tea',[('Teas','',[
 S('African Tea','10,000','Well prepared hot milk with or without spices, Ugandan tea leaves served with sugar or honey.'),
 S('Black Tea','7,000','Well prepared hot water with or without spices, Ugandan tea leaves served with sugar or honey.'),
 S('Lemon Tea','10,000','Hot water with lemon served with honey.'),
 S('Hibiscus Tea','8,000','Hot water with hibiscus served with honey.'),
 S('Ginger Tea','8,000','Hot water with ginger served with honey.'),
 S('Mint Tea','10,000','Hot water with mint served with honey.')]),
 ('Dawa Teas','',[
 S('Classic Dawa Tea','10,000','Honey, lemon, black pepper, ginger and hot water.'),
 S('Cinnamon Garlic Dawa Tea','12,000','Honey, lemon, black pepper, garlic, cinnamon and hot water.'),
 S('Mint Dawa Tea','10,000','Mix of fresh ginger, fresh mint and lemon served with honey.')])]),
('Iced',[('Iced Coffee','',[
 S('Iced Americano','15,000','Well iced water with freshly brewed coffee served with sugar or honey.'),
 S('Iced Black Coffee','15,000','Well iced water with freshly brewed coffee served with sugar or honey.'),
 S('Iced Cafe Latte','16,000','Freshly well brewed espresso coffee and foam of steamed milk, with a flavour of choice and ice cubes.'),
 S('Iced Mocha','16,000','Chocolate sauce or drinking chocolate, espresso shot and well steamed milk with less foam and ice cubes.'),
 S('Iced Chocolate','17,000','Whipped cream, well steamed milk with less foam, drinking chocolate and ice cubes.')]),
 ('Iced Tea','',[
 S('Iced Lemon Tea','17,000','Boiled water with lemon and honey, served chilled with ice cubes.'),
 S('Iced Pineapple Tea','17,000','Boiled water with pineapple cubes and honey, served chilled with ice cubes.')])]),
('Juices',[('Pure Juices','',[
 S('Pure Apple','14,000','A blend of pure apple fruit juice and a dash of water.'),
 S('Pure Orange','14,000','A blend of pure orange fruit juice and water.'),
 S('Passion Juice','10,000','A blend of pure passion fruit juice and water.'),
 S('Water Melon Juice','10,000','Pure watermelon fruit juice and water.'),
 S('Pineapple Juice','13,000'),S('Mango Juice','10,000'),S('Lemon Juice','10,000'),
 S('Carrot Juice','10,000'),S('Kiwi Juice','16,000'),
 S('Hibiscus Juice','10,000','A quality blend of hibiscus and water.')]),
 ('Blends & Mixes','',[
 S('Mango Blast','15,000','A blend of pure mango fruit juice and a dash of milk or ice cream.'),
 S('Passion Mix','13,000','A quality blend of passion, mango, ginger and lemon.'),
 S('Beetroot Mix','14,000','Beetroot, ginger, watermelon and passion.'),
 S('Cocktail Juice','16,000','A blend of pure orange, apple, pineapple and passion fruit juices.'),
 S('Red Rush','16,000')])]),
('Shakes & Smoothies',[('Milkshakes','',[
 S('Vanilla Milkshake','20,000','A blend of premium vanilla ice cream and milk with a garnish of syrup.'),
 S('Strawberry Milkshake','20,000','A blend of premium strawberry ice cream and milk with a garnish of syrup.'),
 S('Chocolate Milkshake','20,000','A blend of premium chocolate ice cream and milk with a garnish of syrup.'),
 S('Oreo Milkshake','20,000','A blend of premium vanilla ice cream, milk and Oreo cookies with a garnish of syrup.'),
 S('Caramel Milkshake','20,000','A blend of premium caramel ice cream with milk and chocolate sauce.'),
 S('Mocha Milkshake','20,000','A blend of premium vanilla ice cream with coffee (espresso) and chocolate sauce.'),
 S('Banana Milkshake','20,000','A blend of vanilla ice cream and caramel syrup.'),
 S('Mango Milkshake','20,000','A blend of ice cream, mangoes, milk and a garnish of syrup.'),
 S('Tropical Milkshake','20,000','A blend of ice cream, banana, mangoes, passion and a garnish of syrup.')]),
 ('Smoothies','A smoothie is a thick, cold drink made from fruit and often yoghurt or ice cream, mixed together until smooth.',[
 S('Vanilla Smoothie','25,000','A blend of yoghurt with vanilla ice cream and a garnish of syrup.'),
 S('Strawberry Smoothie','25,000','A blend of yoghurt with ice cream and fresh strawberries.'),
 S('Oreo Smoothie','25,000','A blend of yoghurt with vanilla ice cream and Oreo cookies.'),
 S('Mango Smoothie','25,000','A blend of yoghurt with vanilla ice cream and mango juice.'),
 S('Banana Smoothie','25,000','A blend of yoghurt with vanilla ice cream and banana.'),
 S('Tropical Smoothie','25,000','A blend of yoghurt with vanilla ice cream, banana, mangoes, passion and a garnish of syrup.')]),
 ('Signature Smoothies','',[
 S('Sweet Dreams','25,000','A blend of banana, mangoes, strawberry, almond milk and plain yoghurt with a garnish of syrup.'),
 S('Princess Moana','25,000','A blend of mango, vanilla ice cream, yoghurt, banana, almond milk and honey.'),
 S('Green Goddess','25,000','A blend of banana, spinach, avocado milk and plain yoghurt.')])]),
('Mojitos',[('Mojitos','',[
 S('Virgin Mojito','15,000','Refreshing beverage made with muddled lime wedges and fresh mint leaves with crushed ice, flavoured with lemon juice.'),
 S('Passion Mojito','15,000','Refreshing beverage made with muddled lime wedges and fresh mint leaves with crushed ice, flavoured with premium passion syrup.'),
 S('Strawberry Mojito','15,000','A colourful presentation of lemon, sprite, strawberries, mint leaves and ice cubes.'),
 S('Watermelon Mojito','15,000','Refreshing beverage made with muddled lime wedges and fresh mint leaves with crushed ice, flavoured with premium watermelon syrup.'),
 S('Mint Lemonade','15,000')])])]
pages=[{'g':g,'pg':[],'sections':[{'t':t,'ti':'','note':n,'items':it} for t,n,it in secs]} for g,secs in M]
json.dump({'v':2,'cur':'UGX','pages':pages},open('site/menu.json','w',encoding='utf8'),ensure_ascii=False,separators=(',',':'))
q=lambda s:"'"+s.replace("'","''")+"'"
rows=[];k=0
for pg in pages:
  for s in pg['sections']:
    for i in s['items']:
      k+=1;rows.append(f"({q(pg['g'])},{q(s['t'])},'',{q(s['note'])},{q(i['n'])},{q(i['v'])},{q(i['d'])},'',{q(i['p'])},{k})")
sql=open('sql/v2.sql',encoding='utf8').read()
a=sql.index('insert into menu_items(grp,sec,sec_ti');b=sql.index('-- After creating the staff users')
sql=sql[:a]+"insert into menu_items(grp,sec,sec_ti,note,name,variant,d,t,price,sort) values\n"+",\n".join(rows)+";\n"+sql[b:]
sql=sql.replace('-- BK menu v2 migration','-- Menu v2 migration for JeLo\'s Cafe (own Supabase project)')
open('sql/v2.sql','w',encoding='utf8').write(sql)
print(k,'items',[(p['g'],sum(len(s['items']) for s in p['sections'])) for p in pages])
