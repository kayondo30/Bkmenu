/* BK menu v5.2: celebrations. The Eritrean (Geez) calendar and the Gregorian one decide the decoration; two levels:
   'season' = the days around a celebration (a garland along the top of the header), 'day' = the exact day (more decorations, twinkling and swaying, and a greeting card first in the carousel).
   Remembrance days (Martyrs' Day 20 June, Fenkil 10 February, 1 September) get NO festive decoration, on purpose. All drawings are SVG made here, nothing downloaded. */
(function(){
const DAY=864e5;
/* Julian day numbers */
const g2j=(y,m,d)=>{const a=Math.floor((14-m)/12),yy=y+4800-a,mm=m+12*a-3;return d+Math.floor((153*mm+2)/5)+365*yy+Math.floor(yy/4)-Math.floor(yy/100)+Math.floor(yy/400)-32045};
const j2g=j=>{const a=j+32044,b=Math.floor((4*a+3)/146097),c=a-Math.floor(146097*b/4),d=Math.floor((4*c+3)/1461),e=c-Math.floor(1461*d/4),m=Math.floor((5*e+2)/153);return[100*b+d-4800+Math.floor(m/10),m+3-12*Math.floor(m/10),e-Math.floor((153*m+2)/5)+1]};
const EP=1724221;/* Geez (Ethiopic) calendar epoch */
const e2j=(y,m,d)=>EP+365*(y-1)+Math.floor(y/4)+30*(m-1)+d-1;
const E0=EP-365;/* year 0, so the leap year (Pagume 6 days) is the 3rd of every 4, as in the Geez calendar */
const j2e=j=>{const r=(j-E0)%1461,n=r%365+365*Math.floor(r/1460);return[4*Math.floor((j-E0)/1461)+Math.floor(r/365)-Math.floor(r/1460),Math.floor(n/30)+1,n%30+1]};
const jOf=dt=>g2j(dt.getFullYear(),dt.getMonth()+1,dt.getDate());
/* Orthodox Easter (Fasika): Julian computus, the Julian date turned into a day number directly; Western Easter: Gregorian computus */
function fasika(y){const a=y%4,b=y%7,c=y%19,d=(19*c+15)%30,e=(2*a+4*b-d+34)%7,m=Math.floor((d+e+114)/31),dd=(d+e+114)%31+1;return julianToJ(y,m,dd)}
function julianToJ(y,m,d){const a=Math.floor((14-m)/12),yy=y+4800-a,mm=m+12*a-3;return d+Math.floor((153*mm+2)/5)+365*yy+Math.floor(yy/4)-32083}
function easter(y){const a=y%19,b=Math.floor(y/100),c=y%100,d=Math.floor(b/4),e=b%4,f=Math.floor((b+8)/25),g=Math.floor((b-f+1)/3),h=(19*a+b-d-g+15)%30,i=Math.floor(c/4),k=c%4,l=(32+2*e+2*i-h-k)%7,m=Math.floor((a+11*h+22*l)/451),mo=Math.floor((h+l-7*m+114)/31),da=(h+l-7*m+114)%31+1;return g2j(y,mo,da)}
/* the two Eids follow the moon: expected dates, can move by a day after the moon sighting (the day level covers the day before and after) */
const EID={2026:['3-20','5-27'],2027:['3-10','5-17'],2028:['2-27','5-5'],2029:['2-15','4-24'],2030:['2-5','4-14'],2031:['1-25','4-3'],2032:['1-14','3-22']};
const fix=(y,m,d)=>g2j(y,m,d);
/* every celebration: art, greeting, the exact day(s) [from,to] and the season [from,to], as Julian day numbers */
function events(y){const L=[],add=(k,d0,d1,s0,s1)=>L.push({k,d0,d1,s0,s1});
 add('xmas',fix(y,12,24),fix(y,12,25),fix(y,12,12),fix(y,12,30));
 add('newyear',fix(y,12,31),fix(y+1,1,1),fix(y,12,26),fix(y+1,1,2));
 add('newyear',fix(y-1,12,31),fix(y,1,1),fix(y-1,12,26),fix(y,1,2));
 add('ledet',fix(y,1,6),fix(y,1,7),fix(y,1,3),fix(y,1,9));
 {const ey=j2e(fix(y,1,15))[0],t=e2j(ey,5,11);add('timket',t-1,t,t-6,t+2)}/* Timket = Tir 11, Ketera the eve */
 add('val',fix(y,2,14),fix(y,2,14),fix(y,2,12),fix(y,2,14));
 {const f=fasika(y);add('fasika',f-1,f,f+1,f+7)}
 {const w=easter(y);add('easter',w,w,w+1,w+7)}
 add('indep',fix(y,5,24),fix(y,5,24),fix(y,5,17),fix(y,5,25));
 {const ey=j2e(fix(y,10,1))[0],n=e2j(ey,1,1);add('awde',n,n,n-9,n+1)}/* Geez New Year = Meskerem 1 (11 or 12 September) */
 {const ey=j2e(fix(y,10,1))[0],m=e2j(ey,1,17);add('meskel',m-1,m,m-14,m+1)}/* Meskel: Demera the eve; daisy season after the New Year */
 add('ug',fix(y,10,9),fix(y,10,9),fix(y,10,6),fix(y,10,9));
 const e=EID[y];if(e){e.forEach((s,i)=>{const[m,d]=s.split('-').map(Number),j=fix(y,m,d);add(i?'adha':'fitr',j-1,j+1,j-3,j+2)})}
 return L}
/* v5.5: each business chooses its celebration sets in config.js (brand.celebrate) */
const SET={ledet:'eritrea',timket:'eritrea',fasika:'eritrea',indep:'eritrea',awde:'eritrea',meskel:'eritrea',xmas:'general',newyear:'general',easter:'general',val:'general',fitr:'islam',adha:'islam',ug:'uganda'};
const allowed=k=>{const b=(window.BK&&window.BK.brand)||{};return !Array.isArray(b.celebrate)||b.celebrate.includes(SET[k])};
function pick(dt){const j=jOf(dt),y=dt.getFullYear();let best=null;
 events(y).filter(e=>allowed(e.k)).forEach(e=>{let lv=null,dist;if(j>=e.d0&&j<=e.d1){lv='day';dist=0}else if(j>=e.s0&&j<=e.s1){lv='season';dist=Math.min(Math.abs(j-e.d0),Math.abs(j-e.d1))}
  if(lv&&(!best||(lv=='day'&&best.lv!='day')||(lv==best.lv&&dist<best.dist)))best={k:e.k,lv,dist}});return best}
/* greetings in English */
const G={xmas:['Merry Christmas'],ledet:['Happy Lidet, Merry Christmas'],newyear:['Happy New Year'],timket:['Happy Timket'],val:["Happy Valentine's Day"],fasika:['Happy Fasika'],easter:['Happy Easter'],indep:['Happy Independence Day, Eritrea'],awde:['Happy New Year'],meskel:['Happy Meskel'],ug:['Happy Independence Day, Uganda'],fitr:['Eid Mubarak'],adha:['Eid Mubarak']};
const ART={xmas:'pine',ledet:'pine',newyear:'gold',timket:'umb',val:'heart',fasika:'spring',easter:'spring',indep:'erflag',awde:'daisy',meskel:'demera',ug:'ugflag',fitr:'lantern',adha:'lantern'};
const NAME={xmas:'Christmas',ledet:'Lidet (Eritrean Christmas)',newyear:'New Year',timket:'Timket',val:"Valentine's Day",fasika:'Fasika (Eritrean Easter)',easter:'Easter',indep:'Eritrea Independence Day',awde:'Geez New Year',meskel:'Meskel',ug:'Uganda Independence Day',fitr:'Eid al-Fitr',adha:'Eid al-Adha'};
/* ---------- drawing helpers (SVG strings) ---------- */
const r1=n=>Math.round(n*10)/10;
let seed=7;const rnd=()=>(seed=(seed*9301+49297)%233280)/233280;
function swag(W,y,dep,n){let d=`M0 ${y}`,dips=[];const w=W/n;for(let i=0;i<n;i++){const x0=i*w,x1=x0+w;d+=` Q${r1(x0+w/2)} ${r1(y+dep*2)} ${r1(x1)} ${y}`;dips.push([x0+w/2,y+dep])}return{d,dips,tops:Array.from({length:n+1},(_,i)=>[i*w,y])}}
const bauble=(x,y,r,c,len,sw)=>`<g class="${sw?'sw':''}" style="transform-origin:${r1(x)}px ${r1(y)}px"><line x1="${r1(x)}" y1="${r1(y)}" x2="${r1(x)}" y2="${r1(y+len)}" stroke="#c9a54c" stroke-width=".8"/><rect x="${r1(x-r*.35)}" y="${r1(y+len-2)}" width="${r1(r*.7)}" height="3" rx="1" fill="#c9a54c"/><circle cx="${r1(x)}" cy="${r1(y+len+r)}" r="${r}" fill="${c}"/><ellipse cx="${r1(x-r*.35)}" cy="${r1(y+len+r*.6)}" rx="${r1(r*.28)}" ry="${r1(r*.4)}" fill="#fff" opacity=".45"/></g>`;
const bulb=(x,y,c,i,tw)=>`<g class="${tw?'tw':''}" style="animation-delay:${(i%5)*.37}s"><circle cx="${r1(x)}" cy="${r1(y+3)}" r="5" fill="${c}" opacity=".25"/><rect x="${r1(x-1.6)}" y="${r1(y-2)}" width="3.2" height="3" fill="#555"/><ellipse cx="${r1(x)}" cy="${r1(y+3)}" rx="2.6" ry="3.8" fill="${c}"/></g>`;
const star=(x,y,r,c)=>{let p='';for(let i=0;i<10;i++){const a=-Math.PI/2+i*Math.PI/5,rr=i%2?r*.45:r;p+=`${r1(x+Math.cos(a)*rr)},${r1(y+Math.sin(a)*rr)} `}return`<polygon points="${p}" fill="${c}"/>`};
const sparkle=(x,y,r,i,tw)=>`<g class="${tw?'tw':''}" style="animation-delay:${(i%7)*.29}s"><path d="M${r1(x)} ${r1(y-r)}L${r1(x+r*.22)} ${r1(y-r*.22)}L${r1(x+r)} ${r1(y)}L${r1(x+r*.22)} ${r1(y+r*.22)}L${r1(x)} ${r1(y+r)}L${r1(x-r*.22)} ${r1(y+r*.22)}L${r1(x-r)} ${r1(y)}L${r1(x-r*.22)} ${r1(y-r*.22)}Z" fill="#fff6d6"/></g>`;
const umb=(x,y,s,c,c2,sw)=>{let fr='';const n=7;for(let i=0;i<n;i++){const a=x-s+i*(2*s/n),b=a+2*s/n;fr+=`Q${r1((a+b)/2)} ${r1(y+s*.28)} ${r1(b)} ${r1(y)} `}
 return`<g class="${sw?'sw':''}" style="transform-origin:${r1(x)}px ${r1(y-s*1.05)}px"><line x1="${r1(x)}" y1="${r1(y-s*1.05)}" x2="${r1(x)}" y2="${r1(y+s*1.3)}" stroke="#d8c08a" stroke-width="1.6"/><path d="M${r1(x-s)} ${r1(y)} Q${r1(x)} ${r1(y-s*1.3)} ${r1(x+s)} ${r1(y)} ${fr.replace(/^Q/,'').length?'':''}" fill="${c}"/><path d="M${r1(x-s)} ${r1(y)} ${fr}" fill="${c2}"/><circle cx="${r1(x)}" cy="${r1(y-s*.55)}" r="${r1(s*.16)}" fill="${c2}"/><circle cx="${r1(x-s*.5)}" cy="${r1(y-s*.25)}" r="${r1(s*.08)}" fill="${c2}"/><circle cx="${r1(x+s*.5)}" cy="${r1(y-s*.25)}" r="${r1(s*.08)}" fill="${c2}"/><circle cx="${r1(x)}" cy="${r1(y-s*1.08)}" r="${r1(s*.12)}" fill="#e9c46a"/></g>`};
const daisy=(x,y,r,rot)=>{let p='';for(let i=0;i<12;i++)p+=`<ellipse cx="${r1(x)}" cy="${r1(y-r*.62)}" rx="${r1(r*.2)}" ry="${r1(r*.5)}" fill="#f6c915" transform="rotate(${i*30+rot} ${r1(x)} ${r1(y)})"/>`;return p+`<circle cx="${r1(x)}" cy="${r1(y)}" r="${r1(r*.32)}" fill="#8a4b12"/><circle cx="${r1(x-r*.08)}" cy="${r1(y-r*.08)}" r="${r1(r*.12)}" fill="#b5651d"/>`};
const leaf=(x,y,s,a,c)=>`<path d="M${r1(x)} ${r1(y)} q${r1(s*.5)} ${r1(-s*.45)} ${r1(s)} 0 q${r1(-s*.5)} ${r1(s*.45)} ${r1(-s)} 0z" fill="${c||'#4f8a3c'}" transform="rotate(${a} ${r1(x)} ${r1(y)})"/>`;
const flower=(x,y,r,c)=>{let p='';for(let i=0;i<5;i++)p+=`<circle cx="${r1(x+Math.cos(i*1.2566)*r*.55)}" cy="${r1(y+Math.sin(i*1.2566)*r*.55)}" r="${r1(r*.48)}" fill="${c}"/>`;return p+`<circle cx="${r1(x)}" cy="${r1(y)}" r="${r1(r*.3)}" fill="#f6c915"/>`};
const pennant=(x,y,w,h,c)=>`<path d="M${r1(x)} ${r1(y)} L${r1(x+w)} ${r1(y)} L${r1(x+w/2)} ${r1(y+h)}Z" fill="${c}"${c=='#111'?' stroke="#9a948a" stroke-width=".8"':''}/>`;
const wreath=(x,y,r)=>{let p='';for(let i=0;i<16;i++){if(i==8||i==7)continue;const a=Math.PI/2+i*Math.PI/8;p+=leaf(x+Math.cos(a)*r,y+Math.sin(a)*r,r*.42,a*57.3+70,'#e3b64b')}return p+`<line x1="${r1(x)}" y1="${r1(y+r)}" x2="${r1(x)}" y2="${r1(y-r*.55)}" stroke="#e3b64b" stroke-width="1.4"/>`+[0,1,2].map(i=>leaf(x,y-r*.4+i*r*.42,r*.36,-50,'#e3b64b')+leaf(x,y-r*.3+i*r*.42,r*.36,230,'#e3b64b')).join('')};
const heart=(x,y,s,c)=>`<path d="M${r1(x)} ${r1(y+s*.9)} C${r1(x-s*1.4)} ${r1(y)} ${r1(x-s*.7)} ${r1(y-s*.9)} ${r1(x)} ${r1(y-s*.2)} C${r1(x+s*.7)} ${r1(y-s*.9)} ${r1(x+s*1.4)} ${r1(y)} ${r1(x)} ${r1(y+s*.9)}Z" fill="${c}"/>`;
const lantern=(x,y,s,c,len,i,anim)=>`<g class="${anim?'sw':''}" style="transform-origin:${r1(x)}px ${r1(y)}px;animation-delay:${i*.4}s"><line x1="${r1(x)}" y1="${r1(y)}" x2="${r1(x)}" y2="${r1(y+len)}" stroke="#c9a54c" stroke-width=".8"/><path d="M${r1(x-s*.35)} ${r1(y+len)}h${r1(s*.7)}l${r1(s*.15)} ${r1(s*.25)}h${r1(-s)}z" fill="#c9a54c"/><path d="M${r1(x-s*.5)} ${r1(y+len+s*.25)}h${r1(s)}l${r1(s*.12)} ${r1(s*.55)}l${r1(-s*.12)} ${r1(s*.55)}h${r1(-s)}l${r1(-s*.12)} ${r1(-s*.55)}z" fill="${c}"/><path d="M${r1(x-s*.22)} ${r1(y+len+s*.38)}h${r1(s*.44)}v${r1(s*.85)}h${r1(-s*.44)}z" fill="#ffe7a3" class="${anim?'tw':''}"/><path d="M${r1(x-s*.35)} ${r1(y+len+s*1.35)}h${r1(s*.7)}l${r1(-s*.2)} ${r1(s*.25)}h${r1(-s*.3)}z" fill="#c9a54c"/></g>`;
const crescent=(x,y,r)=>{const p1=[x+r*.5,y-r*.866],p2=[x+r*.5,y+r*.866],ri=r*.92;return`<path d="M${r1(p1[0])} ${r1(p1[1])} A${r} ${r} 0 1 0 ${r1(p2[0])} ${r1(p2[1])} A${r1(ri)} ${r1(ri)} 0 0 1 ${r1(p1[0])} ${r1(p1[1])}Z" fill="#f2cf63"/>`};
const demera=(x,y,s,anim)=>{let p='';for(let i=-3;i<=3;i++)p+=`<line x1="${r1(x+i*s*.16)}" y1="${r1(y)}" x2="${r1(x+i*s*.03)}" y2="${r1(y-s*1.25)}" stroke="#8a5a2b" stroke-width="2.2" stroke-linecap="round"/>`;
 return`<g>${p}<g class="${anim?'fl':''}" style="transform-origin:${r1(x)}px ${r1(y)}px"><path d="M${r1(x-s*.5)} ${r1(y)} C${r1(x-s*.6)} ${r1(y-s*.5)} ${r1(x-s*.15)} ${r1(y-s*.6)} ${r1(x-s*.1)} ${r1(y-s*1.0)} C${r1(x+s*.05)} ${r1(y-s*.65)} ${r1(x+s*.35)} ${r1(y-s*.75)} ${r1(x+s*.25)} ${r1(y-s*1.1)} C${r1(x+s*.6)} ${r1(y-s*.7)} ${r1(x+s*.6)} ${r1(y-s*.3)} ${r1(x+s*.5)} ${r1(y)}Z" fill="#f08a24"/><path d="M${r1(x-s*.28)} ${r1(y)} C${r1(x-s*.3)} ${r1(y-s*.35)} ${r1(x)} ${r1(y-s*.4)} ${r1(x+s*.02)} ${r1(y-s*.72)} C${r1(x+s*.2)} ${r1(y-s*.4)} ${r1(x+s*.32)} ${r1(y-s*.25)} ${r1(x+s*.28)} ${r1(y)}Z" fill="#ffd34d"/></g><path d="M${r1(x)} ${r1(y-s*1.25)}v${r1(-s*.5)}M${r1(x-s*.15)} ${r1(y-s*1.55)}h${r1(s*.3)}" stroke="#e3b64b" stroke-width="2" stroke-linecap="round"/></g>`};
const burst=(x,y,r,c,i,anim)=>{let p='';for(let k=0;k<12;k++){const a=k*Math.PI/6;p+=`<line x1="${r1(x+Math.cos(a)*r*.35)}" y1="${r1(y+Math.sin(a)*r*.35)}" x2="${r1(x+Math.cos(a)*r)}" y2="${r1(y+Math.sin(a)*r)}" stroke="${c}" stroke-width="1.6" stroke-linecap="round"/><circle cx="${r1(x+Math.cos(a)*r*1.12)}" cy="${r1(y+Math.sin(a)*r*1.12)}" r="1.4" fill="${c}"/>`}return`<g class="${anim?'tw':''}" style="animation-delay:${i*.5}s">${p}</g>`};
/* ---------- the header drawing: W x H px, logo kept clear in the middle (lw = half logo width) ---------- */
function header(art,lv,W,H,free){seed=11;const day=lv=='day',cx=W/2,lw=64,side=x=>free||Math.abs(x-cx)>lw+14;let s='';
 const n=Math.max(4,Math.round(W/(day?62:78)));
 if(art=='pine'){const g=swag(W,4,8,n);s+=`<path d="${g.d}" stroke="#1f5a34" stroke-width="7" fill="none" stroke-linecap="round"/><path d="${g.d}" stroke="#2f7d4a" stroke-width="3" fill="none" stroke-dasharray="2 3"/>`;
  const C=['#c8312e','#e3b64b','#2f7d4a','#c8312e','#e3b64b'];g.dips.forEach((p,i)=>{if(side(p[0])||!day)s+=bauble(p[0],p[1]+2,day?6:5,C[i%5],day?(i%2?10:18):6,day)});
  if(day){const l=swag(W,10,9,n*2);const B=['#ff6b5a','#ffd34d','#7ee08a','#6bb8ff'];let k=0;for(let i=0;i<=40;i++){const t=i/40,x=t*W,seg=Math.floor(t*n*2),lt=t*n*2-seg,y=10+18*lt*(1-lt);if(side(x)||y<16)s+=bulb(x,y,B[k++%4],i,true)}
   s+=star(14,H*.55,8,'#e3b64b')+star(W-14,H*.55,8,'#e3b64b');for(let i=0;i<10;i++){const x=rnd()*W;if(side(x))s+=sparkle(x,30+rnd()*(H-40),2.5+rnd()*2,i,true)}}}
 else if(art=='gold'){for(let i=0;i<(day?60:28);i++){const x=rnd()*W,y=rnd()*H;if(!side(x)&&y>18)continue;const c=['#e3b64b','#f5e6b8','#c0c0c0','#ffd34d'][i%4];s+=`<rect x="${r1(x)}" y="${r1(y)}" width="${r1(3+rnd()*3)}" height="${r1(2+rnd()*2)}" fill="${c}" transform="rotate(${r1(rnd()*180)} ${r1(x)} ${r1(y)})" opacity=".9"/>`}
  if(day){[[W*.12,H*.45,20,'#ffd34d'],[W*.88,H*.4,18,'#f5e6b8'],[W*.24,H*.2,11,'#e3b64b'],[W*.77,H*.22,12,'#ffd34d']].forEach((b,i)=>{if(side(b[0]))s+=burst(b[0],b[1],b[2],b[3],i,true)})}}
 else if(art=='umb'){const C=[['#b5262c','#e9c46a'],['#1f4e9c','#e9c46a'],['#6b2b8a','#e9c46a'],['#1f7a4d','#e9c46a'],['#c8641e','#fff1c1']];const m=day?Math.max(4,Math.round(W/70)):Math.max(3,Math.round(W/110));
  for(let i=0;i<m;i++){const x=(i+.5)*W/m;if(!side(x))continue;const sz=day?(i%2?15:19):13;s+=umb(x,sz*1.15+4,sz,C[i%5][0],C[i%5][1],day)}
  const g=swag(W,3,5,n);s+=`<path d="${g.d}" stroke="#6bb8ff" stroke-width="2" fill="none"/><path d="${g.d}" stroke="#fff" stroke-width="1" fill="none" stroke-dasharray="3 5" transform="translate(0 2)"/>`}
 else if(art=='daisy'||art=='demera'){const g=swag(W,4,6,n);s+=`<path d="${g.d}" stroke="#3f7a32" stroke-width="2.5" fill="none"/>`;
  for(let i=0;i<=n*2;i++){const t=i/(n*2),x=t*W,seg=Math.floor(t*n),lt=t*n-seg,y=4+12*lt*(1-lt);s+=leaf(x,y,8,i%2?30:150);if(i%2==0||day)s+=daisy(x,y+1,day?7:6,i*7)}
  if(day&&art=='demera'){s+=demera(26,H-6,26,true)+demera(W-26,H-6,26,true)}
  if(day&&art=='daisy'){[[18,H*.62],[W-18,H*.62],[44,H*.8],[W-44,H*.8]].forEach((p,i)=>{s+=leaf(p[0]-6,p[1]+6,12,120)+daisy(p[0],p[1],i<2?11:8,i*20)})}}
 else if(art=='erflag'||art=='ugflag'){const C=art=='erflag'?['#12a14a','#ea2c2c','#4189dd','#f2c14e']:['#111','#fcdc04','#d90000','#111','#fcdc04','#d90000'];
  const rows=day?2:1;for(let r=0;r<rows;r++){const g=swag(W,3+r*12,6,n),pc=Math.round(W/(r?26:20));s+=`<path d="${g.d}" stroke="#ddd" stroke-width="1" fill="none"/>`;
   for(let i=0;i<pc;i++){const t=(i+.5)/pc,x=t*W,seg=Math.floor(t*n),lt=t*n-seg,y=3+r*12+12*lt*(1-lt);if(r&&!side(x))continue;s+=pennant(x-6,y,12,r?13:15,C[(i+r)%C.length])}}
  if(day&&art=='erflag'){s+=wreath(26,H*.62,13)+wreath(W-26,H*.62,13)}
  if(day&&art=='ugflag'){s+=star(20,H*.6,7,'#fcdc04')+star(W-20,H*.6,7,'#fcdc04')}}
 else if(art=='lantern'){const C=['#c8312e','#1f7a4d','#1f4e9c','#c8641e'];const m=day?Math.max(5,Math.round(W/58)):Math.max(3,Math.round(W/95));s+=`<line x1="0" y1="2" x2="${W}" y2="2" stroke="#c9a54c" stroke-width="1"/>`;
  for(let i=0;i<m;i++){const x=(i+.5)*W/m;if(!side(x))continue;s+=lantern(x,2,day?13:11,C[i%4],day?(i%2?10:26):6,i,day)}
  s+=crescent(W*.5-lw-30>40?40:20,H*.35,day?11:8);for(let i=0;i<(day?8:3);i++){const x=rnd()*W;if(side(x))s+=star(x,14+rnd()*(H-24),2.4,'#f2cf63')}}
 else if(art=='heart'){const g=swag(W,3,6,n);s+=`<path d="${g.d}" stroke="#d97a8a" stroke-width="1" fill="none"/>`;const pc=Math.round(W/(day?24:34));
  for(let i=0;i<pc;i++){const t=(i+.5)/pc,x=t*W,seg=Math.floor(t*n),lt=t*n-seg,y=3+12*lt*(1-lt);s+=heart(x,y+7,day?6:5,i%2?'#e2445c':'#ff8fa3')}
  if(day)for(let i=0;i<8;i++){const x=rnd()*W;if(side(x))s+=`<g class="tw" style="animation-delay:${i*.3}s">${heart(x,24+rnd()*(H-34),3.5,'#ff8fa3')}</g>`}}
 else if(art=='spring'){const g=swag(W,4,6,n);s+=`<path d="${g.d}" stroke="#4f8a3c" stroke-width="2" fill="none"/>`;const C=['#f2a7c3','#ffffff','#c7a6ff','#ffd166'];
  for(let i=0;i<=n*3;i++){const t=i/(n*3),x=t*W,seg=Math.floor(t*n),lt=t*n-seg,y=4+12*lt*(1-lt);s+=leaf(x,y,7,i%2?20:160);if(i%2==0||day)s+=flower(x,y+2,day?5:4,C[i%4])}
  if(day){[[20,H*.6],[W-20,H*.6]].forEach((p,i)=>{s+=leaf(p[0]-4,p[1]+8,14,110)+leaf(p[0]+2,p[1]+8,14,70)+flower(p[0],p[1],9,i?'#f2a7c3':'#c7a6ff')})}}
 return`<svg viewBox="0 0 ${W} ${H}" width="${W}" height="${H}" xmlns="http://www.w3.org/2000/svg">${s}</svg>`}
/* a small drawing for the greeting card (W x 120) */
function card(art,W){return header(art,'day',W,120,true)}/* the greeting card has no logo, so it is decorated across its whole width */
window.BKD={allowed,pick,header,card,G,ART,NAME,keys:Object.keys(G),events,jOf,j2g};
})();
