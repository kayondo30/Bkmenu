// BK menu v5.5 service worker (borrowed from FHG v505): the menu page is kept as a clean copy (no redirect mark) under ./ and ./index.html,
// so the menu opens in flight mode; the menu data is network first (fresh prices), the saved copy only when offline; staff (admin.html) is never cached.
const C='bk-menu-v5.5',A=['menu.json','photos.json','logo.png','config.js','deco.js','manifest.webmanifest','icon-192.png','icon-512.png','fonts/Manrope-Regular.woff','fonts/Manrope-Medium.woff','fonts/Manrope-Bold.woff'];
const OFF='<!doctype html><meta name="viewport" content="width=device-width,initial-scale=1"><title>Menu</title><body style="font-family:system-ui,sans-serif;padding:32px;line-height:1.5;background:#141311;color:#efeae0"><h1 style="font-size:20px">You are offline</h1><p>Open the menu once with data so it can save itself on this phone. After that it opens without data.</p><p><a style="color:#d4a94b" href="./">Try again</a></p></body>';
function clean(res){if(!res||!res.redirected)return Promise.resolve(res);return res.blob().then(b=>new Response(b,{status:200,statusText:'OK',headers:res.headers}))}
function keep(c,res){return clean(res).then(cl=>{if(!cl||!cl.ok)return;return Promise.all([c.put('./',cl.clone()),c.put('./index.html',cl.clone())])})}
self.addEventListener('install',e=>{e.waitUntil(caches.open(C).then(c=>c.addAll(A.map(u=>new Request(u,{cache:'reload'}))).then(()=>fetch(new Request('./',{cache:'reload'})).then(r=>keep(c,r)))));self.skipWaiting()});
self.addEventListener('activate',e=>{e.waitUntil(caches.keys().then(k=>Promise.all(k.filter(x=>x!==C).map(x=>caches.delete(x)))).then(()=>self.clients.claim()))});
self.addEventListener('message',e=>{if(e.data==='SKIP_WAITING')self.skipWaiting()});
self.addEventListener('fetch',e=>{const r=e.request,u=new URL(r.url);
 if(r.method!=='GET'||u.origin!==location.origin||u.pathname.includes('admin'))return;
 const base=new URL('./',self.registration.scope).pathname;
 if(r.mode==='navigate'){const app=u.pathname===base||u.pathname===base+'index.html';
  e.respondWith(fetch(r).then(res=>{if(res.ok&&app){const cp=res.clone();caches.open(C).then(c=>keep(c,cp))}return res}).catch(()=>(app?caches.match('./',{ignoreSearch:true}).then(h=>h||caches.match('./index.html',{ignoreSearch:true})).then(clean):Promise.resolve(null)).then(h=>h||new Response(OFF,{headers:{'Content-Type':'text/html'}}))));return}
 // data and code: network first so prices and code are always the newest; the saved copy only when offline
 if(/\.(?:json|js|css|webmanifest)$/.test(u.pathname)){e.respondWith(fetch(r).then(res=>{if(res.ok){const cp=res.clone();caches.open(C).then(c=>c.put(r,cp))}return res}).catch(()=>caches.match(r,{ignoreSearch:true})));return}
 // pictures and fonts: saved copy first
 e.respondWith(caches.match(r,{ignoreSearch:true}).then(h=>h||fetch(r).then(res=>{if(res.ok){const cp=res.clone();caches.open(C).then(c=>c.put(r,cp))}return res})))});
