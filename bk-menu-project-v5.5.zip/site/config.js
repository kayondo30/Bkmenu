// ===== ONE PLACE FOR EACH BUSINESS (v5.5) =====
// A new client: change the lines in "brand" below, replace logo.png and the two icons, edit manifest.webmanifest (name, short_name),
// put their drinks in menu.json and their Supabase address and publishable key here. Nothing else needs changing. See NEW-CLIENT.md.
window.BK={
 // Public Supabase project address and publishable key (safe to be public; never put the secret or service_role key here)
 url:'https://qeudronebisrlcqerwvz.supabase.co',
 key:'sb_publishable_9PPL1dg6NpQ6sIjrGuEETQ_Y8h90CJO',
 usd:4350,                                   // dollar rate used until the live rate loads
 brand:{
  short:'BK',                                // short name (staff page title "BK staff")
  full:'BK Liquor, Wines, Spirits & Coffee', // full company name: logo text for screen readers, signature on message cards
  title:'BK Beverage Menu',                  // browser tab, share, install name
  motto:'DRINK • RELAX • ENJOY',             // first footer line (empty = none)
  footer:'BK • Liquor, Wines, Spirits & Coffee', // second footer line
  share:'Our drinks menu',                   // text sent with the Share button
  geez:true,                                 // show today's Eritrean (Geez) date under the price line
  celebrate:['eritrea','general','islam','uganda'] // celebration sets: eritrea (Lidet, Timket, Fasika, Independence, Geez New Year, Meskel), general (Christmas, New Year, Easter, Valentine's), islam (both Eids), uganda (Independence 9 Oct); [] = none
 }
};
