# v3.9: hotel-style reorganisation. Reads the v3.8 menu.json (old structure), writes new menu.json + sql/v3.9.sql + sql/v3.9-undo.sql
import json,copy
old=json.load(open('site/menu.json',encoding='utf8'))
rows={}
for p in old['pages']:
    for s in p['sections']:
        for i in s['items']:
            rows[i['n']]=dict(i,og=p['g'],os=s['t'],oti=s['ti'],on=s['note'])
assert len(rows)==133
# plan: (page, section, section_ti, note, [ (old_name, new_name or None, new_variant or None) ... ])
TI={'coffee':'ቡን','tea':'ሻሂ','icedc':'ቀዝቃዛ ቡን','toast':'ናይ ንግሆ ምግብ','milk':'ሚልክሼክ','smoo':'ስሙዚ','beer':'ቢራ','soft':'ልስሉስ መስተዋት'}
M14='Every milkshake · UGX 14,000'; S17='Every smoothie · UGX 17,000'
P=[
('Coffee','Espresso & Milk Coffees',TI['coffee'],'',[('Lungo',),('Macchiato',),('Cortado',),('Cappuccino',),('Caffè Latte',),('Vanilla Latte',),('Mocha',)]),
('Coffee','Brewed & Traditional Coffee',TI['coffee'],'',[('Black Coffee',),('African Coffee',),('Habesha Coffee',)]),
('Coffee','Hot Chocolate','','',[('Hot Chocolate',)]),
('Coffee','Toasted Specials',TI['toast'],'',[('Toasted Bread',),('Toasted Bread Special with Eggs',)]),
('Tea','Classic Teas',TI['tea'],'',[('Black Tea',),('African Tea',)]),
('Tea','Infusions',TI['tea'],'',[('Ginger Tea',),('Hibiscus Tea',),('Lemon Tea',),('Mint Tea',)]),
('Tea','Dawa Teas','','',[('Classic Dawa Tea',),('Mint Dawa Tea',),('Cinnamon Garlic Dawa Tea',)]),
('Iced','Iced Coffee',TI['icedc'],'',[('Iced Americano',),('Iced Black Coffee',),('Iced Caffè Latte',),('Iced Mocha',),('Iced Chocolate',)]),
('Iced','Iced Tea','','',[('Iced Lemon Tea',),('Iced Pineapple Tea',)]),
('Juices','Fresh & Pure','','',[('Lemon Juice',),('Carrot Juice',),('Watermelon Juice',),('Mango Juice',),('Passion Juice',),('Hibiscus Juice',),('Pineapple Juice',),('Pure Apple',),('Pure Orange',),('Kiwi Juice',)]),
('Juices','Signature Blends','','',[('Passion Mix',),('Beetroot Mix',),('Mango Blast',),('Cocktail Juice',),('Red Rush',)]),
('Shakes & Smoothies','Milkshakes',TI['milk'],M14,[('Vanilla Milkshake',),('Chocolate Milkshake',),('Strawberry Milkshake',),('Banana Milkshake',),('Caramel Milkshake',),('Mango Milkshake',),('Tropical Milkshake',),('Oreo Milkshake',),('Mocha Milkshake',)]),
('Shakes & Smoothies','Smoothies',TI['smoo'],S17,[('Strawberry Smoothie',),('Banana Smoothie',),('Mango Smoothie',),('Tropical Smoothie',),('Vanilla Smoothie',),('Oreo Smoothie',)]),
('Shakes & Smoothies','Signature Smoothies','',S17,[('Sweet Dreams',),('Princess Moana',),('Green Goddess',)]),
('Beer & Soft','Beer & Cider',TI['beer'],'',[('Castle Lite',),('Tusker Lite',),('Tusker Malt',),('Bell',),('Club',),('Nile',),('Tusker Lager',),('Guinness',),('Tusker Cider',),('Heineken',)]),
('Beer & Soft','Soft Drinks & Mixers',TI['soft'],'',[('Sodas',),('Sting',),('Soda Water',),('Tonic Water',)]),
('Whisky','Blended Scotch','','',[('Black & White',),("Ballantine's 750ml","Ballantine's",'750ml'),("Ballantine's 1L","Ballantine's",'1L'),('Red Label','Johnnie Walker Red Label',''),('Grants 1L',"Grant's",'1L'),('Black Label','Johnnie Walker Black Label',''),('Double Black','Johnnie Walker Double Black',''),('Gold Label 750ml','Johnnie Walker Gold Label','750ml'),('Chivas Regal 12 Years','Chivas Regal','12 Year Old'),('Gold Label 1L','Johnnie Walker Gold Label','1L')]),
('Whisky','Irish & American','','',[('Jameson 1L','Jameson','1L'),("Jack Daniel's",)]),
('Whisky','Single Malt','','',[('Singleton 15 Years','Singleton','15 Year Old'),('Glenfiddich 12 Years','Glenfiddich','12 Year Old')]),
('Whisky','Everyday Whisky','','',[('Bond 7',),('Bonfire Whisky',)]),
('Spirits','Vodka','','',[('CHR-One Vodka',),('Absolut Vodka',),('Smirnoff',),('Absolut Raspberry',),('Grey Goose 1L','Grey Goose','1L'),('Cîroc 1L','Cîroc','1L')]),
('Spirits','Gin','','',[('Uganda Waragi 200ml','Uganda Waragi','200ml'),("Jingle's Gin",),('Uganda Waragi Premium',),("Gilbey's Gin",),('Uganda Waragi Lemon & Ginger',),("Gordon's Gin 750ml","Gordon's Gin",'750ml'),("Gordon's Gin 1L","Gordon's Gin",'1L')]),
('Spirits','Rum','','',[('Captain Morgan Gold 750ml','Captain Morgan Gold','750ml'),('Captain Morgan Black 750ml','Captain Morgan Black','750ml'),('Malibu',),('Bacardi',)]),
('Spirits','Tequila','','',[('José Cuervo',),('Olmeca',),('Don Julio',)]),
('Spirits','Brandy & Cognac','','',[('V&A',),('Hennessy',),('Rémy Martin',)]),
('Spirits','Liqueurs','','',[('Baileys 375ml','Baileys','375ml'),('Baileys 750ml','Baileys','750ml'),('Amarula',),('Jägermeister',)]),
('Spirits','Areqi','','',[('Areqi — Shot','Areqi','Shot'),('Areqi — Bottle','Areqi','Bottle')]),
('Wine & Bubbly','Wine','','',[('Well In Town',),('Sweet Kiss',),('J.C',),('Four Cousins',),('Perdeberg Cellar',),('Roma',),('KHV',),('Nederburg',),('B&G',)]),
('Wine & Bubbly','Champagne & Other','','',[('High-5',),('Sierra',),('Moët & Chandon',)]),
]
seen=[];sort=0;pages=[];ups=[];undo=[]
for g,sec,ti,note,items in P:
    pg=next((x for x in pages if x['g']==g),None)
    if not pg:
        pg={'g':g,'pg':[],'sections':[]};pages.append(pg)
    S={'t':sec,'ti':ti,'note':note,'items':[]};pg['sections'].append(S)
    for it in items:
        o=it[0];r=rows[o];seen.append(o);sort+=1
        nn=it[1] if len(it)>1 else o
        nv=it[2] if len(it)>2 else r['v']
        S['items'].append({'n':nn,'v':nv,'d':r['d'],'t':r['t'],'p':r['p']})
        ups.append((o,g,sec,ti,note,nn,nv,sort))
        undo.append((nn,nv,r['og'],r['os'],r['oti'],r['on'],o,r['v'],0))
assert sorted(seen)==sorted(rows) and len(seen)==133
# undo needs old sort: rebuild from old file order
n=0;oldsort={}
for p in old['pages']:
    for s in p['sections']:
        for i in s['items']: n+=1;oldsort[i['n']]=n
q=lambda s:"'"+s.replace("'","''")+"'"
def sql(title,vals,cols):
    return (f"-- {title}\n-- Safe to run twice. Prices, Hold, Sold out and Season are NOT touched.\nbegin;\nwith m(old_name,old_variant,grp,sec,sec_ti,note,name,variant,sort) as (values\n"+",\n".join(vals)+"\n)\nupdate menu_items i set grp=m.grp,sec=m.sec,sec_ti=m.sec_ti,note=m.note,name=m.name,variant=m.variant,sort=m.sort\nfrom m where i.name=m.old_name and coalesce(i.variant,'')=m.old_variant;\ncommit;\n")
# forward: match on old name + old variant, or (if already run) new name + new variant -> make idempotent by matching either
fv=[];uv=[]
for (o,g,sec,ti,note,nn,nv,srt) in ups:
    fv.append(f"({q(o)},{q(rows[o]['v'])},{q(g)},{q(sec)},{q(ti)},{q(note)},{q(nn)},{q(nv)},{srt})")
for (nn,nv,og,os_,oti,on,o,ov,_) in undo:
    uv.append(f"({q(nn)},{q(nv)},{q(og)},{q(os_)},{q(oti)},{q(on)},{q(o)},{q(ov)},{oldsort[o]})")
open('sql/v3.9.sql','w',encoding='utf8').write(sql('BK menu v3.9: hotel-style reorganisation of menu_items (run after v3.5.sql)',fv,0)+"\n-- CHECK (expect 133, then 9 groups):\n-- select count(*) from menu_items;\n-- select grp,count(*) from menu_items group by grp order by min(sort);\n")
open('sql/v3.9-undo.sql','w',encoding='utf8').write(sql('BK menu v3.9 UNDO: puts the v3.8 layout back (only if you want to go back)',uv,0))
json.dump({'v':2,'cur':'UGX','pages':pages},open('site/menu.json','w',encoding='utf8'),ensure_ascii=False,separators=(',',':'))
for p in pages: print(p['g'],[(s['t'],len(s['items'])) for s in p['sections']])
