-- BK menu v2 migration. Run once in Supabase > SQL Editor, then reply "done".
create table if not exists staff(user_id uuid primary key references auth.users on delete cascade, role text default 'staff', pin_hash text, tries int default 0, locked_until timestamptz);
create table if not exists menu_items(id serial primary key, grp text, sec text, sec_ti text, note text, name text, variant text default '', d text default '', t text default '', price text default '', sold_out bool default false, hidden bool default false, sort int);
create table if not exists settings(key text primary key, value text);
create table if not exists audit_log(id serial primary key, at timestamptz default now(), who uuid, action text, detail text);
alter table staff enable row level security; alter table menu_items enable row level security; alter table settings enable row level security; alter table audit_log enable row level security;
create or replace function is_staff() returns bool language sql security definer stable as $$ select exists(select 1 from staff where user_id=auth.uid()) $$;
drop policy if exists mi_read on menu_items; create policy mi_read on menu_items for select using (not hidden or is_staff());
drop policy if exists st_read on settings; create policy st_read on settings for select using (true);
drop policy if exists al_read on audit_log; create policy al_read on audit_log for select using (is_staff());
create or replace function chk_pin(pin text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare s staff%rowtype; begin
 select * into s from staff where user_id=auth.uid(); if not found then return 'denied'; end if;
 if s.pin_hash is null then return 'not_set'; end if;
 if s.locked_until>now() then return 'locked'; end if;
 if s.pin_hash<>crypt(pin,s.pin_hash) then
  update staff set locked_until=case when tries+1>=3 then now()+interval '15 minutes' end, tries=case when tries+1>=3 then 0 else tries+1 end where user_id=auth.uid(); return 'bad_pin'; end if;
 update staff set tries=0 where user_id=auth.uid(); return 'ok'; end $$;
create or replace function set_pin(p text) returns text language plpgsql security definer set search_path=public,extensions as $$
begin if not is_staff() then return 'denied'; end if; if length(p)<4 then return 'invalid'; end if;
 if exists(select 1 from staff where user_id=auth.uid() and pin_hash is not null) then return 'reauth'; end if;
 update staff set pin_hash=crypt(p,gen_salt('bf')),tries=0 where user_id=auth.uid(); return 'ok'; end $$;
create or replace function staff_update_item(i int,p text,sold bool,hid bool,pin text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; begin w:=chk_pin(pin); if w<>'ok' then return w; end if;
 update menu_items set price=p,sold_out=sold,hidden=hid where id=i;
 insert into audit_log(who,action,detail) values(auth.uid(),'item '||i,'price '||p||', sold out '||sold||', hold '||hid); return 'ok'; end $$;
create or replace function set_banner(txt text,pin text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; begin w:=chk_pin(pin); if w<>'ok' then return w; end if;
 insert into settings values('banner',txt) on conflict (key) do update set value=excluded.value;
 insert into audit_log(who,action,detail) values(auth.uid(),'banner',txt); return 'ok'; end $$;
insert into menu_items(grp,sec,sec_ti,note,name,variant,d,t,price,sort) values
('Coffee','Coffee','ቡን','','Black Coffee','','Freshly brewed coffee served with steamed milk, sugar or honey.','ብትኩስ ወተት፣ ሽኮር ወይ መዓር ዝተዳለወ ሓድሽ ቡን።','5,000',1),
('Coffee','Coffee','ቡን','','African Coffee','','Freshly brewed African coffee prepared with milk and served with sugar or honey.','ብወተት ዝተዳለወን ብሽኮር ወይ መዓር ዝቐርብን ሓድሽ ኣፍሪቃዊ ቡን።','5,000',2),
('Coffee','Coffee','ቡን','','Lungo','','A smooth, longer espresso with a rich coffee finish.','ለስላሳ ነዊሕ ኤስፕረሶ ምስ ሃብታም ጣዕሚ ቡን።','4,000',3),
('Coffee','Coffee','ቡን','','Cappuccino','Single / Double','Espresso prepared with steamed milk and a generous layer of milk foam.','ኤስፕረሶ ምስ ትኩስ ወተትን ብዙሕ ፎም ወተትን።','5,000 / 6,000',4),
('Coffee','Coffee','ቡን','','Mocha','','Espresso blended with chocolate and steamed milk, finished with light foam.','ኤስፕረሶ ምስ ቸኮሌትን ትኩስ ወተትን፣ ብቀሊል ፎም ዝውዳእ።','6,000',5),
('Coffee','Coffee','ቡን','','Vanilla Latte','','Espresso blended with steamed milk and vanilla.','ኤስፕረሶ ምስ ትኩስ ወተትን ቫኒላን።','6,000',6),
('Coffee','Coffee','ቡን','','Macchiato','Single / Double','Espresso topped with a small amount of steamed milk foam.','ኤስፕረሶ ብትንሽ ፎም ወተት ዝተሸፈነ።','4,000 / 6,000',7),
('Coffee','Coffee','ቡን','','Cortado','','Espresso balanced with steamed milk for a smooth, rich flavour.','ኤስፕረሶ ምስ ትኩስ ወተት ተመጣጢኑ ዝቐርብ።','6,000',8),
('Coffee','Coffee','ቡን','','Caffè Latte','Single / Double','Freshly brewed espresso with steamed milk and a light layer of foam.','ሓድሽ ኤስፕረሶ ምስ ትኩስ ወተትን ቀሊል ፎምን።','5,000 / 6,000',9),
('Coffee','Coffee','ቡን','','Habesha Coffee','','Traditional Eritrean/Habesha-style coffee prepared from freshly roasted and brewed coffee.','ብባህላዊ ሓበሻዊ ኣገባብ ዝተጠበሰን ዝተፈልሐን ቡን።','2,000',10),
('Coffee','Coffee','ቡን','','Hot Chocolate','','Steamed milk blended with drinking chocolate and finished with light foam.','ትኩስ ወተት ምስ ቸኮሌት መስተ ተቐላቒሉ ብቀሊል ፎም ዝውዳእ።','6,000',11),
('Coffee','Toasted Specials','ናይ ንግሆ ምግብ','','Toasted Bread','','Freshly toasted bread served warm.','ትኩስ ባኒ ተጠቢሱ ብሙቐት ዝቐርብ።','8,000',12),
('Coffee','Toasted Specials','ናይ ንግሆ ምግብ','','Toasted Bread Special with Eggs','','Warm toasted bread served with eggs.','ብሙቐት ዝተጠበሰ ባኒ ምስ እንቋቑሖ።','10,000',13),
('Iced & Tea','Iced Coffee & Tea','ቀዝቃዛ ቡን','','Iced Americano','','Freshly brewed coffee served chilled over ice, with sugar or honey.','ሓድሽ ቡን ቀዝቒዙ ብበረድ ዝቐርብ፣ ምስ ሽኮር ወይ መዓር።','10,000',14),
('Iced & Tea','Iced Coffee & Tea','ቀዝቃዛ ቡን','','Iced Black Coffee','','Well-brewed coffee served chilled with ice and your choice of sugar or honey.','ብጽቡቕ ዝተፈለሐ ቡን ቀዝቒዙ ብበረድ ዝቐርብ።','10,000',15),
('Iced & Tea','Iced Coffee & Tea','ቀዝቃዛ ቡን','','Iced Caffè Latte','','Freshly brewed espresso with cold milk, served over ice.','ሓድሽ ኤስፕረሶ ምስ ዝቐዘቐዘ ወተት ብበረድ።','11,000',16),
('Iced & Tea','Iced Coffee & Tea','ቀዝቃዛ ቡን','','Iced Mocha','','Espresso blended with chocolate and milk, served chilled over ice.','ኤስፕረሶ ምስ ቸኮሌትን ወተትን ተቐላቒሉ ብበረድ ዝቐርብ።','11,000',17),
('Iced & Tea','Iced Coffee & Tea','ቀዝቃዛ ቡን','','Iced Chocolate','','Steamed milk blended with drinking chocolate, served over ice and topped with whipped cream.','ትኩስ ወተት ምስ ቸኮሌት ተቐላቒሉ ብበረድን ዊፕድ ክሪምን።','12,000',18),
('Iced & Tea','Iced Coffee & Tea','ቀዝቃዛ ቡን','','Iced Lemon Tea','','Fresh lemon and honey blended with tea and served chilled over ice.','ሓድሽ ሎሚን መዓርን ምስ ሻሂ ተቐላቒሉ ብበረድ።','12,000',19),
('Iced & Tea','Iced Coffee & Tea','ቀዝቃዛ ቡን','','Iced Pineapple Tea','','Pineapple and honey infused tea served chilled with ice.','ኣናናስን መዓርን ዝተቐላቐለ ሻሂ ብበረድ።','12,000',20),
('Iced & Tea','Teas','ሻሂ','','Black Tea','','A refreshing blend of tea leaves served with sugar or honey.','ዝሑል ዘይኮነ ሻሂ ብሽኮር ወይ መዓር ዝቐርብ።','5,000',21),
('Iced & Tea','Teas','ሻሂ','','African Tea','','African tea leaves prepared with or without spices and served with sugar or honey.','ኣፍሪቃዊ ቅጠል ሻሂ ምስ ወይ ብዘይ ቀመማት፣ ብሽኮር ወይ መዓር።','7,000',22),
('Iced & Tea','Teas','ሻሂ','','Ginger Tea','','Fresh ginger infused in hot water and served with honey.','ሓድሽ ዝንጅብል ብሙቐት ማይ ዝተኣለመ ምስ መዓር።','6,000',23),
('Iced & Tea','Teas','ሻሂ','','Hibiscus Tea','','Hibiscus infused in hot water and served with honey.','ሂቢስከስ ብሙቐት ማይ ዝተኣለመ ምስ መዓር።','6,000',24),
('Iced & Tea','Teas','ሻሂ','','Lemon Tea','','Fresh lemon infused in hot water and served with honey.','ሓድሽ ሎሚ ብሙቐት ማይ ዝተኣለመ ምስ መዓር።','7,000',25),
('Iced & Tea','Teas','ሻሂ','','Mint Tea','','Fresh mint infused in hot water and served with honey.','ሓድሽ ሚንት ብሙቐት ማይ ዝተኣለመ ምስ መዓር።','7,000',26),
('Iced & Tea','Teas','ሻሂ','','Classic Dawa Tea','','A warming blend of honey, lemon, black pepper and ginger with hot water.','መዓር፣ ሎሚ፣ ጸሊም በርበረን ዝንጅብልን ምስ ትኩስ ማይ።','7,000',27),
('Iced & Tea','Teas','ሻሂ','','Mint Dawa Tea','','A refreshing blend of fresh ginger, mint and lemon served with honey.','ሓድሽ ዝንጅብል፣ ሚንትን ሎሚን ምስ መዓር።','7,000',28),
('Iced & Tea','Teas','ሻሂ','','Cinnamon Garlic Dawa Tea','','A warming blend of honey, lemon, black pepper, ginger, garlic and cinnamon with hot water.','መዓር፣ ሎሚ፣ ጸሊም በርበረ፣ ዝንጅብል፣ ሽጉርቲን ቀረፋን ምስ ትኩስ ማይ።','8,000',29),
('Juices','Fruit Juices','ጭማቂ ፍሩታት','','Mango Blast','','A blend of pure mango fruit juice with a dash of milk or ice cream.','ንጹህ ጭማቂ ማንጎ ምስ ትንሽ ወተት ወይ ኣይስ ክሪም።','10,000',30),
('Juices','Fruit Juices','ጭማቂ ፍሩታት','','Passion Juice','','A blend of pure passion fruit juice and water.','ንጹህ ጭማቂ ፓሽን ፍሩት ምስ ማይ።','7,000',31),
('Juices','Fruit Juices','ጭማቂ ፍሩታት','','Watermelon Juice','','Pure watermelon fruit juice and water.','ንጹህ ጭማቂ ሓርማዝ ምስ ማይ።','7,000',32),
('Juices','Fruit Juices','ጭማቂ ፍሩታት','','Kiwi Juice','','Fresh kiwi fruit juice.','ሓድሽ ጭማቂ ኪዊ።','11,000',33),
('Juices','Fruit Juices','ጭማቂ ፍሩታት','','Carrot Juice','','Fresh carrot juice.','ሓድሽ ጭማቂ ካሮት።','7,000',34),
('Juices','Fruit Juices','ጭማቂ ፍሩታት','','Pure Apple','','A blend of pure apple fruit juice and a dash of water.','ንጹህ ጭማቂ ኣፕል ምስ ትንሽ ማይ።','9,000',35),
('Juices','Fruit Juices','ጭማቂ ፍሩታት','','Pure Orange','','A blend of pure orange fruit juice and water.','ንጹህ ጭማቂ ብርቱካን ምስ ማይ።','9,000',36),
('Juices','Fruit Juices','ጭማቂ ፍሩታት','','Passion Mix','','A quality blend of passion, mango, ginger and lemon.','ፓሽን፣ ማንጎ፣ ዝንጅብልን ሎሚን ዝተቐላቐለ።','9,000',37),
('Juices','Fruit Juices','ጭማቂ ፍሩታት','','Hibiscus Juice','','A quality blend of hibiscus and water.','ሂቢስከስ ምስ ማይ ዝተቐላቐለ ጭማቂ።','7,000',38),
('Juices','Fruit Juices','ጭማቂ ፍሩታት','','Beetroot Mix','','A blend of beetroot, ginger, watermelon and passion.','ቤትሩት፣ ዝንጅብል፣ ሓርማዝን ፓሽንን ዝተቐላቐለ።','9,000',39),
('Juices','Fruit Juices','ጭማቂ ፍሩታት','','Cocktail Juice','','A blend of pure orange, apple, pineapple and passion fruit juices.','ንጹህ ጭማቂ ብርቱካን፣ ኣፕል፣ ኣናናስን ፓሽን ፍሩትን ዝተቐላቐለ።','11,000',40),
('Juices','Fruit Juices','ጭማቂ ፍሩታት','','Pineapple Juice','','Fresh pineapple juice.','ሓድሽ ጭማቂ ኣናናስ።','9,000',41),
('Juices','Fruit Juices','ጭማቂ ፍሩታት','','Mango Juice','','Fresh mango juice.','ሓድሽ ጭማቂ ማንጎ።','7,000',42),
('Juices','Fruit Juices','ጭማቂ ፍሩታት','','Lemon Juice','','Fresh lemon juice.','ሓድሽ ጭማቂ ሎሚ።','7,000',43),
('Juices','Fruit Juices','ጭማቂ ፍሩታት','','Red Rush','','A refreshing red fruit juice blend.','ዝተፈላለዩ ቀይሕ ፍሩት ጭማቂታት ዝተቐላቐሉ።','11,000',44),
('Shakes','Milkshakes','ሚልክሼክ','Every milkshake · UGX 14,000','Vanilla Milkshake','','A creamy blend of vanilla ice cream and milk, finished with syrup.','ቫኒላ ኣይስ ክሪምን ወተትን ብሲሮፕ ዝተወደአ ክሬሚ ምትሕውዋስ።','',45),
('Shakes','Milkshakes','ሚልክሼክ','Every milkshake · UGX 14,000','Chocolate Milkshake','','A rich blend of chocolate ice cream and milk, finished with chocolate sauce.','ቸኮሌት ኣይስ ክሪምን ወተትን ምስ ቸኮሌት ሶስ።','',46),
('Shakes','Milkshakes','ሚልክሼክ','Every milkshake · UGX 14,000','Strawberry Milkshake','','A creamy blend of strawberry ice cream, milk and fresh strawberry flavour.','ስትሮበሪ ኣይስ ክሪም፣ ወተትን ስትሮበሪን ዝተቐላቐለ።','',47),
('Shakes','Milkshakes','ሚልክሼክ','Every milkshake · UGX 14,000','Oreo Milkshake','','A creamy blend of vanilla ice cream, milk and Oreo cookies.','ቫኒላ ኣይስ ክሪም፣ ወተትን ኦሪዮ ብስኩትን ዝተቐላቐለ።','',48),
('Shakes','Milkshakes','ሚልክሼክ','Every milkshake · UGX 14,000','Banana Milkshake','','A creamy blend of banana, vanilla ice cream and milk.','ባናና፣ ቫኒላ ኣይስ ክሪምን ወተትን ዝተቐላቐለ።','',49),
('Shakes','Milkshakes','ሚልክሼክ','Every milkshake · UGX 14,000','Mango Milkshake','','A creamy blend of mango, vanilla ice cream and milk, finished with syrup.','ማንጎ፣ ቫኒላ ኣይስ ክሪምን ወተትን ምስ ሲሮፕ።','',50),
('Shakes','Milkshakes','ሚልክሼክ','Every milkshake · UGX 14,000','Tropical Milkshake','','A creamy blend of tropical fruit flavours, vanilla ice cream and milk.','ትሮፒካል ፍሩት፣ ቫኒላ ኣይስ ክሪምን ወተትን ዝተቐላቐለ።','',51),
('Shakes','Milkshakes','ሚልክሼክ','Every milkshake · UGX 14,000','Mocha Milkshake','','A creamy blend of vanilla ice cream, coffee and chocolate sauce.','ቫኒላ ኣይስ ክሪም፣ ቡንን ቸኮሌት ሶስን ዝተቐላቐለ።','',52),
('Shakes','Milkshakes','ሚልክሼክ','Every milkshake · UGX 14,000','Caramel Milkshake','','A creamy blend of caramel ice cream and milk with caramel and chocolate sauce.','ካራሜል ኣይስ ክሪምን ወተትን ምስ ካራሜልን ቸኮሌት ሶስን።','',53),
('Smoothies','Smoothies','ስሙዚ','Every smoothie · UGX 17,000','Vanilla Smoothie','','A smooth blend of yoghurt and vanilla ice cream, finished with syrup.','ዮገርትን ቫኒላ ኣይስ ክሪምን ምስ ሲሮፕ ዝተቐላቐለ።','',54),
('Smoothies','Smoothies','ስሙዚ','Every smoothie · UGX 17,000','Strawberry Smoothie','','A refreshing blend of yoghurt, ice cream and fresh strawberries.','ዮገርት፣ ኣይስ ክሪምን ሓድሽ ስትሮበሪን ዝተቐላቐለ።','',55),
('Smoothies','Smoothies','ስሙዚ','Every smoothie · UGX 17,000','Mango Smoothie','','A smooth blend of yoghurt, vanilla ice cream and mango juice.','ዮገርት፣ ቫኒላ ኣይስ ክሪምን ጭማቂ ማንጎን ዝተቐላቐለ።','',56),
('Smoothies','Smoothies','ስሙዚ','Every smoothie · UGX 17,000','Banana Smoothie','','A creamy blend of yoghurt, vanilla ice cream and fresh banana.','ዮገርት፣ ቫኒላ ኣይስ ክሪምን ሓድሽ ባናናን ዝተቐላቐለ።','',57),
('Smoothies','Smoothies','ስሙዚ','Every smoothie · UGX 17,000','Oreo Smoothie','','A creamy blend of yoghurt, vanilla ice cream and Oreo cookies.','ዮገርት፣ ቫኒላ ኣይስ ክሪምን ኦሪዮ ብስኩትን ዝተቐላቐለ።','',58),
('Smoothies','Smoothies','ስሙዚ','Every smoothie · UGX 17,000','Tropical Smoothie','','A blend of yoghurt, vanilla ice cream, banana, mango and passion fruit, finished with syrup.','ዮገርት፣ ቫኒላ ኣይስ ክሪም፣ ባናና፣ ማንጎን ፓሽን ፍሩትን ምስ ሲሮፕ።','',59),
('Smoothies','Smoothies','ስሙዚ','Every smoothie · UGX 17,000','Sweet Dreams','','A blend of banana, mango, strawberry, almond milk and plain yoghurt, finished with syrup.','ባናና፣ ማንጎ፣ ስትሮበሪ፣ ናይ ኣልሞንድ ወተትን ፕሌይን ዮገርትን ምስ ሲሮፕ።','',60),
('Smoothies','Smoothies','ስሙዚ','Every smoothie · UGX 17,000','Princess Moana','','A tropical blend of mango, vanilla ice cream, yoghurt, banana, almond milk and honey.','ማንጎ፣ ቫኒላ ኣይስ ክሪም፣ ዮገርት፣ ባናና፣ ናይ ኣልሞንድ ወተትን መዓርን።','',61),
('Smoothies','Smoothies','ስሙዚ','Every smoothie · UGX 17,000','Green Goddess','','A fresh blend of banana, spinach, avocado, almond milk and plain yoghurt.','ባናና፣ ስፒናች፣ ኣቮካዶ፣ ናይ ኣልሞንድ ወተትን ፕሌይን ዮገርትን።','',62),
('Beer & Soft','Beers','ቢራ','','Tusker Malt','','','','5,000',63),
('Beer & Soft','Beers','ቢራ','','Tusker Lite','','','','5,000',64),
('Beer & Soft','Beers','ቢራ','','Castle Lite','','','','5,000',65),
('Beer & Soft','Beers','ቢራ','','Tusker Cider','','','','6,000',66),
('Beer & Soft','Beers','ቢራ','','Club','','','','6,000',67),
('Beer & Soft','Beers','ቢራ','','Bell','','','','6,000',68),
('Beer & Soft','Beers','ቢራ','','Nile','','','','6,000',69),
('Beer & Soft','Beers','ቢራ','','Tusker Lager','','','','6,000',70),
('Beer & Soft','Beers','ቢራ','','Guinness','','','','6,000',71),
('Beer & Soft','Beers','ቢራ','','Heineken','','','','10,000',72),
('Beer & Soft','Soft Drinks & Mixers','ልስሉስ መስተዋት','','Sodas','','','','2,000',73),
('Beer & Soft','Soft Drinks & Mixers','ልስሉስ መስተዋት','','Soda Water','','','','3,000',74),
('Beer & Soft','Soft Drinks & Mixers','ልስሉስ መስተዋት','','Tonic Water','','','','3,000',75),
('Beer & Soft','Soft Drinks & Mixers','ልስሉስ መስተዋት','','Sting','','','','3,000',76),
('Whisky','Whisky','','','Bond 7','','','','60,000',77),
('Whisky','Whisky','','','Black & White','','','','80,000',78),
('Whisky','Whisky','','','Ballantine''s 750ml','','','','100,000',79),
('Whisky','Whisky','','','Ballantine''s 1L','','','','120,000',80),
('Whisky','Whisky','','','Red Label','','','','120,000',81),
('Whisky','Whisky','','','Grants 1L','','','','120,000',82),
('Whisky','Whisky','','','Jameson 1L','','','','180,000',83),
('Whisky','Whisky','','','Jack Daniel''s','','','','200,000',84),
('Whisky','Whisky','','','Black Label','','','','220,000',85),
('Whisky','Whisky','','','Double Black','','','','250,000',86),
('Whisky','Whisky','','','Gold Label 750ml','','','','250,000',87),
('Whisky','Whisky','','','Chivas Regal 12 Years','','','','280,000',88),
('Whisky','Whisky','','','Gold Label 1L','','','','350,000',89),
('Whisky','Whisky','','','Singleton 15 Years','','','','350,000',90),
('Whisky','Whisky','','','Glenfiddich 12 Years','','','','380,000',91),
('Whisky','Whisky','','','Bonfire Whisky','200ml','','','10,000',92),
('Spirits','Vodka','','','CHR-One Vodka','','','','50,000',93),
('Spirits','Vodka','','','Absolut Vodka','','','','130,000',94),
('Spirits','Vodka','','','Smirnoff','','','','130,000',95),
('Spirits','Vodka','','','Absolut Raspberry','','','','140,000',96),
('Spirits','Vodka','','','Grey Goose 1L','','','','250,000',97),
('Spirits','Vodka','','','Cîroc 1L','','','','250,000',98),
('Spirits','Brandy / Cognac','','','V&A','','','','50,000',99),
('Spirits','Brandy / Cognac','','','Hennessy','','','','130,000',100),
('Spirits','Brandy / Cognac','','','Rémy Martin','','','','400,000',101),
('Spirits','Tequila','','','José Cuervo','','','','150,000',102),
('Spirits','Tequila','','','Olmeca','','','','180,000',103),
('Spirits','Tequila','','','Don Julio','','','','450,000',104),
('Spirits','Gin','','','Uganda Waragi 200ml','','','','6,000',105),
('Spirits','Gin','','','Jingle''s Gin','','','','10,000',106),
('Spirits','Gin','','','Uganda Waragi Premium','','','','50,000',107),
('Spirits','Gin','','','Gilbey''s Gin','','','','60,000',108),
('Spirits','Gin','','','Uganda Waragi Lemon & Ginger','','','','60,000',109),
('Spirits','Gin','','','Gordon''s Gin 750ml','','','','80,000',110),
('Spirits','Gin','','','Gordon''s Gin 1L','','','','130,000',111),
('Spirits','Rum','','','Captain Morgan Gold 750ml','','','','60,000',112),
('Spirits','Rum','','','Captain Morgan Black 750ml','','','','60,000',113),
('Spirits','Rum','','','Malibu','','','','120,000',114),
('Spirits','Rum','','','Bacardi','','','','130,000',115),
('Wine','Wine','','','Well In Town','','','','40,000',116),
('Wine','Wine','','','Sweet Kiss','','','','50,000',117),
('Wine','Wine','','','J.C','','','','60,000',118),
('Wine','Wine','','','Four Cousins','','','','70,000',119),
('Wine','Wine','','','Perdeberg Cellar','','','','70,000',120),
('Wine','Wine','','','Roma','','','','70,000',121),
('Wine','Wine','','','KHV','','','','80,000',122),
('Wine','Wine','','','Nederburg','','','','90,000',123),
('Wine','Wine','','','B&G','','','','90,000',124),
('Wine','Areqi','','','Areqi — Shot','','','','7,000',125),
('Wine','Areqi','','','Areqi — Bottle','','','','100,000',126),
('Wine','Liqueurs','','','Baileys 375ml','','','','80,000',127),
('Wine','Liqueurs','','','Baileys 750ml','','','','120,000',128),
('Wine','Liqueurs','','','Amarula','','','','120,000',129),
('Wine','Liqueurs','','','Jägermeister','','','','150,000',130),
('Wine','Champagne / Other','','','High-5','','','','5,000',131),
('Wine','Champagne / Other','','','Sierra','','','','180,000',132),
('Wine','Champagne / Other','','','Moët & Chandon','','','','300,000',133);
-- After creating the staff users in Authentication > Users, make them staff:
-- insert into staff(user_id,role) select id,'admin' from auth.users where email in ('OWNER@EMAIL','STAFF@EMAIL');
