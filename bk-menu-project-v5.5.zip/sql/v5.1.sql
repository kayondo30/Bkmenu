-- BK menu v5.1: add, edit and delete drinks from the staff screen (needs v2.sql, v3.1.sql and v3.5.sql run before).
-- Run once in a NEW query tab in Supabase (SQL Editor), then reply "done". Safe to run twice. Guests see nothing new until staff add a drink.
create or replace function staff_add_item(g text,s text,nm text,va text,de text,ti text,p text,hid bool,pin text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; m int; sti text; nte text; begin w:=chk_pin(pin); if w<>'ok' then return w; end if;
 if coalesce(trim(nm),'')='' or coalesce(trim(g),'')='' or coalesce(trim(s),'')='' then return 'missing'; end if;
 select max(sort),max(sec_ti),max(note) into m,sti,nte from menu_items where grp=g and sec=s;
 if m is null then select max(sort) into m from menu_items where grp=g; end if;
 if m is null then select coalesce(max(sort),0) into m from menu_items; end if;
 update menu_items set sort=sort+1 where sort>m;
 insert into menu_items(grp,sec,sec_ti,note,name,variant,d,t,price,sold_out,hidden,sort) values(g,s,coalesce(sti,''),coalesce(nte,''),trim(nm),coalesce(va,''),coalesce(de,''),coalesce(ti,''),coalesce(p,''),false,coalesce(hid,false),m+1);
 insert into audit_log(who,action,detail) values(auth.uid(),'add',trim(nm)||' in '||g||' / '||s||', price '||coalesce(p,'')); return 'ok'; end $$;
create or replace function staff_edit_item(i int,nm text,va text,de text,ti text,pin text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; begin w:=chk_pin(pin); if w<>'ok' then return w; end if;
 if coalesce(trim(nm),'')='' then return 'missing'; end if;
 update menu_items set name=trim(nm),variant=coalesce(va,''),d=coalesce(de,''),t=coalesce(ti,'') where id=i;
 insert into audit_log(who,action,detail) values(auth.uid(),'edit '||i,trim(nm)); return 'ok'; end $$;
create or replace function staff_delete_item(i int,pin text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; n text; begin w:=chk_pin(pin); if w<>'ok' then return w; end if;
 select name into n from menu_items where id=i; delete from menu_items where id=i;
 insert into audit_log(who,action,detail) values(auth.uid(),'delete',coalesce(n,'item '||i)); return 'ok'; end $$;
-- Check (should give 3 rows): select proname from pg_proc where proname in ('staff_add_item','staff_edit_item','staff_delete_item');
