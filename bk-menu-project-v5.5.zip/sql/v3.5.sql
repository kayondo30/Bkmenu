-- BK menu v3.5 (needs v2.sql, v3.sql and v3.1.sql run first). Run once in a NEW query tab, then reply "done".
-- Safe to run twice. Adds: scheduled specials, seasons, staff list. Older site copies keep working.
alter table specials add column if not exists starts_at timestamptz;
alter table specials add column if not exists ends_at timestamptz;
create table if not exists seasons(id serial primary key, name text not null, name_ti text default '', active bool default true, starts_at timestamptz, ends_at timestamptz, sort int default 0);
alter table seasons enable row level security;
alter table menu_items add column if not exists season_id int references seasons(id) on delete set null;
create or replace function window_live(a bool,s timestamptz,e timestamptz) returns bool language sql stable as $$ select coalesce(a,true) and (s is null or s<=now()) and (e is null or e>now()) $$;
create or replace function season_live(sid int) returns bool language sql security definer stable set search_path=public as $$ select sid is null or exists(select 1 from seasons where id=sid and window_live(active,starts_at,ends_at)) $$;
drop policy if exists sea_read on seasons; create policy sea_read on seasons for select using (window_live(active,starts_at,ends_at) or is_staff());
drop policy if exists sp_read on specials; create policy sp_read on specials for select using (window_live(active,starts_at,ends_at) or is_staff());
drop policy if exists mi_read on menu_items; create policy mi_read on menu_items for select using ((not hidden and season_live(season_id)) or is_staff());
create or replace function staff_save_special2(i int,ttl text,te text,tt text,pr text,pk bool,act bool,st timestamptz,en timestamptz,pin text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; begin w:=chk_pin(pin); if w<>'ok' then return w; end if;
 if i=0 then insert into specials(title,text_en,text_ti,price,pick,active,starts_at,ends_at,sort) values(ttl,te,tt,pr,pk,act,st,en,(select coalesce(max(sort),0)+1 from specials));
 else update specials set title=ttl,text_en=te,text_ti=tt,price=pr,pick=pk,active=act,starts_at=st,ends_at=en where id=i; end if;
 insert into audit_log(who,action,detail) values(auth.uid(),'special',ttl); return 'ok'; end $$;
create or replace function staff_save_season(i int,nm text,nt text,act bool,st timestamptz,en timestamptz,pin text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; begin w:=chk_pin(pin); if w<>'ok' then return w; end if;
 if i=0 then insert into seasons(name,name_ti,active,starts_at,ends_at,sort) values(nm,nt,act,st,en,(select coalesce(max(sort),0)+1 from seasons));
 else update seasons set name=nm,name_ti=nt,active=act,starts_at=st,ends_at=en where id=i; end if;
 insert into audit_log(who,action,detail) values(auth.uid(),'season',nm); return 'ok'; end $$;
create or replace function staff_update_item2(i int,p text,sold bool,hid bool,sid int,pin text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; begin w:=chk_pin(pin); if w<>'ok' then return w; end if;
 update menu_items set price=p,sold_out=sold,hidden=hid,season_id=sid where id=i;
 insert into audit_log(who,action,detail) values(auth.uid(),'item '||i,'price '||p||', sold out '||sold||', hold '||hid||', season '||coalesce(sid::text,'none')); return 'ok'; end $$;
create or replace function list_staff() returns table(email text,role text,pin_set bool,locked bool) language sql security definer stable set search_path=public as $$
 select u.email::text, s.role, (s.pin_hash is not null), coalesce(s.locked_until>now(),false) from staff s join auth.users u on u.id=s.user_id where is_staff() order by u.email $$;
