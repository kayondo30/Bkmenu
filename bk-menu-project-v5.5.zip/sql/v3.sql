-- BK menu v3 migration (needs v2.sql run first). Run once in a NEW query tab, then reply "done".
create table if not exists specials(id serial primary key, title text, text_en text default '', text_ti text default '', price text default '', pick bool default false, active bool default true, sort int default 0);
alter table specials enable row level security;
drop policy if exists sp_read on specials; create policy sp_read on specials for select using (active or is_staff());
create or replace function staff_save_special(i int,ttl text,te text,tt text,pr text,pk bool,act bool,pin text) returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; begin w:=chk_pin(pin); if w<>'ok' then return w; end if;
 if i=0 then insert into specials(title,text_en,text_ti,price,pick,active,sort) values(ttl,te,tt,pr,pk,act,(select coalesce(max(sort),0)+1 from specials));
 else update specials set title=ttl,text_en=te,text_ti=tt,price=pr,pick=pk,active=act where id=i; end if;
 insert into audit_log(who,action,detail) values(auth.uid(),'special',ttl); return 'ok'; end $$;
