-- BK menu v3.1 (needs v2.sql and v3.sql run first). Adds verify_pin for the lock screen. Run once in a NEW query tab, then reply "done".
create or replace function verify_pin(pin text) returns text language plpgsql security definer set search_path=public,extensions as $$
begin return chk_pin(pin); end $$;
