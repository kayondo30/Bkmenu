// node tools/test_waiter.js : runs waiter.html and the admin Waiters sheet in headless Chrome with a pretend Supabase (v7.1, part 7b).
const {chromium}=require(process.env.PW||'/home/claude/.npm-global/lib/node_modules/playwright');
const http=require('http'),fs=require('fs'),path=require('path');
const SITE=path.join(__dirname,'../site');
const MIME={'.html':'text/html','.js':'text/javascript','.json':'application/json','.png':'image/png','.woff':'font/woff'};
const srv=http.createServer((q,r)=>{let u=decodeURIComponent(q.url.split('?')[0]);const f=path.join(SITE,u);fs.readFile(f,(e,b)=>{if(e){r.writeHead(404);r.end();return}r.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});r.end(b)})});
let pass=0,fail=0;const ok=(c,m)=>{if(c){pass++;console.log('  ok  ',m)}else{fail++;console.log('  FAIL',m)}};
const b64=o=>Buffer.from(JSON.stringify(o)).toString('base64url');
(async()=>{await new Promise(r=>srv.listen(0,r));const base='http://localhost:'+srv.address().port;
 const br=await chromium.launch(),ctx=await br.newContext({viewport:{width:390,height:800}}),pg=await ctx.newPage();
 const calls=[],steps=[];let tables=[];let logged=false;
 await pg.route('https://qeudronebisrlcqerwvz.supabase.co/**',async route=>{const u=new URL(route.request().url()),m=route.request().method(),fn=u.pathname.split('/').pop();
  const J=b=>route.fulfill({status:200,headers:{'access-control-allow-origin':'*','content-type':'application/json'},body:JSON.stringify(b)});
  if(m==='OPTIONS')return route.fulfill({status:204,headers:{'access-control-allow-origin':'*','access-control-allow-headers':'*','access-control-allow-methods':'*'}});
  const body=route.request().postData()?JSON.parse(route.request().postData()):{};calls.push([fn,body]);
  if(fn==='waiter_login')return J(body.pin==='1234'?{r:'ok',token:'11111111-1111-1111-1111-111111111111',name:'Sara'}:{r:'bad_login'});
  if(fn==='waiter_tables')return J({r:'ok',tables});
  if(fn==='waiter_open_table'){if(body.tbl==='9')return J({r:'table_busy'});
   if(body.kind==='room'){if(!body.tbl)return J({r:'need_room'});if(tables.some(x=>x.table_label==='Room '+body.tbl))return J({r:'table_busy'});const id=20+tables.length;tables.push({id,kind:'room',table_label:'Room '+body.tbl,code:'5'+String(id).padStart(3,'0'),opened_at:new Date().toISOString(),total:0,guests:[]});return J({r:'ok',id,code:'5'+String(id).padStart(3,'0')})}
   if(body.kind==='takeaway'){const id=40+tables.length,c='6'+String(id).padStart(3,'0');tables.push({id,kind:'takeaway',table_label:'Take away '+c+(body.tbl?' - '+body.tbl:''),code:c,opened_at:new Date().toISOString(),total:0,guests:[]});return J({r:'ok',id,code:c})}
   tables.push({id:7,kind:'table',table_label:body.tbl||'4719',code:'4719',opened_at:new Date().toISOString(),total:0,guests:[]});return J({r:'ok',id:7,code:'4719'})}
  if(fn==='waiter_close_table'){tables=[];return J('ok')}
  if(fn==='waiter_new_master'){const x=tables.find(y=>y.id===body.sid);if(!x)return J('not_found');x.paired=false;x.code='7351';x.guests.forEach(g=>{if(g.master)g.removed=true});return J({r:'ok',code:'7351'})}
  if(fn==='waiter_remove_guest'){const x=tables.find(y=>y.id===body.sid),g=x&&x.guests.find(y=>y.num===body.gnum&&!y.removed);if(!g)return J('not_found');if(g.master)return J('is_master');g.removed=true;return J('ok')}
  if(fn==='waiter_order_step'){steps.push(body);tables.forEach(x=>x.guests.forEach(g=>g.orders.forEach(o=>{if(o.id===body.ord_id)o.status=body.st})));return J('ok')}
  if(fn==='waiter_logout')return J('ok');
  return J([]);});
 await pg.goto(base+'/waiter.html');
 ok(await pg.locator('#n').count()===1,'login screen shows');
 await pg.fill('#n','Sara');await pg.fill('#p','0000');await pg.click('#g');await pg.waitForTimeout(300);
 ok(/Wrong name or PIN/.test(await pg.textContent('#msg')),'wrong PIN is refused');
 await pg.fill('#p','1234');await pg.click('#g');await pg.waitForSelector('#op');
 ok(/Hello, Sara/.test(await pg.textContent('#a')),'login works');
 ok(await pg.locator('#tn').count()===0,'no table number box any more');
 await pg.click('#op');ok(calls.filter(c=>c[0]==='waiter_open_table').every(c=>!c[1].tbl),'no table number is sent');await pg.waitForSelector('.code');
 ok((await pg.textContent('.code'))==='4719'&&/Table 4719/.test(await pg.textContent('#ls')),'code and table shown');
 // v7.4 (7d) Orders screen
 tables[0].guests=[{num:2,pay:'Cash',orders:[{id:31,status:'sent',at:new Date().toISOString(),lines:[{name:'Lungo',qty:2,price:4000},{name:'Mocha',qty:3,price:6000}]}]}];tables[0].total=26000;
 await pg.evaluate(()=>refresh(true));await pg.waitForSelector('.nw');
 ok(/Table 4719/.test(await pg.textContent('#nw'))&&/Guest 2/.test(await pg.textContent('#nw'))&&/Lungo/.test(await pg.textContent('#nw')),'new order shows on top with table, guest and drinks');
 ok(/Waiting for you/.test(await pg.textContent('#ls')),'table card marks it as waiting');
 ok(/26,000/.test(await pg.textContent('#ls')),'waiter sees the table total');
 ok((await pg.title()).startsWith('(1)'),'tab title counts unconfirmed orders');
 await pg.click('#nw [data-o]');await pg.waitForFunction(()=>!document.querySelector('.nw'));
 ok(steps.length===1&&steps[0].st==='received'&&steps[0].ord_id===31,'Confirmed taps waiter_order_step received');
 ok(/Confirmed/.test(await pg.textContent('#ls'))&&await pg.locator('#ls [data-s="preparing"]').count()===1,'confirmed order offers the Preparing step');
 await pg.click('#ls [data-s="preparing"]');await pg.waitForSelector('#ls [data-s="on_the_way"]');await pg.click('#ls [data-s="on_the_way"]');await pg.waitForSelector('#ls [data-s="served"]');await pg.click('#ls [data-s="served"]');
 await pg.waitForFunction(()=>!document.querySelector('#ls [data-o]'));
 ok(steps.map(s=>s.st).join()==='received,preparing,on_the_way,served','steps go received, preparing, on the way, served');
 ok(/Served/.test(await pg.textContent('#ls')),'served order stays listed, no more buttons');
 tables[0].guests[0].orders[0].lines[0].vote=-1;await pg.evaluate(()=>refresh());await pg.waitForFunction(()=>/ask the guest/.test(document.querySelector('#ls').textContent));
 ok(/ask the guest/.test(await pg.textContent('#ls')),'waiter sees a thumbs down: ask the guest');
 tables[0].guests[0].orders[0].lines[0].vote=1;await pg.evaluate(()=>refresh());await pg.waitForFunction(()=>!/ask the guest/.test(document.querySelector('#ls').textContent));
 ok(!/ask the guest/.test(await pg.textContent('#ls')),'the warning goes when the guest changes to thumbs up');
 tables[0].guests[0].orders.push({id:32,status:'sent',at:new Date().toISOString(),lines:[{name:'Tea',qty:1,price:3000}]});
 await pg.evaluate(()=>refresh(true));await pg.waitForSelector('.nw');
 await pg.click('#ls [data-c]');ok(/NOT confirmed/.test(await pg.textContent('#ls [data-c]')),'closing with an unconfirmed order warns');
 tables[0].guests[0].orders.pop();await pg.evaluate(()=>refresh(true));
 ok(await pg.locator('#sd').count()===1,'sound button is there');
 await pg.click('[data-c]');ok(await pg.locator('[data-c]').count()===1&&!calls.some(c=>c[0]==='waiter_close_table'),'first tap only asks to confirm');
 await pg.click('[data-c]');await pg.waitForFunction(()=>/No open tables/.test(document.querySelector('#ls').textContent));
 ok(calls.some(c=>c[0]==='waiter_close_table'),'second tap closes the table');
 await pg.reload();await pg.waitForSelector('#op');ok(/Hello, Sara/.test(await pg.textContent('#a')),'stays logged in after reload');
 // v9.1 (9b) Room service and Take away
 ok(await pg.locator('#rm').count()===1&&await pg.locator('#ta').count()===1,'Room service and Take away buttons are there');
 ok(calls.filter(c=>c[0]==='waiter_open_table').every(c=>!('kind' in c[1])),'plain New table sends no kind (works before and after v9.0.sql)');
 await pg.click('#rm');await pg.waitForSelector('#kv');ok(/Room number/.test(await pg.textContent('#kf')),'Room service asks for the room number');
 const nOpen=()=>calls.filter(c=>c[0]==='waiter_open_table').length,n0=nOpen();
 await pg.click('#kg');ok(/Type the room number/.test(await pg.textContent('#msg'))&&nOpen()===n0,'blank room number is refused, nothing sent');
 await pg.fill('#kv','12');await pg.click('#kg');await pg.waitForFunction(()=>/Room 12/.test(document.querySelector('#ls').textContent));
 const rc=calls.filter(c=>c[0]==='waiter_open_table').pop()[1];ok(rc.kind==='room'&&rc.tbl==='12','room opens with kind room and room 12');
 ok(/Room 12/.test(await pg.textContent('#ls'))&&!/Table Room/.test(await pg.textContent('#ls')),'card says Room 12, not Table Room 12');
 ok(/Give the guests code 5/.test(await pg.textContent('#msg')),'waiter is told the code');
 await pg.click('#rm');await pg.fill('#kv','12');await pg.click('#kg');await pg.waitForTimeout(300);ok(/room is already open/.test(await pg.textContent('#msg')),'same room twice: that room is already open');
 await pg.click('#kg').catch(()=>{});
 await pg.click('#ta');await pg.waitForSelector('#kv');ok(/Name \(optional\)/.test(await pg.textContent('#kf')),'Take away asks for an optional name');
 await pg.fill('#kv','Sam');await pg.click('#kg');await pg.waitForFunction(()=>/Take away/.test(document.querySelector('#ls').textContent));
 const tc=calls.filter(c=>c[0]==='waiter_open_table').pop()[1];ok(tc.kind==='takeaway'&&tc.tbl==='Sam','take away opens with kind takeaway and the name');
 ok(/Take away 6\d+ - Sam/.test(await pg.textContent('#ls')),'card says Take away with the code and name');
 const rt=tables.find(x=>x.kind==='room');rt.guests=[{num:1,pay:null,orders:[{id:81,status:'sent',at:new Date().toISOString(),lines:[{name:'Tea',qty:2,price:3000}]}]}];
 await pg.evaluate(()=>refresh(true));await pg.waitForSelector('.nw');
 ok(/Room 12 \u00b7 Guest 1/.test(await pg.textContent('#nw'))&&!/Table Room/.test(await pg.textContent('#nw')),'new order from a room shows Room 12 · Guest 1');
 // v9.4 (H2) host phone
 rt.guests=[{num:1,master:true,removed:false,orders:[]},{num:2,removed:false,orders:[]},{num:3,removed:false,orders:[]}];rt.paired=false;rt.code='5231';
 await pg.evaluate(()=>refresh(true));await pg.waitForFunction(()=>/becomes the master|Old way/.test(document.querySelector('#ls').textContent));
 ok(/5231/.test(await pg.textContent('#ls'))&&!/Paired/.test(await pg.textContent('#ls')),'unpaired table shows the code and no Paired badge');
 rt.paired=true;await pg.evaluate(()=>refresh(true));await pg.waitForFunction(()=>/Paired/.test(document.querySelector('#ls').textContent));
 ok(!/5231/.test(await pg.textContent('#ls'))&&/The code is used/.test(await pg.textContent('#ls'))&&/Master phone: Guest 1/.test(await pg.textContent('#ls')),'paired table hides the code and says Guest 1 is the master');
 ok(await pg.locator('#ls [data-r]').count()===2&&await pg.locator('#ls .gc').count()===3,'guest list has a Remove button for each guest except the master');
 const nc=n=>calls.filter(c=>c[0]===n).length;
 await pg.click('#ls [data-r="'+rt.id+':2"]');ok(nc('waiter_remove_guest')===0&&/Tap again to remove Guest 2/.test(await pg.textContent('#ls [data-r="'+rt.id+':2"]')),'Remove asks for a second tap first');
 await pg.click('#ls [data-r="'+rt.id+':2"]');await pg.waitForFunction(()=>/Guest 2 removed/.test(document.querySelector('#msg').textContent));
 const rg=calls.filter(c=>c[0]==='waiter_remove_guest').pop()[1];ok(rg.sid===rt.id&&rg.gnum===2&&rg.tok,'second tap sends waiter_remove_guest with table and guest number');
 ok(await pg.locator('#ls [data-r]').count()===1&&!/Guest 2/.test(await pg.textContent('#ls .gc')),'removed guest leaves the list');
 await pg.click('#ls [data-m]');ok(nc('waiter_new_master')===0&&/the master is removed/.test(await pg.textContent('#ls [data-m]')),'New master code asks for a second tap first');
 await pg.click('#ls [data-m]');await pg.waitForFunction(()=>/new code 7351/.test(document.querySelector('#msg').textContent));
 ok(nc('waiter_new_master')===1&&calls.filter(c=>c[0]==='waiter_new_master').pop()[1].sid===rt.id,'second tap sends waiter_new_master');
 await pg.waitForFunction(()=>/7351/.test(document.querySelector('#ls').textContent));
 ok(!/Paired/.test(await pg.textContent('#ls'))&&/7351/.test(await pg.textContent('#ls'))&&!/Guest 1 · master/.test(await pg.textContent('#ls')),'fresh code shows, Paired is gone and the old master is gone from the list');
 rt.guests=[{num:1,master:true,removed:true,orders:[{id:91,status:'served',at:new Date().toISOString(),lines:[{name:'Tea',qty:1,price:3000}]}]}];await pg.evaluate(()=>refresh(true));await pg.waitForFunction(()=>/removed\)/.test(document.querySelector('#ls').textContent));
 ok(/Guest 1 \(removed\)/.test(await pg.textContent('#ls')),'a removed guest with orders stays in the order list marked removed');
 tables.splice(tables.indexOf(rt),1,...[]);tables.length=0;await pg.evaluate(()=>refresh(true));
 await pg.click('#lo');await pg.waitForSelector('#n');ok(true,'log out returns to login');
 // admin Waiters sheet
 const JWT='x.'+b64({email:'a@b.c',role:'authenticated'})+'.y';
 const ap=await ctx.newPage();let wl=[{id:1,name:'Sara',active:true}];const ac=[];
 await ap.route('https://qeudronebisrlcqerwvz.supabase.co/**',async route=>{const u=new URL(route.request().url()),m=route.request().method(),p=u.pathname;
  const J=b=>route.fulfill({status:200,headers:{'access-control-allow-origin':'*','content-type':'application/json'},body:JSON.stringify(b)});
  if(m==='OPTIONS')return route.fulfill({status:204,headers:{'access-control-allow-origin':'*','access-control-allow-headers':'*','access-control-allow-methods':'*'}});
  const fn=p.split('/').pop(),body=route.request().postData()?JSON.parse(route.request().postData()):{};
  if(p.includes('/auth/v1/token'))return J({access_token:JWT,refresh_token:'r'});
  if(fn==='admin_closed_tables')return J([{id:9,table_label:'4719',waiter_name:'Baker',opened_at:'2026-11-04T17:24:00Z',closed_at:'2026-11-04T19:30:00Z',total:64000,lines:[{name:'Mocha',qty:5,price:4000,vote:1},{name:'Lungo',qty:2,price:6000,vote:-1}]}]);if(fn==='admin_item_votes')return J([{name:'Mocha',up:3,down:0},{name:'Lungo',up:1,down:2}]);if(fn==='list_waiters')return J(wl);if(fn==='verify_pin')return J('ok');
  if(fn==='staff_add_waiter'){ac.push(fn);wl.push({id:2,name:body.nm,active:true});return J('ok')}
  if(fn==='staff_set_waiter_active'){ac.push(fn);wl[0].active=body.act;return J('ok')}
  if(fn==='staff_reset_waiter_pin'){ac.push(fn);return J('bad_waiter_pin')}
  if(p.endsWith('/menu_items'))return J([{id:1,grp:'Beer',sec:'Beer',name:'X',variant:'',price:'4000',sort:1}]);
  if(p.includes('/rpc/'))return J([]);return J([]);});
 await ap.goto(base+'/admin.html');await ap.waitForSelector('#a');
 await ap.evaluate(t=>{T=t;return panel()},JWT);await ap.waitForSelector('#add');
 await ap.evaluate(()=>{TAB='m';draw()});await ap.waitForSelector('#wtb',{timeout:4000}).catch(()=>{});
 ok(await ap.locator('#wtb').count()===1,'More shows the Waiters card');
 await ap.click('#wtb');ok(/Sara/.test(await ap.textContent('#shc')),'sheet lists waiters');
 await ap.click('#wta');await ap.fill('#wn','Tesfay');await ap.fill('#wp','5566');await ap.click('#wsv');
 await ap.waitForFunction(()=>document.querySelector('#pd[open]'));await ap.fill('#pdi','1111');await ap.click('#pdok');
 await ap.waitForFunction(()=>/Tesfay/.test(document.querySelector('#shc').textContent));ok(true,'add waiter then list shows Tesfay');
 await ap.click('[data-w="1"]');await ap.click('#wac');await ap.waitForFunction(()=>/Paused/.test(document.querySelector('#shc').textContent));ok(ac.includes('staff_set_waiter_active'),'pause works');
 await ap.click('[data-w="1"]');await ap.fill('#wp2','12');await ap.click('#wrp');await ap.waitForTimeout(300);
 ok(/4 to 8/.test(await ap.textContent('#msg')),'bad new PIN message');
 // v7.6 (7e) admin Closed tables
 await ap.keyboard.press('Escape');await ap.evaluate(()=>{TAB='m';draw()});
 ok(await ap.locator('#ctb').count()===1,'More shows the Closed tables card');
 await ap.click('#ctb');await ap.waitForFunction(()=>/Table 4719/.test(document.querySelector('#shc').textContent));
 ok(/64,000\/=/.test(await ap.textContent('#shc'))&&/Baker/.test(await ap.textContent('#shc')),'closed table shows total and waiter');
 await ap.click('[data-c="0"]');ok(/5 \u00d7 Mocha/.test(await ap.textContent('#shc')),'detail lists the drinks');
 ok(/\ud83d\udc4d/.test(await ap.textContent('#shc'))&&/\ud83d\udc4e/.test(await ap.textContent('#shc')),'detail shows the thumbs on each drink');
 await ap.click('#cbk');await ap.waitForSelector('#cvt');await ap.click('#cvt');await ap.waitForFunction(()=>/Lungo/.test(document.querySelector('#shc').textContent));
 ok(/Mocha[^L]*3/.test(await ap.textContent('#shc'))&&/Lungo[^M]*1[^0-9]+2/.test(await ap.textContent('#shc')),'Drink ratings lists thumbs per drink');
 ok(!/Baker|4719/.test(await ap.textContent('#shc')),'ratings show no table or waiter');
 ok(await ap.locator('#shc button:not([data-x]):not(#cbk):not(#vbk)').count()===0,'closed table is read-only (no edit buttons)');
 // v7.8 (7g) Admin test now checks table ordering and thumbs (read only)
 await ap.keyboard.press('Escape');await ap.evaluate(()=>{TAB='m';draw()});await ap.waitForSelector('#atb');
 const rpcBefore=ac.length;await ap.click('#atb');await ap.waitForFunction(()=>/Part 2/.test(document.querySelector('#shc').textContent),null,{timeout:15000});
 const at=await ap.textContent('#shc');
 ok(/Table ordering is set up: 2 waiters/.test(at),'Admin test: table ordering set up, counts waiters');
 ok(/Closed tables list works/.test(at),'Admin test: closed tables list works');
 ok(/Drink ratings \(thumbs\) work/.test(at)&&/2 drinks rated/.test(at),'Admin test: thumbs work, 2 drinks rated');
 ok(/Drink ratings are anonymous/.test(at),'Admin test: ratings are anonymous');
 ok(/Closed tables list shows closed tables only/.test(at),'Admin test: closed tables only');
 ok(!/\u2715/.test(at),'Admin test: no failed check');
 ok(ac.length===rpcBefore,'Admin test saved nothing (no write calls)');
 ok(/log in on waiter\.html/.test(at),'checklist has the waiter steps');
 ok(/thumbs up \/ down on each drink/.test(at)&&/Drink ratings: likes and dislikes/.test(at),'checklist has thumbs and ratings steps');
 ok(await ap.evaluate(()=>BKT.version==='9.8'&&BKT.MANUAL.length===29),'Admin test version 9.8 and 29 checklist items');
 await br.close();srv.close();console.log(pass+' passed, '+fail+' failed');process.exit(fail?1:0)})();
