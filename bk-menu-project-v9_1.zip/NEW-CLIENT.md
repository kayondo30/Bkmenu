# New client in one sitting (menu v5.5 and later)

Everything about the company lives in ONE file, site/config.js. The code is the same for every client.

## 1. Their own Supabase project (5 minutes)
- Create a new Supabase project for the client.
- In its SQL Editor, run the files in sql/ IN THIS ORDER, each in a new query tab: v2.sql, v3.sql, v3.1.sql, v3.5.sql, v5.1.sql, v5.8.sql, v6.0.sql (skip v3.9.sql, it is BK's own regrouping).
- Add the staff rows for the client's staff accounts (as done for BK).
- Copy the project address and the PUBLISHABLE key (never the secret or service_role key).

## 2. site/config.js (2 minutes)
- url, key: from step 1.
- brand.short, brand.full, brand.title, brand.motto, brand.footer, brand.share: the client's names and wording.
- brand.geez: true only if the client wants the Eritrean (Geez) date shown.
- brand.celebrate: pick the sets: 'eritrea', 'general', 'islam', 'uganda'. [] = no decorations.
- usd: today's dollar rate (the live rate replaces it when online).

## 3. Pictures (5 minutes)
- site/logo.png: the client's logo (it shows on a black band; a light logo looks best).
- site/icon-192.png and site/icon-512.png: the app icon (square).
- site/manifest.webmanifest: change "name" and "short_name".

## 4. Their drinks
- site/menu.json: the fallback list (the live list comes from their Supabase menu_items table).
- Or start with an empty table and add drinks on the staff page with "+ Add a drink".

## 5. Deploy
- Cloudflare: Workers & Pages > Create > Pages > Upload assets > a new project name for the client.
- Upload the SITE zip (the files of site/ at the top level, 20 files, including bk-staff-guide.mp4). Check "Uploading 20 total file(s)".
- In their Supabase: Authentication > URL Configuration: Site URL = the new pages.dev address.
- Make the QR code LAST, from the FINAL address.
- The staff how-to video (site/bk-staff-guide.mp4) shows the BK logo and BK drink names. For a new client: re-render it (tools/video/howto.html uses site/logo.png) and replace the file, or delete the file and the "How to use the app" card in admin.html.
