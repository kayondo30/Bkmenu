-- BK menu v7.7 part 7f of 7 (THUMBS UP / DOWN per drink). Optional feature.
-- Run once in Supabase > SQL Editor (new query tab). Safe to run again. "Success. No rows returned" is normal.
-- Needs v7.0.sql run first. Nothing in your menu, prices or orders is changed or deleted.
-- Check:  select proname from pg_proc where proname in ('guest_vote','admin_item_votes');   -> 2 rows
--         select column_name from information_schema.columns where table_name='order_lines' and column_name='vote';  -> 1 row
-- Undo = sql/v7.7-undo.sql.
--
-- HOW IT WORKS
-- After the waiter marks an order Served, the guest can tap thumbs up or thumbs down on each drink (tap again to clear it).
-- The waiter sees a thumbs down on his own open table so he can ask the guest by mouth.
-- The admin sees likes and dislikes per drink ONLY from CLOSED tables (never an open table), with no table, waiter or guest link in the summary.

alter table order_lines add column if not exists vote smallint check (vote in (1,-1));

-- The guest's own screen now also carries the line id and his vote.
create or replace function guest_status(gt uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype; s sittings%rowtype;
begin
 select * into g from sitting_guests where token=gt;
 if not found then return jsonb_build_object('connected',false); end if;
 select * into s from sittings where id=g.sitting_id;
 return jsonb_build_object('connected',s.status='open','closed',s.status='closed','num',g.num,'table',s.table_label,'pay',g.pay,
  'total',(select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.guest_id=g.id),
  'orders',(select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'lines',
      (select coalesce(jsonb_agg(jsonb_build_object('id',l.id,'name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote) order by l.id),'[]'::jsonb)
       from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb) from orders o where o.guest_id=g.id));
end $$;

-- The waiter's own OPEN tables: lines now carry the vote (a thumbs down means: ask the guest by mouth).
create or replace function waiter_tables(tok uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; r jsonb;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 select coalesce(jsonb_agg(to_jsonb(t) order by t.opened_at),'[]'::jsonb) into r from (
  select s.id, s.table_label, s.code, s.opened_at,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('num',g.num,'pay',g.pay,'orders',
      (select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'at',o.created_at,'lines',
         (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote) order by l.id),'[]'::jsonb)
          from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb)
       from orders o where o.guest_id=g.id)) order by g.num),'[]'::jsonb)
    from sitting_guests g where g.sitting_id=s.id) as guests
  from sittings s where s.waiter_id=w and s.status='open') t;
 return jsonb_build_object('r','ok','tables',r);
end $$;

-- Thumbs: v = 1 (up), -1 (down), or NULL to clear. Only for a drink that was Served, only while the table is open.
-- Replies ok | not_connected | not_found | not_served | bad_vote
create or replace function guest_vote(gt uuid, line_id int, v int)
returns text language plpgsql security definer set search_path=public as $$
declare g int; st text; n int;
begin
 g:=g_of(gt); if g is null then return 'not_connected'; end if;
 if v is not null and v not in (1,-1) then return 'bad_vote'; end if;
 select o.status into st from order_lines l join orders o on o.id=l.order_id where l.id=line_id and o.guest_id=g;
 if st is null then return 'not_found'; end if;
 if st<>'served' then return 'not_served'; end if;
 update order_lines set vote=v where id=line_id;
 get diagnostics n=row_count;
 return case when n=1 then 'ok' else 'not_found' end;
end $$;

-- Admin: each closed table's lines now carry the vote.
create or replace function admin_closed_tables(n int default 50)
returns jsonb language plpgsql security definer set search_path=public as $$
begin
 if not is_staff() then return '[]'::jsonb; end if;
 return (select coalesce(jsonb_agg(to_jsonb(t) order by t.closed_at desc),'[]'::jsonb) from (
  select s.id, s.table_label, s.waiter_name, s.opened_at, s.closed_at,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote) order by l.id),'[]'::jsonb)
      from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as lines
  from sittings s where s.status='closed' order by s.closed_at desc limit least(coalesce(n,50),200)) t);
end $$;

-- Admin: likes and dislikes per drink, CLOSED tables only, no table / waiter / guest link.
create or replace function admin_item_votes()
returns jsonb language plpgsql security definer set search_path=public as $$
begin
 if not is_staff() then return '[]'::jsonb; end if;
 return (select coalesce(jsonb_agg(to_jsonb(t) order by t.up+t.down desc, t.name),'[]'::jsonb) from (
  select l.name, count(*) filter (where l.vote=1)::int as up, count(*) filter (where l.vote=-1)::int as down
  from order_lines l join orders o on o.id=l.order_id join sittings s on s.id=o.sitting_id
  where s.status='closed' and l.vote is not null group by l.name) t);
end $$;

revoke all on function guest_status(uuid), waiter_tables(uuid), guest_vote(uuid,int,int), admin_closed_tables(int), admin_item_votes() from public;
grant execute on function guest_status(uuid), waiter_tables(uuid), guest_vote(uuid,int,int) to anon, authenticated;
grant execute on function admin_closed_tables(int), admin_item_votes() to authenticated;
