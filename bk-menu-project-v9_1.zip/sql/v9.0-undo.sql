-- Undo BK menu v9.0: puts back the v7.5 waiter_open_table and the v7.7 versions of guest_status, waiter_tables, admin_closed_tables
-- (without kind), then removes the kind column. Room service and take away tables already made become plain tables with their labels
-- (Room 12, Take away 4719) because the label stays. Orders, prices, closed tables and thumbs are untouched.
drop function if exists waiter_open_table(uuid,text,text);
create or replace function waiter_open_table(tok uuid, tbl text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; lbl text := left(trim(coalesce(tbl,'')),20); c text; sid int; k int := 0; nm text;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 if lbl<>'' and exists(select 1 from sittings where status='open' and lower(table_label)=lower(lbl)) then return jsonb_build_object('r','table_busy'); end if;
 select name into nm from waiters where id=w;
 loop
  c:=lpad((floor(random()*10000))::int::text,4,'0');
  begin
   insert into sittings(waiter_id,waiter_name,table_label,code) values(w,nm,case when lbl='' then c else lbl end,c) returning id into sid;
   return jsonb_build_object('r','ok','id',sid,'code',c);
  exception when unique_violation then
   k:=k+1; if k>25 then return jsonb_build_object('r','try_again'); end if;
  end;
 end loop;
end $$;
revoke all on function waiter_open_table(uuid,text) from public;
grant execute on function waiter_open_table(uuid,text) to anon, authenticated;
create or replace function guest_status(gt uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype; s sittings%rowtype;
begin
 select * into g from sitting_guests where token=gt;
 if not found then return jsonb_build_object('connected',false); end if;
 select * into s from sittings where id=g.sitting_id;
 return jsonb_build_object('connected',s.status='open','closed',s.status='closed','num',g.num,'table',s.table_label,'pay',g.pay,
  'total',(select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.guest_id=g.id),
  'orders',(select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'lines',
      (select coalesce(jsonb_agg(jsonb_build_object('id',l.id,'name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote) order by l.id),'[]'::jsonb)
       from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb) from orders o where o.guest_id=g.id));
end $$;

create or replace function waiter_tables(tok uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; r jsonb;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 select coalesce(jsonb_agg(to_jsonb(t) order by t.opened_at),'[]'::jsonb) into r from (
  select s.id, s.table_label, s.code, s.opened_at,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('num',g.num,'pay',g.pay,'orders',
      (select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'at',o.created_at,'lines',
         (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote) order by l.id),'[]'::jsonb)
          from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb)
       from orders o where o.guest_id=g.id)) order by g.num),'[]'::jsonb)
    from sitting_guests g where g.sitting_id=s.id) as guests
  from sittings s where s.waiter_id=w and s.status='open') t;
 return jsonb_build_object('r','ok','tables',r);
end $$;

create or replace function admin_closed_tables(n int default 50)
returns jsonb language plpgsql security definer set search_path=public as $$
begin
 if not is_staff() then return '[]'::jsonb; end if;
 return (select coalesce(jsonb_agg(to_jsonb(t) order by t.closed_at desc),'[]'::jsonb) from (
  select s.id, s.table_label, s.waiter_name, s.opened_at, s.closed_at,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote) order by l.id),'[]'::jsonb)
      from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as lines
  from sittings s where s.status='closed' order by s.closed_at desc limit least(coalesce(n,50),200)) t);
end $$;

revoke all on function guest_status(uuid), waiter_tables(uuid), admin_closed_tables(int) from public;
grant execute on function guest_status(uuid), waiter_tables(uuid) to anon, authenticated;
grant execute on function admin_closed_tables(int) to authenticated;
alter table sittings drop constraint if exists sittings_kind_ck;
alter table sittings drop column if exists kind;
