-- BK menu v9.0 part 9a of 9c (ORDER TYPES: table, room service, take away). DATABASE ONLY. Optional feature.
-- Run once in Supabase > SQL Editor (new query tab). Safe to run again. "Success. No rows returned" is normal.
-- Needs v7.0, v7.5 and v7.7 run first. Nothing in your menu, prices, orders or closed tables is changed or deleted:
-- every table that already exists simply becomes kind 'table'. The site does not use the new type until part 9b.
-- Check:  select column_name from information_schema.columns where table_name='sittings' and column_name='kind';  -> 1 row
--         select pronargs from pg_proc where proname='waiter_open_table';  -> one row with 3
-- Undo = sql/v9.0-undo.sql (puts back the v7.5 and v7.7 functions and removes the kind column).
--
-- HOW IT WORKS
-- A sitting now has a kind: 'table' (as today), 'room' (room service) or 'takeaway'.
-- The waiter opens one with waiter_open_table(tok, text, kind). The third part is optional and defaults to 'table', so the site you
-- already run (v7.8) keeps working exactly as before.
--   table:    the text is ignored or used as a table number like today; if blank the code names it (Table 4719).
--   room:     the waiter MUST give the room number; the label becomes "Room 12" (reply need_room if blank, table_busy if that room is open).
--   takeaway: the text is an optional name; the label becomes "Take away 4719" or "Take away 4719 - Sam".
-- Replies: ok (with id and code) | no_login | need_room | table_busy | bad_kind | try_again.
-- waiter_tables, guest_status and admin_closed_tables now also return kind. Guests still see no totals in the app.

alter table sittings add column if not exists kind text not null default 'table';
do $$ begin
 if not exists (select 1 from pg_constraint where conname='sittings_kind_ck') then
  alter table sittings add constraint sittings_kind_ck check (kind in ('table','room','takeaway'));
 end if;
end $$;

-- the 2-argument version is replaced by one with an optional third argument (two versions side by side would confuse the site)
drop function if exists waiter_open_table(uuid,text);
create or replace function waiter_open_table(tok uuid, tbl text, kind text default 'table')
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; lbl text := left(trim(coalesce(tbl,'')),20); kd text := lower(trim(coalesce(kind,'table'))); c text; sid int; k int := 0; nm text; lb text;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 if kd not in ('table','room','takeaway') then return jsonb_build_object('r','bad_kind'); end if;
 if kd='room' then
  if lbl='' then return jsonb_build_object('r','need_room'); end if;
  lb:='Room '||lbl;
 elsif kd='table' and lbl<>'' then
  lb:=lbl;
 end if;
 if lb is not null and exists(select 1 from sittings where status='open' and lower(table_label)=lower(lb)) then return jsonb_build_object('r','table_busy'); end if;
 select name into nm from waiters where id=w;
 loop
  c:=lpad((floor(random()*10000))::int::text,4,'0');
  begin
   insert into sittings(waiter_id,waiter_name,table_label,code,kind)
    values(w,nm,coalesce(lb,case when kd='takeaway' then 'Take away '||c||case when lbl<>'' then ' - '||lbl else '' end else c end),c,kd)
    returning id into sid;
   return jsonb_build_object('r','ok','id',sid,'code',c);
  exception when unique_violation then
   k:=k+1; if k>25 then return jsonb_build_object('r','try_again'); end if;
  end;
 end loop;
end $$;
revoke all on function waiter_open_table(uuid,text,text) from public;
grant execute on function waiter_open_table(uuid,text,text) to anon, authenticated;

-- these three now also return kind
create or replace function guest_status(gt uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype; s sittings%rowtype;
begin
 select * into g from sitting_guests where token=gt;
 if not found then return jsonb_build_object('connected',false); end if;
 select * into s from sittings where id=g.sitting_id;
 return jsonb_build_object('connected',s.status='open','closed',s.status='closed','num',g.num,'table',s.table_label,'kind',s.kind,'pay',g.pay,
  'total',(select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.guest_id=g.id),
  'orders',(select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'lines',
      (select coalesce(jsonb_agg(jsonb_build_object('id',l.id,'name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote) order by l.id),'[]'::jsonb)
       from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb) from orders o where o.guest_id=g.id));
end $$;

create or replace function waiter_tables(tok uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; r jsonb;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 select coalesce(jsonb_agg(to_jsonb(t) order by t.opened_at),'[]'::jsonb) into r from (
  select s.id, s.table_label, s.kind, s.code, s.opened_at,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('num',g.num,'pay',g.pay,'orders',
      (select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'at',o.created_at,'lines',
         (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote) order by l.id),'[]'::jsonb)
          from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb)
       from orders o where o.guest_id=g.id)) order by g.num),'[]'::jsonb)
    from sitting_guests g where g.sitting_id=s.id) as guests
  from sittings s where s.waiter_id=w and s.status='open') t;
 return jsonb_build_object('r','ok','tables',r);
end $$;

create or replace function admin_closed_tables(n int default 50)
returns jsonb language plpgsql security definer set search_path=public as $$
begin
 if not is_staff() then return '[]'::jsonb; end if;
 return (select coalesce(jsonb_agg(to_jsonb(t) order by t.closed_at desc),'[]'::jsonb) from (
  select s.id, s.table_label, s.kind, s.waiter_name, s.opened_at, s.closed_at,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote) order by l.id),'[]'::jsonb)
      from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as lines
  from sittings s where s.status='closed' order by s.closed_at desc limit least(coalesce(n,50),200)) t);
end $$;

revoke all on function guest_status(uuid), waiter_tables(uuid), admin_closed_tables(int) from public;
grant execute on function guest_status(uuid), waiter_tables(uuid) to anon, authenticated;
grant execute on function admin_closed_tables(int) to authenticated;
