-- Undo BK menu v7.5: puts back the v7.0 waiter_open_table (a table number must be typed). No data is changed.
create or replace function waiter_open_table(tok uuid, tbl text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; lbl text := left(trim(coalesce(tbl,'')),20); c text; sid int; k int := 0; nm text;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 if lbl='' then return jsonb_build_object('r','need_table'); end if;
 if exists(select 1 from sittings where status='open' and lower(table_label)=lower(lbl)) then return jsonb_build_object('r','table_busy'); end if;
 select name into nm from waiters where id=w;
 loop
  c:=lpad((floor(random()*10000))::int::text,4,'0');
  begin
   insert into sittings(waiter_id,waiter_name,table_label,code) values(w,nm,lbl,c) returning id into sid;
   return jsonb_build_object('r','ok','id',sid,'code',c);
  exception when unique_violation then
   k:=k+1; if k>25 then return jsonb_build_object('r','try_again'); end if;
  end;
 end loop;
end $$;
