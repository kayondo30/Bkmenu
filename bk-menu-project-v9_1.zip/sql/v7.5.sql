-- BK menu v7.5: the 4-digit code IS the table. The waiter no longer types a table number.
-- Run once in Supabase > SQL editor. Safe to run again. Replaces ONE function (waiter_open_table); no data is changed.
-- If a table number is still sent it is used as before; if it is blank the code becomes the table's name ("Table 4719").
create or replace function waiter_open_table(tok uuid, tbl text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; lbl text := left(trim(coalesce(tbl,'')),20); c text; sid int; k int := 0; nm text;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 if lbl<>'' and exists(select 1 from sittings where status='open' and lower(table_label)=lower(lbl)) then return jsonb_build_object('r','table_busy'); end if;
 select name into nm from waiters where id=w;
 loop
  c:=lpad((floor(random()*10000))::int::text,4,'0');
  begin
   insert into sittings(waiter_id,waiter_name,table_label,code) values(w,nm,case when lbl='' then c else lbl end,c) returning id into sid;
   return jsonb_build_object('r','ok','id',sid,'code',c);
  exception when unique_violation then
   k:=k+1; if k>25 then return jsonb_build_object('r','try_again'); end if;
  end;
 end loop;
end $$;
revoke all on function waiter_open_table(uuid,text) from public;
grant execute on function waiter_open_table(uuid,text) to anon, authenticated;
-- Check:  insert nothing; just run:  select proname from pg_proc where proname='waiter_open_table';  -> 1 row
