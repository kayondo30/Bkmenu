-- Undo BK menu v7.7: removes the thumbs functions and puts back the v7.0 versions of guest_status, waiter_tables, admin_closed_tables.
-- The vote column is dropped too (the thumbs already given are lost; orders, prices and tables are untouched).
drop function if exists guest_vote(uuid,int,int);
drop function if exists admin_item_votes();
create or replace function guest_status(gt uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype; s sittings%rowtype;
begin
 select * into g from sitting_guests where token=gt;
 if not found then return jsonb_build_object('connected',false); end if;
 select * into s from sittings where id=g.sitting_id;
 return jsonb_build_object('connected',s.status='open','closed',s.status='closed','num',g.num,'table',s.table_label,'pay',g.pay,
  'total',(select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.guest_id=g.id),
  'orders',(select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'lines',
      (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price) order by l.id),'[]'::jsonb)
       from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb) from orders o where o.guest_id=g.id));
end $$;
create or replace function waiter_tables(tok uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; r jsonb;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 select coalesce(jsonb_agg(to_jsonb(t) order by t.opened_at),'[]'::jsonb) into r from (
  select s.id, s.table_label, s.code, s.opened_at,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('num',g.num,'pay',g.pay,'orders',
      (select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'at',o.created_at,'lines',
         (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price) order by l.id),'[]'::jsonb)
          from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb)
       from orders o where o.guest_id=g.id)) order by g.num),'[]'::jsonb)
    from sitting_guests g where g.sitting_id=s.id) as guests
  from sittings s where s.waiter_id=w and s.status='open') t;
 return jsonb_build_object('r','ok','tables',r);
end $$;
create or replace function admin_closed_tables(n int default 50)
returns jsonb language plpgsql security definer set search_path=public as $$
begin
 if not is_staff() then return '[]'::jsonb; end if;
 return (select coalesce(jsonb_agg(to_jsonb(t) order by t.closed_at desc),'[]'::jsonb) from (
  select s.id, s.table_label, s.waiter_name, s.opened_at, s.closed_at,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price) order by l.id),'[]'::jsonb)
      from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as lines
  from sittings s where s.status='closed' order by s.closed_at desc limit least(coalesce(n,50),200)) t);
end $$;
alter table order_lines drop column if exists vote;
revoke all on function guest_status(uuid), waiter_tables(uuid), admin_closed_tables(int) from public;
grant execute on function guest_status(uuid), waiter_tables(uuid) to anon, authenticated;
grant execute on function admin_closed_tables(int) to authenticated;
