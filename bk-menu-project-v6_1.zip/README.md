# BK Beverage Menu
Short list of every version: CHANGELOG.md. Detail below.

## v6.1 (2026-11-03)
My words: "edit this video to the current features and it should be in the app on the admin side". Site files only, NO SQL (the video is a plain file in the site zip, nothing is stored in Supabase). DEPLOY COUNT NOW 19 FILES: the 18 before plus bk-staff-guide.mp4 (2.9 MB); check "Uploading 19 total file(s)". Video remade from tools/video/howto.html (render with: node tools/video/render.js /tmp/video, needs Playwright and ffmpeg; copy the result to site/bk-staff-guide.mp4): 97 seconds, 11 steps, portrait, captions, no sound. New or changed steps: 4 Change a price or a NAME, 5 Sold out or hide WITH A REASON, 6 Add a drink or food with PRICE SUGGESTIONS (example Caramel Latte), 10 WHO CHANGED WHAT; Step 3 and the closing card mention the change log. In the app: staff screen > More > "How to use the app" > Watch the how-to video (opens in a sheet, needs internet, stops when the sheet closes). sw.js lets .mp4 requests go straight to the network (no offline copy, no caching problems with video ranges). Cache bk-menu-v6.1. Tests: 51 browser checks pass. RULE: when a feature changes what staff see, update tools/video/howto.html, render again and replace the mp4.

## v6.0 (2026-11-03)
My words: "when an admin hides something he gives a reason why, so the change log has the details". Site files only (18) plus ONE new SQL file, sql/v6.0.sql (function staff_update_item3; nothing deleted, the old staff_update_item2 stays unused). In the tap-a-drink sheet, switching Hide from menu ON shows a box "Why are you hiding it? (required)" (max 120 characters); saving without a reason is refused ("Please give a reason for hiding it"), by the app AND by the server (need_reason). Switching Hide OFF shows an optional note. Who changed what now reads like: "Gold Label: price 220,000 · HIDDEN from the menu · Reason: Out of stock until Friday", with the login name and the time; showing it again reads "shown again". The reason is only asked when the item changes from shown to hidden (saving a price on an already hidden item does not ask again). NOT covered yet: hiding a special or a season (untick Show), Sold out today, Delete. Without v6.0.sql, saving an item says "Not saved: run the file bk-menu-v6.0.sql in Supabase once". sw.js cache bk-menu-v6.0. Tests: 48 browser checks pass.

## v5.9 (2026-11-03)
My words (screenshot of the Gold Label sheet): "now add how to edit the item name". Site files only, NO SQL, 18 files. The item sheet (tap a drink) now has a visible Name box at the top with the hint "Change the name here, then tap Save"; the main Save saves the name too (an empty name is refused: "Type a name first"). More options now holds Size, descriptions and Delete. The price hint under Price now reads "One price, or two sizes like 4,000 / 6,000" (it said "Two sizes" on every drink). sw.js cache bk-menu-v5.9.

## v5.8 (2026-11-03)
My words: "inside the app just to know who could have changed the menu and at what time". Site files only (18 files) plus ONE new read-only SQL file, sql/v5.8.sql (function list_changes; nothing changed or lost). Staff page > More > "Who changed what": the last 8 changes, each with what happened (item name, new price, sold out or hidden, added, edited, deleted, special, season, notice banner), WHO (the part of the login email before @) and the date and time on this phone; "See all" opens the last 100. It reads the existing audit_log, so older changes show too (older rows kept the item number only, v5.8.sql adds the item name). Without v5.8.sql the old short list shows and says to run it. LIMITS: it names the LOGIN, not the person (two people on one login look the same); changes made directly inside Supabase are not recorded; staff cannot edit or delete the log. sw.js cache bk-menu-v5.8. Tests: 43 browser checks pass.

## v5.7 (2026-11-03)
My words: "could you add the price suggestions". Site files only, NO SQL, still 18 site files. In Add a drink or food, under Price: tap-to-fill chips. First the price of the closest relative on the menu (name shares a brand word), then the most used prices in the chosen page and section with how many items use each; a section note such as "Every milkshake" is shown as text. Chips follow the page and section when they change. Code: BKDET.priceHints in detect.js. sw.js cache bk-menu-v5.7. Tests: 43 browser checks.

## v5.6 (2026-11-03)
My words: "make the how to use the app video for admins; for new items choose drink or food and detect the category; on the celebration day decorate by shaking the phone, one carousel card saying Happy Independence Day, shake your phone to celebrate with us; create the admin testing; batch the items into small splits; run it". Site files only, NO SQL, 18 site files (3 new, each one batch).
BATCH A, detect.js: the Add screen guesses drink or food and the page and section from the name (keywords for the BK pages, brands already on the menu, food words). Tested by tools/test_detect.js (30 checks on the real menu).
BATCH B, admin.html: "+ Add a drink or food": Name first, then Not sure / Drink / Food, then Page and Section already filled in. A page or section that does not exist yet is offered as a new one (Food, Cocktails). A page or section chosen by hand is never overridden. No SQL: the existing staff_add_item already creates a new page when the page name is new.
BATCH C, shake.js + index.html: on a celebration DAY the carousel gets ONE card: "Happy <celebration>" and "Shake your phone to celebrate with us" with a Tap to celebrate button. Until then the header shows only the calm season garland. Three quick shakes (or a tap) start the full decoration of the day and a 3-second confetti burst; it stays for that day on that phone. iPhone asks for motion permission on the tap. Previews (?deco=indep) behave the same but are not remembered. Settings Celebration decorations Off turns it all off.
BATCH D, admintest.js: More > Admin test: 23 automatic read-only checks (connection, tables, staff, PIN, detection, shake, celebration calendar, offline copy), an 11-line tick list for what only a person can check, a shake test on the phone, and Copy the result.
VIDEO: tools/video (howto.html + render.js) makes bk-staff-guide.mp4, 9 steps, about 1 minute, captions on screen, portrait. Not part of the site zip (send it on WhatsApp).
TESTS: node tools/test_detect.js and node tools/test_browser.js (headless Chrome, pretend Supabase, 40 checks incl. shake, real-day clock 24 May 2027, add item through the PIN, admin test).
LOCKED: the shake hint is English only until the owner gives the Tigrinya words. sw.js cache bk-menu-v5.6, shake.js added to the offline files.

## v5.5 (2026-11-01)
One bump, my words: "design the best, just a single bump; on a new menu project I won't be redoing anything much, just changing names of the company". Site files only, NO SQL, 15 site files.
1) THE SPECIAL CARD, richer: a soft accent glow, a gold hairline on top, a bigger title, the price as a pill, a large faint drawing (a glass; a heart on message cards). A special WITHOUT a price is a message card: label "From us", signed "— <company full name>" (BK: "Thank you our esteemed customers"). Drink of the day keeps its filled label. A single card is taller.
2) ONE FILE PER CLIENT: site/config.js now holds brand { short, full, title, motto, footer, share, geez, celebrate }. index.html and admin.html read every company wording from it (tab title, logo text, footer, share, staff page title, message-card signature); geez:false hides the Eritrean date; celebrate chooses the sets (eritrea, general, islam, uganda) for the decorations and for the staff list "See the celebrations". New file NEW-CLIENT.md (project zip only): the whole new-client checklist. Tested with a pretend client "Sunset Lounge & Grill" (general celebrations only, no Geez date): every wording changed from config.js alone.

## v5.4 (2026-11-01)
Fix after my screenshot "It's not saving" (Add a drink, Club small size 5000 330ml): the staff message was drawn BEHIND an open sheet (an open sheet sits above everything), so a failed save looked like nothing happened. Now the message shows inside the open sheet, full width, for 4 seconds, and says WHY: "Not saved: run the file bk-menu-v5.1.sql in Supabase once, then try again" when the add, edit or delete step is missing on the server; "Not saved: <the server's words>" for anything else; "No connection. Nothing was saved". An expired login (after about an hour) is renewed once and the save is tried again by itself. Site files only, NO SQL. Version 5.4, cache bk-menu-v5.4, 15 site files.
Most likely cause of my failed save: sql/v5.1.sql not run yet. Check: select proname from pg_proc where proname in ('staff_add_item','staff_edit_item','staff_delete_item'); must give 3 rows.

## v5.3 (2026-11-01)
Specials follow the language switch (my words: "when the special is set it follows the current language automatically ... when the language changes it follows up the switch"). Site files only, NO SQL.
Guest menu: a special's Tigrinya wording (the existing field text_ti) is now its Tigrinya TITLE: ትግርኛ shows it as the big title, English shows the English title and text, Both shows the English title with the Tigrinya under it in gold; a special with no Tigrinya shows the English to everyone.
Staff page: the special sheet says "Title in English", "Short text in English", and "In ትግርኛ (shown when guests choose ትግርኛ)"; a button "Suggest ትግርኛ from the English" fills that box with a MACHINE translation (Google's free translate address, then MyMemory as a second try) for staff to CHECK and correct before saving; with no internet it says so and changes nothing. The same button sits under the Tigrinya description when adding or editing a drink. Version 5.3, cache bk-menu-v5.3. Not tested here: the real translation services (my test machine has no internet).

## v5.2 (2026-11-01)
Celebrations by the Eritrean (Geez) and the Gregorian calendar, plus a new featured carousel. Site files only, NO SQL. New file deco.js (site count now 15 files).
Two levels: SEASON (the days around a celebration) = a drawn garland along the top of the black header; DAY (the exact day, often with its eve) = more decorations, twinkling lights, swaying ornaments, side pieces, and a greeting card first in the carousel (English + Tigrinya + today's date in both calendars).
Celebrations and their art: Lidet 7 Jan and Christmas 25 Dec (pine garland, baubles, lights, stars); New Year 1 Jan (gold confetti, fireworks); Timket = Tir 11 (19 or 20 Jan, Ketera the eve; ceremonial umbrellas); Valentine's 14 Feb (hearts); Fasika (Orthodox Easter, computed) and Easter (Western, computed) (spring flowers); Eritrea Independence 24 May, season from 17 May (bunting green, red, blue, gold, gold olive wreaths); Geez New Year = Meskerem 1 (11 or 12 Sep; Adey Abeba daisies); Meskel = Meskerem 17 (27 Sep; daisies and Demera fires, the eve is the Demera); Uganda Independence 9 Oct (black, yellow, red bunting); Eid al-Fitr and Eid al-Adha (lanterns, crescent, stars; expected dates in a table for 2026 to 2032, they follow the moon, the day level covers the day before and after). NO decoration on remembrance days: Martyrs' Day 20 Jun, Fenkil 10 Feb, 1 Sep.
Today's Eritrean date under "Prices in ...": ጥቅምቲ 22 2019 (Tigrinya), 22 Tiqimti 2019 (English), both in Both mode.
Featured carousel: one carousel for the greeting card (celebration days), Drink of the day, specials and photos: big cards with a label, title, text, price (7,000/=), a faint drawn glass; dots that follow; gentle auto-advance every 5.5 s that stops for good after a touch, never with Reduce motion.
Settings: Celebration decorations On or Off (this phone). Staff page, More: "See the celebrations" opens any one now (the day, or its season) with ?deco=key and &lvl=season; a "Preview" label shows.
Checked: 26 dates against public holiday lists (2026 to 2028), including Pagume 6 in 2027 and New Year on 12 Sep 2027. Tigrinya greetings written by Claude: owner to check.

## v5.1 (2026-11-01)
Staff page made simple, add drinks in the app, prices written 4,000/=.
Staff page: four tabs (Drinks, Specials, Notice, More), one job at a time; a short summary line (sold out, hidden, notice, drink of the day). Drinks: Find a drink, a big "+ Add a drink" button, the list by page; tap a drink for a sheet with a big Price box, switches "Sold out today" and "Hide from menu", Season (only if seasons exist), Save; "More options" holds the name, size, both descriptions and "Delete this drink" (with a warning to use Hide instead for a while). Add a drink: page, section (or a new section), name, price, size, English and Tigrinya descriptions (optional), "Show on the menu now"; it goes at the end of its section. The PIN is asked once, at the first save, and kept until the screen locks (a wrong PIN asks again). Specials, seasons and the PIN open in the same kind of sheet. Typed 7000 is saved as 7,000.
Guest menu: every shilling amount ends with /= (4,000/=), no USh in front; two sizes still stack on two lines; dollars unchanged ($0.92). Version 5.1, cache bk-menu-v5.1.
NEEDS sql/v5.1.sql run ONCE (staff_add_item, staff_edit_item, staff_delete_item, each checks the PIN and writes to Recent changes). Without it the rest works and Add, edit name and delete say "Run v5.1.sql in Supabase first". Check query: select proname from pg_proc where proname in ('staff_add_item','staff_edit_item','staff_delete_item'); gives 3 rows.

## v5.0 (2026-11-01)
One-run remake to the FHG Calm standard. Prices, drinks, descriptions and Tigrinya text are unchanged; the same Supabase tables and functions are used, so NO new SQL.
Guest menu: follows the phone's light or dark by default (Settings > Light or dark: Phone, Light, Dark); Manrope font (fonts/ folder, SIL Open Font License, from the FHG app) with the phone's Ethiopic font for Tigrinya; one scrolling menu (all 9 pages) with sticky category chips that light up as you scroll and jump on tap (#p1 to #p9 links still work); each drink row stacks name, size, English and Tigrinya lines, price on the right (two sizes on two lines); tap a drink for a details sheet with the price in USh and a dollar guide; Sold out badge; banner and specials as calm cards (Drink of the day first); search with "Showing N of N" and an empty message; language button (Both, English, ትግርኛ); currency pill under the logo; settings as a bottom sheet; toast at the bottom; back to top button; offline line when the phone has no connection; "A newer menu is ready, Refresh" line after an update; clean print of the whole menu.
Offline (borrowed from FHG v505): the menu page is saved as a clean copy under / and /index.html, so it opens in flight mode; prices and code are network first, the saved copy only offline; staff screen never cached.
Staff screen: same login, PIN lock, idle lock and every save as before; Calm look; a sticky bar at the top with the PIN (typed once) and Find an item; the item list folds by page with counts; sold-out items crossed through; messages as a bottom toast.
Held items are also left out on the guest side (as a safety in addition to the database rules). Manifest stays full screen. Cache bk-menu-v5.0. Site zip: 14 files (the 11 as before plus fonts/ with 3 files).

## v4.1 (2026-10-29)
Currency: guests can switch prices between Uganda Shillings and US Dollars (tap the line under the logo, or Settings > Currency). UGX prices now carry the symbol USh (no official UGX symbol exists; USh is the common one). Dollar prices = UGX / rate, 2 decimals, shown as a guide. Rate: fetched live from open.er-api.com when online, remembered on the phone, falls back to 4,350 (checked 2026-10-29) when never fetched. Specials prices convert too. Staff screen still edits prices in plain UGX. Site files only, no new SQL. Cache bk-menu-v4.1. Settings shows Version 4.1.

## v4.0 (2026-10-29)
Leading icons: a small line icon now sits in front of every category chip (cup, tea cup, iced glass, orange slice, shake glass, beer mug, tumbler, bottle, wine glass) and in front of every drink row, in the colour of the accent. A drink with its own photo shows the photo instead of the icon. Icons follow light/dark and accent, and are hidden in print. Site files only, no new SQL (v3.9.sql is still the latest). Cache bk-menu-v4.0. Settings shows Version 4.0.

## v3.9 (2026-10-29)
Hotel-style menu organisation. 9 pages: Coffee, Tea, Iced, Juices, Shakes & Smoothies, Beer & Soft, Whisky, Spirits, Wine & Bubbly. Hot tea moved to its own page; Whisky split by style; Liqueurs and Areqi moved to Spirits; sizes and ages sit beside the name (Ballantine's 750ml, Chivas Regal 12 Year Old); Johnnie Walker names completed; items sorted logically or by price. Prices, descriptions and Tigrinya text are unchanged. NEW SQL: sql/v3.9.sql (sql/v3.9-undo.sql goes back). Cache bk-menu-v3.9.

## v3.8 (2026-10-29)
Bottom toolbar (Search, Language, Share, Print, Settings) replaces the top row; search opens a box above the bar. Calmer look: woven band and ornaments removed, plain hairlines, outlined category chip, no auto-sliding specials/photos, smaller logo header. No new SQL. Cache bk-menu-v3.8.

## v3.7 (2026-10-29)
Menu follows the phone light/dark setting (Settings > Light or dark has a new System choice, now the default; Dark and Light still override). Cover photo removed (cover.jpg deleted, site is now 11 files); the BK logo is the header at the top. Staff login and PIN lock screens are a centred card with stacked fields; the staff screen follows the same theme and accent. No new SQL. Cache bk-menu-v3.7.

## v3.6 (2026-10-26)
Decoration: gold diamond dividers, woven band, photo carousel, category banner photos, item thumbnails (tap to enlarge). Photos are listed in photos.json and stored in img/. No new SQL. Cache bk-menu-v3.6.

## v3.5 (2026-10-26)
Today tiles, staff list, scheduled specials (Starts/Ends), seasons (items in a season show only while it is on). sql/v3.5.sql (run after v3.1.sql). Cache bk-menu-v3.5. If v3.5.sql is not run the site still works with the old save functions.
Also in this zip: sql/v3.1.sql (verify_pin for the lock screen, rewritten 2026-10-26). v3.1 to v3.4: logout and signed-in bar, same-address Staff view, PIN-only lock screen, customer vs staff detection.
Left for later: push alerts, deleting seasons/specials.

## v3 (2026-10-25)
Specials strip with Drink of the day (auto-slides every 7 s, swipe), Share button, staff Specials editor in admin.html, sql/v3.sql (run after v2.sql). Cache bk-menu-v3.
Left for later: seasons, push alerts, today tiles, staff list screen, scheduled release.

## v2.2 (2026-10-25)
config.js filled with the menu project address and publishable key. Cache bk-menu-v2.2.

## v2.1 (2026-10-25)
Fix: works with new Supabase publishable keys (no Bearer header unless the key is a JWT). Cache bk-menu-v2.1.

## v2 (2026-10-25)
Staff control: admin.html (login, edit price, Sold out, Hold, Action PIN, notice banner, recent changes), sql/v2.sql, config.js.
Set up: 1) Supabase new project. 2) Run sql/v2.sql, reply "done". 3) Authentication > Users: add owner and staff. 4) Run the last commented line of v2.sql with their emails. 5) Put Project URL and anon key in config.js, upload site zip. 6) Open /admin.html, log in, set the PIN once.
Until config.js is filled, the menu runs from menu.json and admin.html says "not set up yet".
Left for v3: today tiles, staff list screen, scheduled release, specials, share, push alerts, QR.

## v1.1 (2026-10-25)
Real BK logo: app icons (192, 512) and splash screen. Cache name bk-menu-v1.1.

## v1 (2026-10-25)
Public bilingual (English / Tigrinya / both) beverage menu, PWA, works offline.
Built features: F01 F02 F03 F04 F06 F07 F08 F70 F50 F55 (9 pages with prev/next and phone Back) F90 F91 (menu.json) F94 (print/PDF) F95 (chips and dots).
Not in v1: QR code (needs the live address), SQL (menu is static until v2), staff features (v2), extras (v3).
Edit prices now: change menu.json, then raise the version in sw.js (cache name) and upload the site zip.
Rebuild data from the old menu: tools/build_menu.py.
Host: Cloudflare Pages, upload the site zip contents. _headers keeps sw.js, index.html and menu.json fresh.
