/* BK menu v5.6, batch C: shake the phone to celebrate. Three quick shakes call the callback; a tap does the same (phones with no motion sensor, or iPhone, which asks permission once, on a tap).
   Also a small confetti burst. No downloads, no libraries. Test hooks: BKS.fake(n) feeds n strong movements, BKS.state() tells what is going on. */
(function(){
const S={threshold:28,need:3,window:1200,gap:2500};
let cb=null,armed=false,last=0,hits=[],prev=null,count=0,permission='unknown';
const has=typeof window!=='undefined'&&('DeviceMotionEvent' in window);
const ask=has&&typeof DeviceMotionEvent.requestPermission==='function';
/* one movement sample: the change on the three axes since the last sample; 3 big changes inside 1.2 seconds = one shake */
function feed(x,y,z,t){t=t||Date.now();if(prev){const d=Math.abs(x-prev.x)+Math.abs(y-prev.y)+Math.abs(z-prev.z);
  if(d>S.threshold){hits=hits.filter(h=>t-h<S.window);hits.push(t);if(hits.length>=S.need&&t-last>S.gap){last=t;hits=[];count++;if(cb)cb('shake')}}}
 prev={x,y,z}}
function onMotion(e){const a=e.accelerationIncludingGravity||e.acceleration;if(!a||a.x==null)return;feed(a.x||0,a.y||0,a.z||0)}
/* arm: start listening. On iPhone this must be called from a tap. Returns true when the sensor is listening. */
async function arm(){if(armed)return true;if(!has)return false;
 if(ask){try{permission=await DeviceMotionEvent.requestPermission()}catch(e){permission='denied'}if(permission!=='granted')return false}else permission='granted';
 addEventListener('devicemotion',onMotion);armed=true;return true}
function disarm(){if(armed)removeEventListener('devicemotion',onMotion);armed=false;prev=null;hits=[]}
/* confetti: a full-screen canvas for about 3 seconds, then removed. colours: array of hex. */
function confetti(cols,n){if(typeof document==='undefined')return;if(matchMedia&&matchMedia('(prefers-reduced-motion: reduce)').matches)return;
 cols=cols&&cols.length?cols:['#e3b64b','#f5e6b8','#ffffff','#c9a54c'];n=n||140;
 const old=document.getElementById('bks-c');if(old)old.remove();
 const c=document.createElement('canvas');c.id='bks-c';c.setAttribute('aria-hidden','true');c.style.cssText='position:fixed;inset:0;width:100%;height:100%;z-index:90;pointer-events:none';
 const W=c.width=innerWidth,H=c.height=innerHeight;document.body.appendChild(c);const g=c.getContext('2d');if(!g){c.remove();return}
 const P=Array.from({length:n},(_,i)=>({x:W/2+(Math.random()-.5)*W*.5,y:H*.62,vx:(Math.random()-.5)*14,vy:-8-Math.random()*13,w:5+Math.random()*6,h:3+Math.random()*5,r:Math.random()*6.28,vr:(Math.random()-.5)*.4,c:cols[i%cols.length]}));
 const t0=performance.now();(function f(now){const t=now-t0;g.clearRect(0,0,W,H);P.forEach(p=>{p.vy+=.34;p.vx*=.992;p.x+=p.vx;p.y+=p.vy;p.r+=p.vr;g.save();g.globalAlpha=Math.max(0,Math.min(1,(3000-t)/800));g.translate(p.x,p.y);g.rotate(p.r);g.fillStyle=p.c;g.fillRect(-p.w/2,-p.h/2,p.w,p.h);g.restore()});
  if(t<3000)requestAnimationFrame(f);else c.remove()})(t0)}
const api={on:f=>{cb=f},arm,disarm,confetti,supported:has,needsTap:ask,feed,
 fake:n=>{prev={x:0,y:0,z:0};let t=Date.now();for(let i=0;i<(n||3);i++){t+=150;feed(i%2?30:-30,i%2?-30:30,i%2?20:-20,t)}},/* test hook: n strong movements in a row */
 reset:()=>{last=0;hits=[];prev=null;count=0},state:()=>({armed,permission,count,supported:has,needsTap:ask}),settings:S};
(typeof window!=='undefined'?window:globalThis).BKS=api;if(typeof module!=='undefined')module.exports=api;
})();
