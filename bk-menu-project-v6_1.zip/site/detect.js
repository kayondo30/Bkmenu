/* BK menu v5.6, batch A: detect what a NEW item is (drink or food) and which page and section it belongs to, from its name.
   Order: 1) a brand word already on the menu (Chivas, Smirnoff...) puts it beside its relatives; 2) keyword rules; 3) nothing found = staff choose.
   Pure functions, no screen code, so it can be tested alone. Staff always see the guess and can change it before saving. */
(function(){
const norm=s=>String(s||'').toLowerCase().normalize('NFKD').replace(/[\u0300-\u036f]/g,'').replace(/[^a-z0-9 ]+/g,' ').replace(/\s+/g,' ').trim();
const toks=s=>norm(s).split(' ').filter(w=>w.length>2);
/* [words (regex, whole words), page, section]. Page names match the BK menu; another client's pages are found by the PAGE_HINT fallback below. */
const DRINK=[
 ['cocktail juice|juice|fresh juice','Juices','Fresh & Pure'],
 ['cocktail|mojito|margarita|daiquiri|pina colada|cosmopolitan|negroni|martini|old fashioned|sunrise|bloody mary|long island|mule|spritz|sour|caipirinha|mocktail|virgin','Cocktails','Cocktails'],
 ['iced coffee|iced latte|iced mocha|iced chocolate|iced americano|cold brew|frappe','Iced','Iced Coffee'],
 ['iced tea|ice tea|iced lemon tea','Iced','Iced Tea'],
 ['milkshake|shake|float','Shakes & Smoothies','Milkshakes'],
 ['smoothie','Shakes & Smoothies','Smoothies'],
 ['hot chocolate|cocoa','Coffee','Hot Chocolate'],
 ['espresso|latte|cappuccino|macchiato|mocha|americano|flat white|cortado|ristretto|doppio|affogato|lungo','Coffee','Espresso & Milk Coffees'],
 ['black coffee|filter coffee|french press|turkish|ethiopian coffee|buna|jebena|ground coffee|coffee','Coffee','Brewed & Traditional Coffee'],
 ['dawa','Tea','Dawa Teas'],
 ['ginger tea|mint tea|lemon tea|herbal|camomile|chamomile|hibiscus tea|lemongrass|infusion|rooibos|green tea','Tea','Infusions'],
 ['tea|chai|masala','Tea','Classic Teas'],
 ['passion|mango|pineapple|watermelon|orange|avocado|tamarind|sugarcane|fresh pressed|apple|kiwi|carrot|beetroot|lemonade','Juices','Fresh & Pure'],
 ['beer|lager|stout|pilsner|cider|ale|club|nile|tusker|bell|guinness|heineken|castle|savanna|corona|windhoek|ipa','Beer & Soft','Beer & Cider'],
 ['soda|coke|coca cola|pepsi|fanta|sprite|mirinda|water|tonic|ginger ale|mixer|energy|redbull|red bull|krest|soft drink|bitter lemon|malt|sting','Beer & Soft','Soft Drinks & Mixers'],
 ['single malt|glenfiddich|glenlivet|macallan|lagavulin|talisker|laphroaig|balvenie|singleton','Whisky','Single Malt'],
 ['bourbon|jameson|jack daniel|jack daniels|jim beam|bushmills|tullamore|irish|rye','Whisky','Irish & American'],
 ['whisky|whiskey|scotch|johnnie walker|chivas|ballantine|grant|j&b|jb|black and white|dewar|famous grouse|cutty|vat 69|label','Whisky','Blended Scotch'],
 ['vodka|smirnoff|absolut|ciroc|grey goose|belvedere|skyy','Spirits','Vodka'],
 ['gin|gordon|bombay|tanqueray|hendrick|beefeater|gilbey|waragi','Spirits','Gin'],
 ['rum|captain morgan|bacardi|havana|malibu|kraken','Spirits','Rum'],
 ['tequila|patron|jose cuervo|cuervo|olmeca|don julio','Spirits','Tequila'],
 ['brandy|cognac|hennessy|remy martin|martell|courvoisier|vsop|xo','Spirits','Brandy & Cognac'],
 ['liqueur|baileys|amarula|kahlua|cointreau|jagermeister|sambuca|amaretto|disaronno|archers','Spirits','Liqueurs'],
 ['areqi|arake|zibib','Spirits','Areqi'],
 ['champagne|prosecco|sparkling|bubbly|moet|veuve|brut|cava|mimosa','Wine & Bubbly','Champagne & Other'],
 ['wine|merlot|cabernet|shiraz|malbec|chardonnay|sauvignon|pinot|rose|red wine|white wine|mulled|sangria','Wine & Bubbly','Wine']
];
const FOOD=[
 ['breakfast|omelette|omelet|pancake|waffle|french toast|porridge|oats|egg|eggs|fatira|fatah|ful|foul','Food','Breakfast'],
 ['burger|cheeseburger|sandwich|club sandwich|wrap|shawarma|hot dog|hotdog|toastie|panini|sub|kebab sandwich|chapati','Food','Burgers & Sandwiches'],
 ['salad|soup|lentil|minestrone|caesar','Food','Salads & Soups'],
 ['cake|croissant|muffin|brownie|cookie|donut|doughnut|pastry|pie|tart|cheesecake|scone|bun|cupcake|ice cream|sundae|pudding|dessert|baklava|gateau','Food','Cakes & Pastries'],
 ['chips|fries|samosa|spring roll|nuggets|wings|popcorn|crisps|bites|sausage|gnuts|groundnuts|peanuts|nachos|snack|bhajia|kachori|mandazi|rolex|plantain|gonja|cassava|chicken wings|calamari','Food','Snacks & Bites'],
 ['rice|pasta|spaghetti|pizza|chicken|beef|goat|fish|tilapia|lamb|steak|stew|curry|pilau|pilaf|posho|matooke|injera|zigni|tsebhi|shiro|alicha|kitfo|tibs|lasagne|lasagna|noodles|ugali|meal|platter|grill|bbq|roast|fillet|liver|stir fry|biryani','Food','Meals']
];
const FOODPAGE=/food|snack|meal|bite|breakfast|kitchen|dessert|cake|pastr|eat/i;
const re=w=>new RegExp('(^| )('+w.split('|').map(x=>x.trim().replace(/[.*+?^${}()|[\]\\]/g,'\\$&')).join('|')+')( |$)');
const R=(L)=>L.map(r=>({re:re(r[0]),pg:r[1],sec:r[2],w:r[0]}));
const RD=R(DRINK),RF=R(FOOD);
const GENERIC=new Set('red black gold white blue green label special fresh hot cold the and with big small large single double glass bottle can shot extra premium house new old classic original reserve'.split(' '));
const eqi=(a,b)=>norm(a)===norm(b);
function pages(items){const o=[];(items||[]).forEach(i=>{if(i&&i.grp&&!o.includes(i.grp))o.push(i.grp)});return o}
function secs(items,g){const o=[];(items||[]).forEach(i=>{if(i&&i.grp===g&&i.sec&&!o.includes(i.sec))o.push(i.sec)});return o}
/* the page on the menu that fits a rule's page name: same name, or one that contains its main word (Whisky, Whiskies) */
function findPage(items,pg){const P=pages(items);let m=P.find(p=>eqi(p,pg));if(m)return m;const k=norm(pg).split(' ')[0].slice(0,5);m=P.find(p=>norm(p).includes(k));return m||null}
function findSec(items,g,sec){const S=secs(items,g);let m=S.find(s=>eqi(s,sec));if(m)return m;const k=norm(sec).split(' ')[0].slice(0,5);m=S.find(s=>norm(s).includes(k));return m||null}
/* 1) a word that is on the menu already (brand): the new item goes beside its relatives */
function relative(name,items){const T=toks(name).filter(w=>!GENERIC.has(w));if(!T.length)return null;
 const df={};(items||[]).forEach(i=>{new Set(toks(i.name)).forEach(w=>df[w]=(df[w]||0)+1)});
 let best=null,bs=0;(items||[]).forEach(i=>{const it=new Set(toks(i.name));let s=0;T.forEach(w=>{if(it.has(w)&&df[w]<=4)s+=1/df[w]});if(s>bs){bs=s;best=i}});
 return bs>=.25?best:null}
function rule(L,name){const n=norm(name);for(const r of L)if(r.re.test(n))return r;return null}
/* kind: '' (let the name decide), 'drink' or 'food' (staff chose). Returns {type, grp, sec, newPage, newSec, why} or {type:'', grp:'', sec:'', why:''} when nothing is known. */
function detect(name,items,kind){items=items||[];const none={type:kind||'',grp:'',sec:'',newPage:false,newSec:false,why:''};if(!norm(name))return none;
 const rf=rule(RF,name),rd=rule(RD,name),rel=relative(name,items),relT=rel?(FOODPAGE.test(rel.grp)?'food':'drink'):'';
 /* the kind: staff's choice, else the name's keywords (food words first: "coffee cake"), else the kind of the relative on the menu */
 const type=kind||(rf?'food':rd?'drink':relT);
 if(!type)return none;
 const r=type=='food'?rf:rd;
 if(!r){ /* no keyword: beside a relative of the same kind, else the usual food page, else staff choose */
  if(rel&&relT==type)return{type,grp:rel.grp,sec:rel.sec,newPage:false,newSec:false,why:'next to '+rel.name};
  if(type=='food'){const fp=pages(items).find(p=>FOODPAGE.test(p));if(fp){const S=secs(items,fp);return{type,grp:fp,sec:S[0]||'Meals',newPage:false,newSec:!S.length,why:'the food page'}}return{type,grp:'Food',sec:'Meals',newPage:true,newSec:true,why:'a new Food page'}}
  return{...none,type}}
 let g=findPage(items,r.pg),newPage=false;
 if(!g&&type=='food')g=pages(items).find(p=>FOODPAGE.test(p))||null;
 if(!g){g=r.pg;newPage=true}
 let s=newPage?null:findSec(items,g,r.sec),newSec=false;
 if(!s){s=r.sec;newSec=true}
 return{type,grp:g,sec:s,newPage,newSec,why:'looks like '+r.w.split('|')[0]}}
/* v5.7: price suggestions for a new item: the price of its closest relative on the menu, then the most used prices in the chosen section */
function priceHints(name,items,grp,sec){items=items||[];const out=[],seen=new Set(),has=p=>String(p||'').trim();
 const rel=relative(name,items);if(rel&&has(rel.price)){out.push({price:rel.price,why:'like '+rel.name});seen.add(rel.price)}
 const cnt={};items.filter(i=>i.grp===grp&&i.sec===sec&&has(i.price)).forEach(i=>cnt[i.price]=(cnt[i.price]||0)+1);
 Object.keys(cnt).sort((a,b)=>cnt[b]-cnt[a]||a.localeCompare(b)).forEach(p=>{if(out.length<5&&!seen.has(p)){out.push({price:p,why:cnt[p]+(cnt[p]==1?' item':' items')});seen.add(p)}});
 const note=(items.find(i=>i.grp===grp&&i.sec===sec&&has(i.note))||{}).note||'';
 return{list:out,note}}
const G=typeof window!=='undefined'?window:globalThis;G.BKDET={priceHints,detect,norm,pages,secs,FOODPAGE};
if(typeof module!=='undefined')module.exports=G.BKDET;
})();
