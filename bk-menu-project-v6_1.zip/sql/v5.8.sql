-- BK menu v5.8: "Who changed what" on the staff page. Run once in Supabase > SQL Editor (new query tab), then check with:
--   select proname from pg_proc where proname = 'list_changes';   -> 1 row
-- It only READS the existing audit_log (nothing is changed or lost). Staff only.
create or replace function list_changes(n int default 100)
returns table(id int, at timestamptz, who text, action text, detail text, item text, variant text)
language sql security definer stable set search_path=public as $$
 select a.id, a.at, u.email::text, a.action, a.detail, m.name, m.variant
 from audit_log a
 left join auth.users u on u.id = a.who
 left join menu_items m on m.id = (case when a.action ~ '^(item|edit) [0-9]+$' then split_part(a.action,' ',2)::int end)
 where is_staff()
 order by a.id desc
 limit least(coalesce(n,100),500) $$;
grant execute on function list_changes(int) to authenticated;
