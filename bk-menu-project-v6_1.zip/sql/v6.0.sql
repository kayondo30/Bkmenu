-- BK menu v6.0: a REASON is required when an item is hidden, and it is written in the change log.
-- Run once in Supabase > SQL Editor (new query tab). "Success. No rows returned" is normal.
-- Check: select proname from pg_proc where proname = 'staff_update_item3';   -> 1 row
-- Nothing is deleted or changed in your data. The old staff_update_item2 stays (not used by v6.0).
create or replace function staff_update_item3(i int,p text,sold bool,hid bool,sid int,why text,pin text)
returns text language plpgsql security definer set search_path=public,extensions as $$
declare w text; was bool; r text := left(trim(coalesce(why,'')),200); d text;
begin
 w:=chk_pin(pin); if w<>'ok' then return w; end if;
 select hidden into was from menu_items where id=i; was:=coalesce(was,false);
 if coalesce(hid,false) and not was and r='' then return 'need_reason'; end if;
 update menu_items set price=p,sold_out=sold,hidden=hid,season_id=sid where id=i;
 d:='price '||p||', sold out '||sold||', hold '||hid||', season '||coalesce(sid::text,'none');
 if coalesce(hid,false) and not was then d:=d||', HIDDEN';
 elsif was and not coalesce(hid,false) then d:=d||', SHOWN AGAIN'; end if;
 if r<>'' then d:=d||', reason: '||r; end if;
 insert into audit_log(who,action,detail) values(auth.uid(),'item '||i,d);
 return 'ok'; end $$;
grant execute on function staff_update_item3(int,text,bool,bool,int,text,text) to authenticated;
