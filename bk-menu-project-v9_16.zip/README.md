# BK Beverage Menu
Short list of every version: CHANGELOG.md. Detail below.

## v9.16 (2026-11-06)
Closing a table asks for the waiter's PIN, then the phone locks (owner's choice, L19). Database: v9.16.sql (run once after v9.15.sql; undo v9.16-undo.sql): waiter_close_table now takes the PIN (tok, sid, pin) and the old two-argument version is removed, so a table can not be closed without the PIN even outside the app. Wrong PIN: bad_pin, the table stays open. Three wrong PINs (counted with wrong logins) lock the waiter for 15 minutes and end every login of that waiter. A successful close ends this phone's login. Site (waiter.html): Close table opens a PIN box with Close for good and Cancel; the box and what was typed survive the 6-second refresh; after closing, the login shows with the name filled in and "Table ... closed. Type your PIN to continue". To go and room cards close the same way. Note: while logged out the phone does not beep for new orders, so the waiter types the PIN again soon after closing. Site files changed: waiter.html, index.html (version line), sw.js, admintest.js (new item closepin, 33 items). Tests: waiter 72, guest 70, browser 59, detect 47, guide 10.

## v9.15 (2026-11-06)
Joining and security, from the owner's rules L13, L14 and L16. Database: v9.15.sql (run once after v9.13.sql; undo v9.15-undo.sql). Site files changed: index.html, waiter.html, sw.js, admintest.js (still 21 files).
One scan = one phone: a new join_keys table holds one-time keys. guest_status gives each phone that may share (host always; the others while Let is on) its own QR key and makes a new one as soon as it is used. A key is either "qr" (shown on the screen) or "link" (made by guest_link when the guest taps Send the link).
Sent link = To go guest: guest_join_key seats a link guest as remote (no seat: the 5 seats are for phones at the table; at most 5 link guests). Their orders are all To go and start as awaiting_host. The phone that sent the link (or the host, if that phone left) sees "From your link" with Approve and Decline (guest_host_decide). Approve: the order becomes sent with a 4-digit pickup code and reaches the waiter, billed on the table. Decline: it never reaches the waiter. Waiting and declined orders are left out of every total (guest, waiter, admin) and the waiter cannot step them. The link guest's button says Send to the host, with "Your host approves it, then it goes to the waiter as To go."
Hold deletes every unused key of the table; removing a guest deletes that guest's unused keys; a new master code deletes all unused keys.
Slow down: join_tries now records the phone id (sent by the site) and the internet address; a phone is slowed after 8 wrong tries a minute, an address after 40, everyone after 200 (old site with neither: 30, as before).
Also: is_staff() gets a fixed search path; the old guest_join(code) door from v9.2 is removed; waiter_order_step, waiter_tables and admin_closed_tables updated for the new order states.
Tests: guest 70, waiter 68, browser 59 (32 checklist items, new "link"), detect 47, guide 10, all passing. The SQL could not be run here (no database in the build machine): run it, then the check query, before uploading the site.

## v9.14 (2026-11-06)
No-camera help for joining a table. No SQL; site files changed: index.html, sw.js, admintest.js. Still 21 site files.
Host phone (Waiter sheet > Table ordering, under the QR): "Send the link" shares the join address (?j=key) with the phone's share sheet; if the phone has none it copies the link, and if copying fails it opens WhatsApp with the text. "Friend can't scan?" opens a sheet with the steps: Send the link first; Android Camera (Samsung: Camera settings > Scan QR codes; Google Lens); iPhone Camera; the in-menu scanner; then "Find a scanner app" (Play Store search, Android only; hidden on iPhone because every iPhone camera reads QR codes).
Guest phone (Table ordering): "Scan the host's QR" opens the camera inside the menu and joins the table when it reads a host QR (same as tapping the link). It uses the browser's BarcodeDetector, so it shows on Chrome for Android and stays hidden where the phone cannot read QR codes (iPhone Safari: use the Camera). A To go QR or any other QR is refused with a message. The camera stops when the sheet closes.
Note: the in-menu scanner only helps a guest who already has the menu open (home-screen icon from an earlier visit, or the address typed from the table card). Send the link is the main no-camera path.
Fixes: the "New here?" video could open 1.8 s after page load over a guest who had just joined a table; it now checks again that the phone is not at a table. Tests: test_waiter still expected "Take away" (renamed To go in v9.12); test_browser now expects 31 checklist items; test_guest adds the To go split and the three no-camera features. Results: detect 47, guest 62, waiter 66, browser 59, guide 10, all passing.

## v9.13 (2026-11-05)
To go as a separate order (owner chose: separate order + auto-show the To go QR after sending). Database (v9.13.sql, run once; undo v9.13-undo.sql; needs v9.12.1.sql first): sittings.from_sitting (the table the To go order came from); guest_send_togo(gt, lines) checks the guest and the lines like guest_send_order, allows at most 10 open To go orders per table (too_many), takes a new 4-digit code, opens a takeaway sitting for the same waiter with its own host row (so nobody can pair onto that code), and saves one order whose lines are all To go. Site: Send in My list sends eat-here lines to the table and To go lines through guest_send_togo, then shows the To go code and a QR of "TO GO <code>". Open limit: the guest phone does not follow the To go order (the waiter does), and the To go drinks are not in the guest's Total ordered. README section added in v9.14 (v9.13 left it out).

## v9.12 / v9.12.1 (2026-11-05)
To go per order line. Database (v9.12.1.sql, run once; undo v9.12.1-undo.sql): order_lines.togo boolean not null default false; guest_send_order reads "togo" on each line (missing = false, other values = bad_line); guest_status, waiter_tables, admin_closed_tables return togo. Site: To go button on each line of the guest's list (flips the whole line; a small button moves just one unit; equal lines merge), To go tag on guest orders, waiter cards, New orders and the admin closed-table sheet; 'Take away' renamed 'To go' in the waiter and admin screens. Site files: index.html, waiter.html, admin.html, admintest.js, sw.js. Cache bk-menu-v9.12.

## v9.11 (2026-11-05)
Customer how-to video (site/bk-guest-guide.mp4, 40 s, English only). Guests see it once per visit in a bottom sheet; "Don't show this again" stores hg=1 in that phone's localStorage. Settings > How to use this menu plays it any time and has Show at start / Never show. Rebuild: node tools/video/render-guest.js /tmp/gvideo, then copy the mp4 to site/. Site is now 21 files; no SQL.

## v9.7.1 (2026-11-05)
Header drawings fitted inside the strip (picture 400x120, drawing smaller). No SQL, 20 files.

## v9.7 (2026-11-05)
Header picture on every category: photos.json cat holds 9 designed pictures (data addresses, own art, not photos). To use a real photo for a category, put its address in photos.json under cat. Print button removed. No SQL, 20 files.

## v9.6.1 (2026-11-05)
Site files index.html, sw.js, admintest.js (VER 9.6.1). No SQL, 20 files. Scan to join now opens the table sheet; sheet polls every 4 s while open; clearer message for a QR that is not valid. Owner reported: in Hold the scanned host QR gave "not valid" and landed on the menu; in Let it joined. Cause not proven (the code and SQL look right); if it happens again run: select id, share_qr, join_key from sittings where status='open'; and compare join_key with the ?j= in the QR address.

## v9.6 part H4 of 4 (2026-11-05)
My word: "H4". Site files admintest.js (VER 9.6), index.html (Settings says Version 9.6), sw.js (cache bk-menu-v9.6), bk-staff-guide.mp4. Still 20 files: check "Uploading 20 total file(s)". NO SQL. The host phone work (H1 to H4) is finished.
- Admin test: new automatic check "Host phone functions answer": it calls guest_remove, guest_set_share, waiter_new_master and waiter_remove_guest with a blank key, so nothing is changed; if one is missing it says to run v9.3.sql and v9.3.1.sql. It does not call guest_pair or guest_join_key (they count wrong tries).
- Tick list is 29 lines (was 25). New: scan to join, Hold or Let, host removes a guest, New master code. Changed: the join line (host + QR, code hidden) and the total line (guests see their own total again, v9.5).
- How-to video: 19 steps, 171 s. New Step 14 Host phone and ordering QR (the QR in the picture is only a drawing). Old steps 14 to 18 are now 15 to 19. The title card now says 19 short steps, about 3 minutes.
- Tests: guest 49/49, waiter 66/66, detect 47/47, browser 59/59 (pretend Supabase + headless Chrome), NOT the real database or a phone.

## v9.5.2 (2026-11-05)
Same as v9.5 (no font license file added, by choice). Site zip is 20 files again: check "Uploading 20 total file(s)". No SQL.

## v9.5 part H3 of 4 (2026-11-05)
Guest page, host phone. Waiter sheet: type the waiter's 4-digit code to become the host; the sheet shows the ordering QR (own QR maker inside index.html, address ?j=key), Hold / Let, phones n of 5 and Remove per guest. Scan to join with the camera: joins at once. Guests see their own List total and Total ordered. No SQL. Test: node tools/test_guest.js (49 checks, decodes the QR with python cv2). Deploy: site zip only, 20 files.

## v9.2 part 9c of 9c (2026-11-04)
My word: "9c". Site files index.html (Version 9.2), admin.html, sw.js (cache bk-menu-v9.2), admintest.js (version 9.2), bk-staff-guide.mp4, still 20 files, NO SQL (uses v9.0.sql, already run), NOT yet deployed. Order types are now finished (9a database, 9b waiter page, 9c guest and admin).
- Guest card: the title on My orders / the pairing sheet says Room 12, Take away 6123 - Sam or Table 4719 (the word Table is only put in front for a plain table). A database that sends no type is treated as a table.
- Admin > Closed tables: each closed order says Table, Room service or Take away under its title, and the detail sheet title uses the same label.
- Admin test: version 9.2; checklist now 25 lines (new: Room service, Take away, Closed tables type).
- How-to video: 18 steps, 164 s. New Step 13 Room service and Take away; old steps 13 to 17 are now 14 to 18.
- Tests (pretend Supabase, headless Chrome, NOT the real database or a phone): waiter 56/56, guest 30/30, detect 47/47, browser 59/59.
- To deploy: upload bk-menu-site-v9_2.zip to Cloudflare Pages (should say Uploading 20 total file(s)), put bk-menu-project-v9_2.zip on GitHub. No SQL.

## v9.1 part 9b of 9c (2026-11-04)
My word: "9b". Site files waiter.html, index.html (Version 9.1), sw.js (cache bk-menu-v9.1), admintest.js (version 9.1, so its offline-copy check matches), still 20 files, NO SQL, NOT yet deployed. Needs sql/v9.0.sql (9a) already run (it was, checks passed). Waiter page: New table (Get a code, as before), plus Room service (tap, type the room number, Get a code for this room; blank number is refused; the same room twice says the room is already open) and Take away (tap, optional name, Get a take away code). Cards, the New orders list and the close messages use the right name: Room 12, Take away 6123 - Sam, Table 4719. A plain New table still sends no kind, so it works even before v9.0.sql. Guest and admin screens do not show the type yet (9c). Tests: test_waiter.js 56/56, test_guest.js 26/26, test_detect.js 47/47, test_browser.js 59/59 (pretend Supabase, headless Chrome, NOT the real database or a phone).

## v9.0 part 9a of 9c (2026-11-04)
My word: "9a". SQL ONLY: sql/v9.0.sql (run once in Supabase > SQL Editor; undo: sql/v9.0-undo.sql). Needs v7.0, v7.5 and v7.7 run first. NO site change (site zip stays v7.8, 20 files, nothing to upload). Adds sittings.kind ('table', 'room', 'takeaway'; every existing table becomes 'table') and replaces waiter_open_table with a version that has an optional third argument kind (default 'table'), so the running site keeps working. Room: the waiter must give the room number, label "Room 12", replies need_room / table_busy. Take away: label "Take away 4719" (optional name after it). waiter_tables, guest_status and admin_closed_tables now also return kind. Check after running: select column_name from information_schema.columns where table_name='sittings' and column_name='kind'; (1 row) and select pronargs from pg_proc where proname='waiter_open_table'; (one row, 3). NOT tested against a real database (none here); the site does not use it until 9b.

## v7.8 part 7g of 7 (2026-11-04)
My word: "7g". Site files admintest.js, index.html (Version 7.8), sw.js (cache bk-menu-v7.8), bk-staff-guide.mp4 (new), still 20 files, NOT yet deployed. NO SQL. TABLE ORDERING IS NOW COMPLETE (7a to 7g).
- Admin test (More > Admin test): its version is now 7.8 (it was still checking for the old offline copy bk-menu-v6.1, so it warned wrongly; fixed). New read-only checks: table ordering is set up (counts waiters), Closed tables list works and returns closed tables only, Drink ratings (thumbs) work, Drink ratings are anonymous (no table, waiter or guest). The tick list grew from 11 to 22 items: waiter login, Get a code, guest joins, order, confirm and steps to Served, thumbs, guests see no total, Close table, Closed tables, Drink ratings, pause a waiter. Nothing is saved by the test.
- How-to video: now 155 s, 17 steps. New: 11 Add a waiter, 12 A table from code to Served, 13 Thumbs and Drink ratings. Old steps 11 to 14 are now 14 to 17; Step 16 (Test the app) shows the new checks. Rendered here with Playwright + ffmpeg, frames reviewed; not watched on a phone.
- Tests (tools/): test_waiter.js 44/44 (new: 10 Admin test checks), test_guest.js 26/26, test_detect.js 47/47, test_browser.js 59/59 (checklist now 22 items; the test phone now behaves like an Android phone that needs no permission tap, because this Chrome build exposes requestPermission and the guest page then waits for a tap). All use a pretend Supabase and headless Chrome, NOT the real database or a real phone.
- Deploy: site zip to Cloudflare Pages ("Uploading 20 total file(s)"), project zip to GitHub. No SQL this time (v7.7.sql from 7f must already be run).
- Real test on the venue (Admin test > Part 2, tick each): follow the 11 table-ordering lines in order with one waiter phone and one guest phone.

## v7.7 part 7f of 7 (2026-11-04)
My word: "7f". Site files index.html, waiter.html, admin.html (Version 7.7), sw.js (cache bk-menu-v7.7), still 20 files, NOT yet deployed. SQL: sql/v7.7.sql (run once in Supabase > SQL Editor; undo: sql/v7.7-undo.sql). Needs v7.0.sql run first. Guest: once an order is Served, each drink has thumbs up and thumbs down (tap the same one again to clear, tap the other to switch); the database only accepts a vote for a Served drink on an open table of that guest. Waiter: a thumbs down shows on that drink as "ask the guest" (no sound), a thumbs up shows a small thumb. Admin: More > Table ordering > Closed tables shows the thumb on each drink, and the Drink ratings button lists likes and dislikes per drink from CLOSED tables only (no table, waiter or guest). Check after Run: select proname from pg_proc where proname in ('guest_vote','admin_item_votes'); -> 2 rows. Tested: tools/test_waiter.js 34/34, tools/test_guest.js 26/26 (pretend Supabase), NOT the real database or a phone. Next: 7g tests, Admin test checks, how-to video and docs.

## v7.6 part 7e of 7 (2026-11-04)
My words: "7e". Site files admin.html, index.html (Version 7.6), sw.js (cache bk-menu-v7.6), NO SQL (uses admin_closed_tables from v7.0.sql), still 20 files, NOT yet deployed. More > Table ordering > Closed tables: read-only list of finished tables (table, closed by, times, total), tap one for every drink. An open table is never shown (database enforced). Guest progress (Sent to Served) and the waiter Close table were already done in v7.2 to v7.4; guests see NO totals. Tested: tools/test_waiter.js 29/29, tools/test_guest.js 20/20 (pretend Supabase). Not tested on the real database. Next: 7f thumbs (optional) or 7g tests, Admin test, video, docs.

## v7.5 (2026-11-04)
My words: "the table isn't needed, the code should play that part". Site files waiter.html, index.html, sw.js + sql/v7.5.sql (run once, replaces only the function waiter_open_table; undo: sql/v7.5-undo.sql). Waiter page: no table number box; Get a code makes the 4-digit code and the table is named by it (Table 4719) on the waiter page, the guest sheet and Admin closed tables. If v7.5.sql is not run yet, Get a code says Run v7.5.sql in Supabase first. Tested in headless Chrome with a pretend Supabase (tools/test_waiter.js, 25 checks), NOT the real database. Cache bk-menu-v7.5, NOT yet deployed.

## v7.4 part 7d of 7 (2026-11-04)
My words: "Do 7d". Site files only (waiter.html, index.html, sw.js), NO SQL (uses waiter_tables and waiter_order_step from v7.0.sql), still 20 files, cache bk-menu-v7.4, NOT yet deployed. Waiter page: new orders (status sent) show on top, oldest first, with table, guest and every drink; a two-tone beep, phone vibration and a (n) count in the tab title repeat every 20 s while one waits (page polls every 6 s while open). Waiter confirms by mouth, taps Confirmed with the guests (received), then Mark Preparing, Mark On the way, Mark Served; guests see the progress. Each open table lists each guest (how he plans to pay, his subtotal), his orders and a Table total (staff view only; guests still see no money). Closing a table with an unconfirmed order warns. Sound on/off button; a phone that has not been tapped yet shows Tap here to switch the alert sound on (phones only allow sound after a tap). Tested in headless Chrome with a pretend Supabase (tools/test_waiter.js, 24 checks), NOT against the real database or a real phone. Sound only works while the waiter page is open on screen.

## v7.1 part 7b of 7 (2026-11-04)
My words: "Yes" (admin acts as a waiter) then "Do 7b". Site files only (admin.html, waiter.html NEW, sw.js), NO new SQL (needs v7.0.sql run: done), 20 files, cache bk-menu-v7.1, NOT yet deployed. Staff: More > Table ordering > Waiters (add, pause, new PIN, copy the waiter page address). Waiter page waiter.html: name + PIN, table number, 4-digit code, own open tables, Close table. Test: node tools/test_waiter.js (14 checks). Next: 7c guest joins + two-tap order, only when I say.

## v6.6 part 1 of 4 (2026-11-03)
My words: "Just split 2 into 4 parts", then "Now do 1" (roadmap item 2, Happy hour). SQL ONLY: sql/v6.6.sql (undo: sql/v6.6-undo.sql). No site change: still 19 files, cache bk-menu-v6.5, nothing to deploy. Tables happy_hours (name, days 0=Sunday..6=Saturday, start_min/end_min minutes after midnight on the guest's phone clock, overnight allowed, active) and happy_hour_rules (page + percent, or item + percent, or item + fixed happy price). Row security: guests read only active happy hours, staff read all. Functions, all PIN-checked and written in Who changed what: staff_save_happy (saves a happy hour and all its rules together), staff_set_happy_active, staff_delete_happy. Defaults chosen without my answer: both discount types, phone clock, overnight allowed, several happy hours at once. The real price is never changed; the guest menu will work the happy price out (part 3). Parts still to build: 2 staff screen, 3 guest menu, 4 tests, video step and docs. Not tested against a real database: after Run, use the check queries at the top of the file.

## v6.5 (2026-11-03)
Roadmap items 5 (Call waiter) and 8 (Mobile Money list, simple version). Site files only (index.html, config.js, sw.js), NO SQL, still 19 files, cache bk-menu-v6.5. A Waiter button joins the bottom bar (now 6 buttons). Its sheet has: Your table (from the QR address ending ?t=5, kept 6 hours on that phone, or typed), Call waiter, and Ways to pay. Call waiter: if config.js has waiter.whatsapp, WhatsApp opens with "Table 5: a waiter is needed, please."; if empty, a big "Table 5" card is shown to wave at a waiter. Ways to pay: config.js pay list, a waiter confirms by hand, the app never touches money; tap a number to copy it. Not done: staff do not get an alert inside the app (needs SQL, later with Ordering); no Tigrinya words yet (ask the owner). Staff how-to video not changed (no staff feature). Tested in headless Chrome at phone size; not on a real phone.

## v6.4.2 (2026-11-03)
My words: "The video after". Site files only, NO SQL, cache bk-menu-v6.4.2, 19 files, NOT yet deployed. The how-to video (bk-staff-guide.mp4, inside the site zip) is re-rendered from tools/video: 126 s, 14 steps. New steps: 7 Scan a bottle, 8 Add the cost, 9 Set the margin, 10 Price check (old steps 7 to 10 are now 11 to 14). Settings says Version 6.4.2. Not tested on a phone.

## v6.4.1 (2026-11-03)
Prompt only, nothing to deploy. Mobile Money became a list of payment methods that a waiter confirms by hand (ships with ordering). Fixed stale text: the site zip is 19 files, not 11.

## v6.4 (2026-11-03)
My words: "Now choose what you will start with" (Claude chose roadmap item 1, Price check). Site files only, NO SQL, 19 files, cache bk-menu-v6.4. Staff page > More > Price check: lists items that have a Cost and one shilling price whose profit % is under the target % of their page (More > Cost and margin), lowest first, each with the suggested price (same maths as v6.2, nearest 500/=, only shown when higher than the current price). Tap a row to open the drink and tap the suggested price chip, then Save. Read-only: nothing changes by itself. Items without a cost, or with two sizes, are not checked (the sheet says how many). Needs the v6.2 cost tables (sql/v6.2.sql) to show. Code: BKDET.priceCheck in detect.js, More screen in admin.html. Tests: tools/test_detect.js, tools/test_browser.js section 6.

## v6.3 (2026-11-03)
My words: "add in the scan of a drink or a bottle of whiskey ... if it is a good feature add it". Site files only, NO SQL, 19 files, cache bk-menu-v6.3. Add a drink or food > Scan a bottle: take a photo of the barcode; the phone reads it (BarcodeDetector: Chrome on Android; iPhone Safari cannot yet, it says so and staff type the name), looks it up in the free Open Food Facts list (needs internet) and fills the Name and Size (70 cl = 700ml), then the normal page/section detection and price chips run. Nothing is saved until Add it. No API key, no cost. LIMITS: the public list does not know every bottle (then: "not in the public list, type the name"); names can be messy, staff check. NOT TESTED on a real phone or against the live list (no network here; tested with the maths helpers and the existing 54 browser checks). FUTURE (v6.4, only if wanted): photo of the LABEL read by AI for bottles with no barcode; needs a Supabase Edge Function, an Anthropic API key kept server-side and a small cost per scan.

## v6.2 (2026-11-03)
My words: "Work on it now" (cost + margin price suggestions). My three answers were not given, so these DEFAULTS were built and are easy to change: 1) MARGIN on the selling price (price = cost / (1 - margin)), 2) start 50%, 3) one default % for every page PLUS an optional own % per page (empty = the default). Needs sql/v6.2.sql run once (tables item_costs and margin_rules, staff-only read; functions staff_set_cost and staff_set_margin, PIN checked, written in Who changed what WITHOUT the amount). 18 + video = 19 site files, cache bk-menu-v6.2. Costs are NEVER a column on menu_items. Add a drink or food: optional Cost box; when typed, a chip like "4,000/= cost 2,000/= + 50%" appears FIRST, before the current chips (tap to fill, you can still type your own); no cost = no cost chip. Tap-a-drink sheet: Cost box, the same chip, and "Profit 2,000 (50%)" (single prices only). More > Cost and margin > Margin % for price suggestions. Rounded to the nearest 500/=. Without v6.2.sql the cost boxes stay hidden and nothing else changes. Tests: test_detect.js (+12 maths checks), test_browser.js 54/54. The how-to video was NOT re-rendered (no network here): re-render later with tools/video.

## v6.1 (2026-11-03)
My words: "edit this video to the current features and it should be in the app on the admin side". Site files only, NO SQL (the video is a plain file in the site zip, nothing is stored in Supabase). DEPLOY COUNT NOW 19 FILES: the 18 before plus bk-staff-guide.mp4 (2.9 MB); check "Uploading 19 total file(s)". Video remade from tools/video/howto.html (render with: node tools/video/render.js /tmp/video, needs Playwright and ffmpeg; copy the result to site/bk-staff-guide.mp4): 97 seconds, 11 steps, portrait, captions, no sound. New or changed steps: 4 Change a price or a NAME, 5 Sold out or hide WITH A REASON, 6 Add a drink or food with PRICE SUGGESTIONS (example Caramel Latte), 10 WHO CHANGED WHAT; Step 3 and the closing card mention the change log. In the app: staff screen > More > "How to use the app" > Watch the how-to video (opens in a sheet, needs internet, stops when the sheet closes). sw.js lets .mp4 requests go straight to the network (no offline copy, no caching problems with video ranges). Cache bk-menu-v6.1. Tests: 51 browser checks pass. RULE: when a feature changes what staff see, update tools/video/howto.html, render again and replace the mp4.

## v6.0 (2026-11-03)
My words: "when an admin hides something he gives a reason why, so the change log has the details". Site files only (18) plus ONE new SQL file, sql/v6.0.sql (function staff_update_item3; nothing deleted, the old staff_update_item2 stays unused). In the tap-a-drink sheet, switching Hide from menu ON shows a box "Why are you hiding it? (required)" (max 120 characters); saving without a reason is refused ("Please give a reason for hiding it"), by the app AND by the server (need_reason). Switching Hide OFF shows an optional note. Who changed what now reads like: "Gold Label: price 220,000 · HIDDEN from the menu · Reason: Out of stock until Friday", with the login name and the time; showing it again reads "shown again". The reason is only asked when the item changes from shown to hidden (saving a price on an already hidden item does not ask again). NOT covered yet: hiding a special or a season (untick Show), Sold out today, Delete. Without v6.0.sql, saving an item says "Not saved: run the file bk-menu-v6.0.sql in Supabase once". sw.js cache bk-menu-v6.0. Tests: 48 browser checks pass.

## v5.9 (2026-11-03)
My words (screenshot of the Gold Label sheet): "now add how to edit the item name". Site files only, NO SQL, 18 files. The item sheet (tap a drink) now has a visible Name box at the top with the hint "Change the name here, then tap Save"; the main Save saves the name too (an empty name is refused: "Type a name first"). More options now holds Size, descriptions and Delete. The price hint under Price now reads "One price, or two sizes like 4,000 / 6,000" (it said "Two sizes" on every drink). sw.js cache bk-menu-v5.9.

## v5.8 (2026-11-03)
My words: "inside the app just to know who could have changed the menu and at what time". Site files only (18 files) plus ONE new read-only SQL file, sql/v5.8.sql (function list_changes; nothing changed or lost). Staff page > More > "Who changed what": the last 8 changes, each with what happened (item name, new price, sold out or hidden, added, edited, deleted, special, season, notice banner), WHO (the part of the login email before @) and the date and time on this phone; "See all" opens the last 100. It reads the existing audit_log, so older changes show too (older rows kept the item number only, v5.8.sql adds the item name). Without v5.8.sql the old short list shows and says to run it. LIMITS: it names the LOGIN, not the person (two people on one login look the same); changes made directly inside Supabase are not recorded; staff cannot edit or delete the log. sw.js cache bk-menu-v5.8. Tests: 43 browser checks pass.

## v5.7 (2026-11-03)
My words: "could you add the price suggestions". Site files only, NO SQL, still 18 site files. In Add a drink or food, under Price: tap-to-fill chips. First the price of the closest relative on the menu (name shares a brand word), then the most used prices in the chosen page and section with how many items use each; a section note such as "Every milkshake" is shown as text. Chips follow the page and section when they change. Code: BKDET.priceHints in detect.js. sw.js cache bk-menu-v5.7. Tests: 43 browser checks.

## v5.6 (2026-11-03)
My words: "make the how to use the app video for admins; for new items choose drink or food and detect the category; on the celebration day decorate by shaking the phone, one carousel card saying Happy Independence Day, shake your phone to celebrate with us; create the admin testing; batch the items into small splits; run it". Site files only, NO SQL, 18 site files (3 new, each one batch).
BATCH A, detect.js: the Add screen guesses drink or food and the page and section from the name (keywords for the BK pages, brands already on the menu, food words). Tested by tools/test_detect.js (30 checks on the real menu).
BATCH B, admin.html: "+ Add a drink or food": Name first, then Not sure / Drink / Food, then Page and Section already filled in. A page or section that does not exist yet is offered as a new one (Food, Cocktails). A page or section chosen by hand is never overridden. No SQL: the existing staff_add_item already creates a new page when the page name is new.
BATCH C, shake.js + index.html: on a celebration DAY the carousel gets ONE card: "Happy <celebration>" and "Shake your phone to celebrate with us" with a Tap to celebrate button. Until then the header shows only the calm season garland. Three quick shakes (or a tap) start the full decoration of the day and a 3-second confetti burst; it stays for that day on that phone. iPhone asks for motion permission on the tap. Previews (?deco=indep) behave the same but are not remembered. Settings Celebration decorations Off turns it all off.
BATCH D, admintest.js: More > Admin test: 23 automatic read-only checks (connection, tables, staff, PIN, detection, shake, celebration calendar, offline copy), an 11-line tick list for what only a person can check, a shake test on the phone, and Copy the result.
VIDEO: tools/video (howto.html + render.js) makes bk-staff-guide.mp4, 18 steps (v9.2), about 2.7 minutes, captions on screen, portrait. The file is inside the site zip and plays in More > Watch the how-to video. Render: node tools/video/render.js (needs Playwright and ffmpeg).
TESTS: node tools/test_detect.js and node tools/test_browser.js (headless Chrome, pretend Supabase, 40 checks incl. shake, real-day clock 24 May 2027, add item through the PIN, admin test).
LOCKED: the shake hint is English only until the owner gives the Tigrinya words. sw.js cache bk-menu-v5.6, shake.js added to the offline files.

## v5.5 (2026-11-01)
One bump, my words: "design the best, just a single bump; on a new menu project I won't be redoing anything much, just changing names of the company". Site files only, NO SQL, 15 site files.
1) THE SPECIAL CARD, richer: a soft accent glow, a gold hairline on top, a bigger title, the price as a pill, a large faint drawing (a glass; a heart on message cards). A special WITHOUT a price is a message card: label "From us", signed "— <company full name>" (BK: "Thank you our esteemed customers"). Drink of the day keeps its filled label. A single card is taller.
2) ONE FILE PER CLIENT: site/config.js now holds brand { short, full, title, motto, footer, share, geez, celebrate }. index.html and admin.html read every company wording from it (tab title, logo text, footer, share, staff page title, message-card signature); geez:false hides the Eritrean date; celebrate chooses the sets (eritrea, general, islam, uganda) for the decorations and for the staff list "See the celebrations". New file NEW-CLIENT.md (project zip only): the whole new-client checklist. Tested with a pretend client "Sunset Lounge & Grill" (general celebrations only, no Geez date): every wording changed from config.js alone.

## v5.4 (2026-11-01)
Fix after my screenshot "It's not saving" (Add a drink, Club small size 5000 330ml): the staff message was drawn BEHIND an open sheet (an open sheet sits above everything), so a failed save looked like nothing happened. Now the message shows inside the open sheet, full width, for 4 seconds, and says WHY: "Not saved: run the file bk-menu-v5.1.sql in Supabase once, then try again" when the add, edit or delete step is missing on the server; "Not saved: <the server's words>" for anything else; "No connection. Nothing was saved". An expired login (after about an hour) is renewed once and the save is tried again by itself. Site files only, NO SQL. Version 5.4, cache bk-menu-v5.4, 15 site files.
Most likely cause of my failed save: sql/v5.1.sql not run yet. Check: select proname from pg_proc where proname in ('staff_add_item','staff_edit_item','staff_delete_item'); must give 3 rows.

## v5.3 (2026-11-01)
Specials follow the language switch (my words: "when the special is set it follows the current language automatically ... when the language changes it follows up the switch"). Site files only, NO SQL.
Guest menu: a special's Tigrinya wording (the existing field text_ti) is now its Tigrinya TITLE: ትግርኛ shows it as the big title, English shows the English title and text, Both shows the English title with the Tigrinya under it in gold; a special with no Tigrinya shows the English to everyone.
Staff page: the special sheet says "Title in English", "Short text in English", and "In ትግርኛ (shown when guests choose ትግርኛ)"; a button "Suggest ትግርኛ from the English" fills that box with a MACHINE translation (Google's free translate address, then MyMemory as a second try) for staff to CHECK and correct before saving; with no internet it says so and changes nothing. The same button sits under the Tigrinya description when adding or editing a drink. Version 5.3, cache bk-menu-v5.3. Not tested here: the real translation services (my test machine has no internet).

## v5.2 (2026-11-01)
Celebrations by the Eritrean (Geez) and the Gregorian calendar, plus a new featured carousel. Site files only, NO SQL. New file deco.js (site count now 15 files).
Two levels: SEASON (the days around a celebration) = a drawn garland along the top of the black header; DAY (the exact day, often with its eve) = more decorations, twinkling lights, swaying ornaments, side pieces, and a greeting card first in the carousel (English + Tigrinya + today's date in both calendars).
Celebrations and their art: Lidet 7 Jan and Christmas 25 Dec (pine garland, baubles, lights, stars); New Year 1 Jan (gold confetti, fireworks); Timket = Tir 11 (19 or 20 Jan, Ketera the eve; ceremonial umbrellas); Valentine's 14 Feb (hearts); Fasika (Orthodox Easter, computed) and Easter (Western, computed) (spring flowers); Eritrea Independence 24 May, season from 17 May (bunting green, red, blue, gold, gold olive wreaths); Geez New Year = Meskerem 1 (11 or 12 Sep; Adey Abeba daisies); Meskel = Meskerem 17 (27 Sep; daisies and Demera fires, the eve is the Demera); Uganda Independence 9 Oct (black, yellow, red bunting); Eid al-Fitr and Eid al-Adha (lanterns, crescent, stars; expected dates in a table for 2026 to 2032, they follow the moon, the day level covers the day before and after). NO decoration on remembrance days: Martyrs' Day 20 Jun, Fenkil 10 Feb, 1 Sep.
Today's Eritrean date under "Prices in ...": ጥቅምቲ 22 2019 (Tigrinya), 22 Tiqimti 2019 (English), both in Both mode.
Featured carousel: one carousel for the greeting card (celebration days), Drink of the day, specials and photos: big cards with a label, title, text, price (7,000/=), a faint drawn glass; dots that follow; gentle auto-advance every 5.5 s that stops for good after a touch, never with Reduce motion.
Settings: Celebration decorations On or Off (this phone). Staff page, More: "See the celebrations" opens any one now (the day, or its season) with ?deco=key and &lvl=season; a "Preview" label shows.
Checked: 26 dates against public holiday lists (2026 to 2028), including Pagume 6 in 2027 and New Year on 12 Sep 2027. Tigrinya greetings written by Claude: owner to check.

## v5.1 (2026-11-01)
Staff page made simple, add drinks in the app, prices written 4,000/=.
Staff page: four tabs (Drinks, Specials, Notice, More), one job at a time; a short summary line (sold out, hidden, notice, drink of the day). Drinks: Find a drink, a big "+ Add a drink" button, the list by page; tap a drink for a sheet with a big Price box, switches "Sold out today" and "Hide from menu", Season (only if seasons exist), Save; "More options" holds the name, size, both descriptions and "Delete this drink" (with a warning to use Hide instead for a while). Add a drink: page, section (or a new section), name, price, size, English and Tigrinya descriptions (optional), "Show on the menu now"; it goes at the end of its section. The PIN is asked once, at the first save, and kept until the screen locks (a wrong PIN asks again). Specials, seasons and the PIN open in the same kind of sheet. Typed 7000 is saved as 7,000.
Guest menu: every shilling amount ends with /= (4,000/=), no USh in front; two sizes still stack on two lines; dollars unchanged ($0.92). Version 5.1, cache bk-menu-v5.1.
NEEDS sql/v5.1.sql run ONCE (staff_add_item, staff_edit_item, staff_delete_item, each checks the PIN and writes to Recent changes). Without it the rest works and Add, edit name and delete say "Run v5.1.sql in Supabase first". Check query: select proname from pg_proc where proname in ('staff_add_item','staff_edit_item','staff_delete_item'); gives 3 rows.

## v5.0 (2026-11-01)
One-run remake to the FHG Calm standard. Prices, drinks, descriptions and Tigrinya text are unchanged; the same Supabase tables and functions are used, so NO new SQL.
Guest menu: follows the phone's light or dark by default (Settings > Light or dark: Phone, Light, Dark); Manrope font (fonts/ folder, SIL Open Font License, from the FHG app) with the phone's Ethiopic font for Tigrinya; one scrolling menu (all 9 pages) with sticky category chips that light up as you scroll and jump on tap (#p1 to #p9 links still work); each drink row stacks name, size, English and Tigrinya lines, price on the right (two sizes on two lines); tap a drink for a details sheet with the price in USh and a dollar guide; Sold out badge; banner and specials as calm cards (Drink of the day first); search with "Showing N of N" and an empty message; language button (Both, English, ትግርኛ); currency pill under the logo; settings as a bottom sheet; toast at the bottom; back to top button; offline line when the phone has no connection; "A newer menu is ready, Refresh" line after an update; clean print of the whole menu.
Offline (borrowed from FHG v505): the menu page is saved as a clean copy under / and /index.html, so it opens in flight mode; prices and code are network first, the saved copy only offline; staff screen never cached.
Staff screen: same login, PIN lock, idle lock and every save as before; Calm look; a sticky bar at the top with the PIN (typed once) and Find an item; the item list folds by page with counts; sold-out items crossed through; messages as a bottom toast.
Held items are also left out on the guest side (as a safety in addition to the database rules). Manifest stays full screen. Cache bk-menu-v5.0. Site zip: 14 files (the 11 as before plus fonts/ with 3 files).

## v4.1 (2026-10-29)
Currency: guests can switch prices between Uganda Shillings and US Dollars (tap the line under the logo, or Settings > Currency). UGX prices now carry the symbol USh (no official UGX symbol exists; USh is the common one). Dollar prices = UGX / rate, 2 decimals, shown as a guide. Rate: fetched live from open.er-api.com when online, remembered on the phone, falls back to 4,350 (checked 2026-10-29) when never fetched. Specials prices convert too. Staff screen still edits prices in plain UGX. Site files only, no new SQL. Cache bk-menu-v4.1. Settings shows Version 4.1.

## v4.0 (2026-10-29)
Leading icons: a small line icon now sits in front of every category chip (cup, tea cup, iced glass, orange slice, shake glass, beer mug, tumbler, bottle, wine glass) and in front of every drink row, in the colour of the accent. A drink with its own photo shows the photo instead of the icon. Icons follow light/dark and accent, and are hidden in print. Site files only, no new SQL (v3.9.sql is still the latest). Cache bk-menu-v4.0. Settings shows Version 4.0.

## v3.9 (2026-10-29)
Hotel-style menu organisation. 9 pages: Coffee, Tea, Iced, Juices, Shakes & Smoothies, Beer & Soft, Whisky, Spirits, Wine & Bubbly. Hot tea moved to its own page; Whisky split by style; Liqueurs and Areqi moved to Spirits; sizes and ages sit beside the name (Ballantine's 750ml, Chivas Regal 12 Year Old); Johnnie Walker names completed; items sorted logically or by price. Prices, descriptions and Tigrinya text are unchanged. NEW SQL: sql/v3.9.sql (sql/v3.9-undo.sql goes back). Cache bk-menu-v3.9.

## v3.8 (2026-10-29)
Bottom toolbar (Search, Language, Share, Print, Settings) replaces the top row; search opens a box above the bar. Calmer look: woven band and ornaments removed, plain hairlines, outlined category chip, no auto-sliding specials/photos, smaller logo header. No new SQL. Cache bk-menu-v3.8.

## v3.7 (2026-10-29)
Menu follows the phone light/dark setting (Settings > Light or dark has a new System choice, now the default; Dark and Light still override). Cover photo removed (cover.jpg deleted, site is now 11 files); the BK logo is the header at the top. Staff login and PIN lock screens are a centred card with stacked fields; the staff screen follows the same theme and accent. No new SQL. Cache bk-menu-v3.7.

## v3.6 (2026-10-26)
Decoration: gold diamond dividers, woven band, photo carousel, category banner photos, item thumbnails (tap to enlarge). Photos are listed in photos.json and stored in img/. No new SQL. Cache bk-menu-v3.6.

## v3.5 (2026-10-26)
Today tiles, staff list, scheduled specials (Starts/Ends), seasons (items in a season show only while it is on). sql/v3.5.sql (run after v3.1.sql). Cache bk-menu-v3.5. If v3.5.sql is not run the site still works with the old save functions.
Also in this zip: sql/v3.1.sql (verify_pin for the lock screen, rewritten 2026-10-26). v3.1 to v3.4: logout and signed-in bar, same-address Staff view, PIN-only lock screen, customer vs staff detection.
Left for later: push alerts, deleting seasons/specials.

## v3 (2026-10-25)
Specials strip with Drink of the day (auto-slides every 7 s, swipe), Share button, staff Specials editor in admin.html, sql/v3.sql (run after v2.sql). Cache bk-menu-v3.
Left for later: seasons, push alerts, today tiles, staff list screen, scheduled release.

## v2.2 (2026-10-25)
config.js filled with the menu project address and publishable key. Cache bk-menu-v2.2.

## v2.1 (2026-10-25)
Fix: works with new Supabase publishable keys (no Bearer header unless the key is a JWT). Cache bk-menu-v2.1.

## v2 (2026-10-25)
Staff control: admin.html (login, edit price, Sold out, Hold, Action PIN, notice banner, recent changes), sql/v2.sql, config.js.
Set up: 1) Supabase new project. 2) Run sql/v2.sql, reply "done". 3) Authentication > Users: add owner and staff. 4) Run the last commented line of v2.sql with their emails. 5) Put Project URL and anon key in config.js, upload site zip. 6) Open /admin.html, log in, set the PIN once.
Until config.js is filled, the menu runs from menu.json and admin.html says "not set up yet".
Left for v3: today tiles, staff list screen, scheduled release, specials, share, push alerts, QR.

## v1.1 (2026-10-25)
Real BK logo: app icons (192, 512) and splash screen. Cache name bk-menu-v1.1.

## v1 (2026-10-25)
Public bilingual (English / Tigrinya / both) beverage menu, PWA, works offline.
Built features: F01 F02 F03 F04 F06 F07 F08 F70 F50 F55 (9 pages with prev/next and phone Back) F90 F91 (menu.json) F94 (print/PDF) F95 (chips and dots).
Not in v1: QR code (needs the live address), SQL (menu is static until v2), staff features (v2), extras (v3).
Edit prices now: change menu.json, then raise the version in sw.js (cache name) and upload the site zip.
Rebuild data from the old menu: tools/build_menu.py.
Host: Cloudflare Pages, upload the site zip contents. _headers keeps sw.js, index.html and menu.json fresh.

## v9.3 part H1 of 4: host phone and ordering QR (database only, 2026-11-05)
Run sql/v9.3.sql once in Supabase (undo: sql/v9.3-undo.sql). Needs v7.0, v7.5, v7.7, v9.0. No site change: keep the v9.2 site zip. Check: select proname from pg_proc where proname in ('guest_pair','guest_join_key','guest_remove','waiter_new_master','waiter_remove_guest'); gives 5 rows. Full design and the reply words of each function are in BK-menu-project-prompt.md, ITEM 10. Parts H2 (waiter page), H3 (guest page), H4 (tests, video, docs) are not built yet.

## v9.3.1: Hold or Let the ordering QR (database only, 2026-11-05)
Run sql/v9.3.1.sql once after v9.3.sql (undo: sql/v9.3.1-undo.sql). No site change. Check: select proname from pg_proc where proname='guest_set_share'; gives 1 row.

## v9.4 part H2 of 4: waiter page host phone (site files only, 2026-11-05)
Deploy the site zip (20 files). Needs v9.3.sql run (done). Waiter page: Paired badge, New master code, Remove guest. Guest page parts (ordering QR, Hold/Let, scan-to-join, totals) come in H3.
