// node tools/video/render.js [outdir] : draws every frame of the guest guide and makes bk-guest-guide.mp4 with ffmpeg (portrait 1080x1920, captions on screen, no sound needed)
const {chromium}=require(process.env.PW||'/home/claude/.npm-global/lib/node_modules/playwright');const path=require('path'),fs=require('fs'),cp=require('child_process');
const out=process.argv[2]||'/tmp/gvideo';fs.mkdirSync(out+'/f',{recursive:true});
(async()=>{const br=await chromium.launch();const pg=await br.newPage({viewport:{width:540,height:960},deviceScaleFactor:2});
 await pg.goto('file://'+path.join(__dirname,'guest.html'));await pg.evaluate(()=>document.fonts.ready);await pg.waitForTimeout(400);
 const n=await pg.evaluate(()=>Math.round(TOTAL*FPS));console.log('frames',n);
 for(let i=0;i<n;i++){if(fs.existsSync(`${out}/f/${String(i).padStart(5,'0')}.jpg`)&&!process.env.REDO&&i<n-1&&fs.existsSync(`${out}/f/${String(i+1).padStart(5,'0')}.jpg`))continue;await pg.evaluate(t=>render(t),i/15);await pg.screenshot({path:`${out}/f/${String(i).padStart(5,'0')}.jpg`,type:'jpeg',quality:90});if(i%100==0)console.log(i)}
 await br.close();
 cp.execSync(`ffmpeg -y -loglevel error -framerate 15 -i ${out}/f/%05d.jpg -vf "scale=1080:1920,format=yuv420p" -r 30 -c:v libx264 -preset medium -crf 28 -movflags +faststart ${out}/bk-guest-guide.mp4`);console.log('done',out+'/bk-guest-guide.mp4')})();
