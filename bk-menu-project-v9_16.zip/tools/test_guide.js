// node tools/test_guide.js : needs "cd site && python3 -m http.server 8766" running; checks the customer how-to video sheet and hide forever
const {chromium}=require(process.env.PW||'/home/claude/.npm-global/lib/node_modules/playwright');
(async()=>{const br=await chromium.launch();const ctx=await br.newContext({viewport:{width:390,height:800},serviceWorkers:'block'});const pg=await ctx.newPage();const errs=[];pg.on('pageerror',e=>errs.push(e.message));
let r=[];const ok=(c,m)=>{r.push((c?'ok   ':'FAIL ')+m)};
await pg.goto('http://localhost:8766/index.html');await pg.waitForTimeout(2800);
ok(await pg.evaluate(()=>document.getElementById('gdd').open),'first visit opens the guide');
ok(await pg.evaluate(()=>document.getElementById('hv').getAttribute('src')==='bk-guest-guide.mp4'),'video source set');
await pg.click('#gdd [data-x=gdd]');ok(!await pg.evaluate(()=>document.getElementById('gdd').open),'Close works');
await pg.reload();await pg.waitForTimeout(2800);ok(!await pg.evaluate(()=>document.getElementById('gdd').open),'same session: not shown again after Close');
await pg.evaluate(()=>sessionStorage.clear());await pg.reload();await pg.waitForTimeout(2800);
ok(await pg.evaluate(()=>document.getElementById('gdd').open),'new session: shown again');
await pg.click('#hn');ok(await pg.evaluate(()=>localStorage.getItem('hg')==='1'),'Never show saves hide forever');
await pg.evaluate(()=>sessionStorage.clear());await pg.reload();await pg.waitForTimeout(2800);ok(!await pg.evaluate(()=>document.getElementById('gdd').open),'hidden forever: not shown in a new session');
await pg.click('#st');await pg.click('#hw');ok(await pg.evaluate(()=>document.getElementById('gdd').open),'Settings > Watch opens it anyway');
await pg.click('#gdd [data-x=gdd]');await pg.click('#st');await pg.click('#sg [data-g=on]');ok(await pg.evaluate(()=>!localStorage.getItem('hg')),'Settings brings it back');
await pg.screenshot({path:'/tmp/guide1.png'});
await pg.evaluate(()=>document.getElementById('sd').close());await pg.evaluate(()=>document.getElementById('gdd').showModal());await pg.screenshot({path:'/tmp/guide2.png'});
ok(errs.length==0,'no page errors '+errs.join('|'));console.log(r.join('\n'));await br.close()})();
