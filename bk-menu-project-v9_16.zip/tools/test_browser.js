// (v7.8: the test phone behaves like an Android phone that needs no permission tap (this Chrome build exposes requestPermission, which made the guest page wait for a tap)) node tools/test_browser.js : runs the real site in headless Chrome with a pretend Supabase (no internet needed).
// Checks: shake card + shake celebration (preview and a real day), calm day, add drink/food with detection, admin test sitting.
const {chromium}=require(process.env.PW||'/home/claude/.npm-global/lib/node_modules/playwright');
const http=require('http'),fs=require('fs'),path=require('path');
const SITE=path.join(__dirname,'../site'),OUT=process.env.OUT||'/tmp/shots';fs.mkdirSync(OUT,{recursive:true});
const MIME={'.html':'text/html','.js':'text/javascript','.json':'application/json','.png':'image/png','.woff':'font/woff','.webmanifest':'application/manifest+json'};
const srv=http.createServer((q,r)=>{let u=decodeURIComponent(q.url.split('?')[0]);if(u.endsWith('/'))u+='index.html';const f=path.join(SITE,u);fs.readFile(f,(e,b)=>{if(e){r.writeHead(404);r.end();return}r.writeHead(200,{'Content-Type':MIME[path.extname(f)]||'application/octet-stream'});r.end(b)})});
const menu=JSON.parse(fs.readFileSync(path.join(SITE,'menu.json'),'utf8'));let ID=0,SORT=0;const ITEMS=[];
menu.pages.forEach(p=>p.sections.forEach(s=>s.items.forEach(i=>ITEMS.push({id:++ID,grp:p.g,sec:s.t,sec_ti:s.ti||'',note:s.note||'',name:i.n,variant:i.v||'',d:i.d||'',t:i.t||'',price:i.p||'',sold_out:false,hidden:false,sort:++SORT,season_id:null}))));
const calls=[];let pass=0,fail=0;const ok=(c,m)=>{if(c){pass++;console.log('  ok  ',m)}else{fail++;console.log('  FAIL',m)}};
const b64=o=>Buffer.from(JSON.stringify(o)).toString('base64url');
const JWT='x.'+b64({email:'kayondo30@gmail.com',role:'authenticated'})+'.y';
async function mock(page){await page.route('https://qeudronebisrlcqerwvz.supabase.co/**',async route=>{const u=new URL(route.request().url()),m=route.request().method(),pth=u.pathname;const J=b=>route.fulfill({status:200,contentType:'application/json',headers:{'access-control-allow-origin':'*'},body:JSON.stringify(b)});
  if(m==='OPTIONS')return route.fulfill({status:204,headers:{'access-control-allow-origin':'*','access-control-allow-headers':'*','access-control-allow-methods':'*'}});
  if(pth.endsWith('/menu_items'))return J(ITEMS);if(pth.endsWith('/specials'))return J([]);if(pth.endsWith('/seasons'))return J([]);if(pth.endsWith('/audit_log'))return J([]);if(pth.endsWith('/settings'))return J(u.search.includes('banner')?[]:[{key:'x',value:''}]);
  if(pth.endsWith('/rpc/list_staff'))return J([{email:'kayondo30@gmail.com',role:'admin',pin_set:true,locked:false},{email:'kayondobaker3@gmail.com',role:'admin',pin_set:true,locked:false}]);
  if(pth.endsWith('/rpc/staff_add_item')){const b=JSON.parse(route.request().postData());calls.push(b);ITEMS.push({id:++ID,grp:b.g,sec:b.s,sec_ti:'',note:'',name:b.nm,variant:b.va,d:b.de,t:b.ti,price:b.p,sold_out:false,hidden:b.hid,sort:++SORT,season_id:null});return J('ok')}
  if(pth.endsWith('/rpc/staff_update_item3')){const b=JSON.parse(route.request().postData());calls.push(b);if(b.hid&&!b.why)return J('need_reason');return J('ok')}
  if(pth.endsWith('/item_costs'))return J([]);
  if(pth.endsWith('/margin_rules'))return J([{grp:'*',pct:50}]);
  if(pth.endsWith('/rpc/staff_set_cost')){calls.push(JSON.parse(route.request().postData()));return J('ok')}
  return J([])});
 await page.route(/open\.er-api|translate/,r=>r.abort())}
(async()=>{await new Promise(r=>srv.listen(0,r));const base='http://localhost:'+srv.address().port+'/';
 const br=await chromium.launch();const ctx=await br.newContext({viewport:{width:390,height:844},deviceScaleFactor:2,isMobile:true,hasTouch:true,serviceWorkers:'block'});await ctx.addInitScript(()=>{if(!window.DeviceMotionEvent){window.DeviceMotionEvent=class extends Event{constructor(t,i){super(t);Object.assign(this,i||{})}}}try{Object.defineProperty(DeviceMotionEvent,'requestPermission',{value:undefined,configurable:true})}catch(e){}});
 const errs=[];
 // ---------- 1. preview of Eritrea Independence Day ----------
 console.log('\n1. Guest menu, preview of Independence Day (?deco=indep)');
 let page=await ctx.newPage();page.on('pageerror',e=>errs.push(e.message));await mock(page);
 await page.goto(base+'?deco=indep');await page.waitForSelector('.fs.gr',{timeout:8000});await page.waitForTimeout(600);
 const card=await page.textContent('.fs.gr');
 ok(/Happy Independence Day, Eritrea/.test(card),'card says Happy Independence Day, Eritrea');
 ok(/Shake your phone to celebrate with us/.test(card),'card says "Shake your phone to celebrate with us"');
 ok(await page.$('.fs.gr [data-celb]'),'card has the Tap to celebrate button');
 ok((await page.$$('#fct .fs.gr')).length===1,'exactly one celebration card');
 ok(await page.evaluate(()=>BKS.state().armed),'shake sensor is listening on a celebration day');
 const before=await page.evaluate(()=>document.getElementById('dec').innerHTML.length);
 await page.screenshot({path:OUT+'/01-day-before-shake.png'});
 await page.evaluate(()=>{ // real browser events, three strong movements
  let n=0;const send=(x,y,z)=>window.dispatchEvent(new DeviceMotionEvent('devicemotion',{accelerationIncludingGravity:{x,y,z}}));
  send(0,0,9);for(let i=0;i<4;i++)send(i%2?30:-30,i%2?-30:30,i%2?20:-20)});
 await page.waitForTimeout(500);
 ok(await page.$('#bks-c'),'confetti canvas appeared after the shake');
 const after=await page.evaluate(()=>document.getElementById('dec').innerHTML.length);
 ok(after>before*1.3,'header decoration became fuller after the shake ('+before+' to '+after+' characters)');
 ok(/Thank you for celebrating/.test(await page.textContent('#shkt')),'card text changed after the shake');
 await page.screenshot({path:OUT+'/02-day-after-shake.png'});
 await page.waitForTimeout(3300);ok(!(await page.$('#bks-c')),'confetti removed itself after 3 seconds');
 // tap button path
 await page.reload();await page.waitForSelector('.fs.gr');const b0=await page.evaluate(()=>document.getElementById('dec').innerHTML.length);
 await page.click('[data-celb]');await page.waitForTimeout(400);const b1=await page.evaluate(()=>document.getElementById('dec').innerHTML.length);
 ok(b1>b0*1.3,'Tap to celebrate does the same as a shake');
 // a small movement must NOT trigger
 await page.reload();await page.waitForSelector('.fs.gr');
 await page.evaluate(()=>{const send=(x,y,z)=>window.dispatchEvent(new DeviceMotionEvent('devicemotion',{accelerationIncludingGravity:{x,y,z}}));for(let i=0;i<30;i++)send(0.4*(i%2),0.3*(i%3),9.8)});
 await page.waitForTimeout(300);ok(!(await page.$('#bks-c')),'walking-size movements do not trigger');
 // season preview has no card
 await page.goto(base+'?deco=indep&lvl=season');await page.waitForTimeout(500);ok(!(await page.$('.fs.gr')),'season level: garland only, no shake card');
 await page.close();
 // ---------- 2. a real day (clock set to 9 Oct 2027) ----------
 console.log('\n2. Real day: 9 Oct 2027, no preview, the date decides');
 const ctx2=await br.newContext({viewport:{width:390,height:844},isMobile:true,hasTouch:true,serviceWorkers:'block'});await ctx2.addInitScript(()=>{if(!window.DeviceMotionEvent){window.DeviceMotionEvent=class extends Event{constructor(t,i){super(t);Object.assign(this,i||{})}}}try{Object.defineProperty(DeviceMotionEvent,'requestPermission',{value:undefined,configurable:true})}catch(e){}});page=await ctx2.newPage();page.on('pageerror',e=>errs.push(e.message));await page.clock.setFixedTime(new Date('2027-10-09T10:00:00'));await mock(page);
 await page.goto(base);await page.waitForSelector('.fs.gr',{timeout:8000});
 ok(/Independence Day, Uganda/.test(await page.textContent('.fs.gr')),'the card appears by itself on the day');
 await page.evaluate(()=>BKS.fake(3));await page.waitForTimeout(400);
 ok(await page.evaluate(()=>localStorage.getItem('shk')!==null||Object.keys(localStorage).some(k=>/shk/.test(k))),'the celebration is remembered for the day');
 await page.reload();await page.waitForSelector('.fs.gr');await page.waitForTimeout(500);
 ok(/Thank you for celebrating/.test(await page.textContent('#shkt')),'after a reload the same day stays celebrated');
 await page.close();await ctx2.close();
 console.log('\n3. An ordinary day: today (3 Nov 2026)');
 page=await ctx.newPage();page.on('pageerror',e=>errs.push(e.message));await mock(page);await page.goto(base);await page.waitForTimeout(900);
 ok(!(await page.$('.fs.gr')),'no celebration card');ok(!(await page.evaluate(()=>BKS.state().armed)),'sensor not listening');
 const ic=await page.evaluate(()=>document.querySelector('.chip svg')!=null);ok(ic,'menu chips still draw');await page.close();
 // ---------- 4. admin ----------
 console.log('\n4. Staff screen: add a drink or food');
 page=await ctx.newPage();page.on('pageerror',e=>errs.push(e.message));await mock(page);await page.goto(base+'admin.html');await page.waitForSelector('#a');
 await page.evaluate(t=>{T=t;return panel()},JWT);await page.waitForSelector('#add');
 await page.click('#add');await page.waitForSelector('#an');
 await page.fill('#an','Test Latte');await page.waitForTimeout(100);
 ok(await page.inputValue('#ag')==='Coffee'&&await page.inputValue('#as')==='Espresso & Milk Coffees','Test Latte -> Coffee / Espresso & Milk Coffees');
 ok(/Looks like a drink/.test(await page.textContent('#adh')),'hint says it looks like a drink');
 await page.screenshot({path:OUT+'/03-add-latte.png'});
 const chips=await page.$$eval('#aps button',b=>b.map(x=>x.textContent));ok(chips.length>=2,'price suggestions shown for Coffee / Espresso: '+chips.join(' | '));
 await page.click('#aps button');ok((await page.inputValue('#ap')).length>0,'tapping a suggestion fills the price ('+await page.inputValue('#ap')+')');
 await page.fill('#an','The Glenlivet');await page.waitForTimeout(100);const gl=await page.$$eval('#aps button',b=>b.map(x=>x.textContent));ok(gl.length>=1&&/Single Malt|like|item/.test(gl.join(' ')),'Glenlivet gets whisky prices: '+gl.join(' | '));
 await page.screenshot({path:OUT+'/07-price-chips.png'});
 await page.fill('#ac','2000');await page.waitForTimeout(100);const cb=await page.$$eval('#aps button',b=>b.map(x=>x.textContent));ok(/4,000\/=/.test(cb[0]||'')&&/cost/.test(cb[0]||''),'cost chip is FIRST: '+cb[0]);ok(cb.length>=2,'the usual price chips stay behind it ('+cb.length+' chips)');await page.fill('#ac','');await page.waitForTimeout(100);const cn=await page.$$eval('#aps button',b=>b.map(x=>x.textContent));ok(!cn.some(x=>/cost/.test(x)),'no cost typed = no cost chip');
 await page.fill('#an','Test Latte');await page.fill('#ap','');
 await page.fill('#an','Test Burger');ok(await page.inputValue('#ag')==='Food'&&await page.inputValue('#as')==='Burgers & Sandwiches','Test Burger -> new Food page / Burgers & Sandwiches');
 ok(/Looks like food/.test(await page.textContent('#adh'))&&/new page/.test(await page.textContent('#adh')),'hint says food, a new page');
 await page.fill('#an','Passion Mojito');ok(await page.inputValue('#ag')==='Cocktails','Passion Mojito -> Cocktails (new page)');
 await page.click('#ak [data-k=food]');ok(await page.inputValue('#ag')==='Food','tapping Food overrides the guess');
 await page.click('#ak [data-k=drink]');ok(await page.inputValue('#ag')==='Cocktails','tapping Drink gives the drink guess again');
 await page.selectOption('#ag','Whisky');await page.fill('#an','Smirnoff Zero');ok(await page.inputValue('#ag')==='Whisky','a page chosen by hand is not overridden');
 await page.screenshot({path:OUT+'/04-manual-kept.png'});
 // save a food item through the PIN
 await page.fill('#an','');await page.click('#ak [data-k=""]');await page.fill('#an','Chicken Burger');
 ok(await page.inputValue('#ag')==='Food','Chicken Burger -> Food again after tapping Not sure');
 await page.fill('#ap','12000');await page.uncheck('#ash').catch(()=>{});
 await page.click('#asv');await page.waitForSelector('#pdi');await page.fill('#pdi','1234');await page.click('#pdok');await page.waitForTimeout(800);
 ok(calls.length===1&&calls[0].g==='Food'&&calls[0].s==='Burgers & Sandwiches'&&calls[0].nm==='Chicken Burger'&&calls[0].p==='12,000','saved to Food / Burgers & Sandwiches at 12,000 (sent: '+JSON.stringify({g:calls[0]&&calls[0].g,s:calls[0]&&calls[0].s,p:calls[0]&&calls[0].p})+')');
 ok((await page.textContent('#tv')).includes('Chicken Burger'),'the new item shows in the staff list');
 // second item goes into the Food page that now exists
 await page.click('#add');await page.fill('#an','Beef Samosa');await page.waitForTimeout(100);
 ok(await page.inputValue('#ag')==='Food'&&await page.inputValue('#as')==='Snacks & Bites','Beef Samosa -> existing Food page, Snacks & Bites');
 await page.keyboard.press('Escape');
 // ---------- 4b. hiding needs a reason ----------
 console.log('\n4b. Hide needs a reason');
 await page.click('.tabs [data-t=d]').catch(()=>{});await page.evaluate(()=>editSheet(D.it[0].id));await page.waitForSelector('#eh');
 ok(await page.$eval('#rw',e=>e.hidden),'reason box is hidden until Hide is switched on');
 ok(await page.inputValue('#en')===(await page.evaluate(()=>D.it[0].name)),'Name box is at the top and filled');
 await page.evaluate(()=>{const e=document.getElementById('eh');e.checked=true;e.dispatchEvent(new Event('change'))});
 ok(!(await page.$eval('#rw',e=>e.hidden))&&/required/.test(await page.textContent('#rl')),'reason box appears and says required');
 const n0=calls.length;await page.click('#esv');await page.waitForTimeout(300);
 ok(calls.length===n0,'saving without a reason sends nothing');
 await page.fill('#er','Out of stock until Friday');await page.click('#esv');await page.waitForTimeout(900);
 const hc=calls[calls.length-1];ok(calls.length===n0+1&&hc.hid===true&&hc.why==='Out of stock until Friday','the reason is sent with the hide ('+JSON.stringify(hc&&hc.why)+')');
 // ---------- 4c. how-to video in the staff screen ----------
 console.log('\n4c. How-to video');
 await page.keyboard.press('Escape').catch(()=>{});await page.click('.tabs [data-t=m]');await page.waitForSelector('#vid');await page.click('#vid');await page.waitForSelector('#hv');
 ok(/bk-staff-guide\.mp4$/.test(await page.$eval('#hv',v=>v.getAttribute('src'))),'More > Watch the how-to video opens the video');
 const vs=await page.evaluate(()=>fetch('bk-staff-guide.mp4').then(async r=>r.status+' '+(await r.arrayBuffer()).byteLength));ok(/^200 \d{6,}/.test(vs),'the video file is in the site ('+vs+' bytes)');
 await page.keyboard.press('Escape');await page.waitForTimeout(200);ok(!(await page.$('#hv')),'closing the sheet removes the video (it stops playing)');
 // ---------- 5. admin test sitting ----------
 console.log('\n5. Admin test sitting');
 await page.click('.tabs [data-t=m]');await page.waitForSelector('#atb');await page.click('#atb');await page.waitForSelector('#atcp',{timeout:8000});
 const rows=await page.$$eval('#shc .row',r=>r.map(x=>x.textContent.trim().replace(/\s+/g,' ')));
 console.log('     '+rows.length+' automatic checks:');rows.forEach(x=>console.log('       '+x));
 ok(rows.length>=18,'at least 18 automatic checks ran');ok(!rows.some(x=>x.startsWith('✕')),'no automatic check failed');
 ok(rows.some(x=>/Shake detection works/.test(x)),'shake detection check passes');ok(rows.some(x=>/detection works/.test(x)),'drink or food detection check passes');
 ok((await page.$$('#shc input[data-t]')).length===33,'33 checklist items');
 await page.click('#shc input[data-t=login]');await page.click('#shc input[data-t=price]');ok(/Checklist 2 of 33/.test(await page.textContent('#shc .nt')),'ticking updates the count');
 await page.click('#atsb');await page.waitForTimeout(300);ok(/Listening/.test(await page.textContent('#atsk')),'shake test starts listening');
 await page.evaluate(()=>BKS.fake(3));await page.waitForTimeout(300);ok(/Shake detected/.test(await page.textContent('#atsk')),'shake test says Shake detected');
 await page.screenshot({path:OUT+'/05-admin-test.png',fullPage:false});
 await page.evaluate(()=>{const d=document.getElementById('sh');d.scrollTop=700});await page.screenshot({path:OUT+'/06-admin-test-lower.png'});
 const rep=await page.evaluate(()=>BKT.report([{ok:'pass',t:'x',d:''}],{login:true}));ok(/Checklist 1 of 33/.test(rep),'the copied report is complete');
console.log('\n6. Price check (v6.4)');
 page=await ctx.newPage();page.on('pageerror',e=>errs.push(e.message));await mock(page);await page.goto(base+'admin.html');await page.waitForSelector('#a');
 await page.evaluate(t=>{T=t;return panel()},JWT);await page.waitForSelector('#add');
 const ids=await page.evaluate(()=>D.it.filter(x=>/^[\d,]+$/.test(String(x.price).trim())).slice(0,2).map(x=>({id:x.id,p:parseInt(String(x.price).replace(/,/g,''),10)})));
 await page.evaluate(a=>{D.co={};D.co[a[0].id]=Math.round(a[0].p*0.8);D.co[a[1].id]=Math.round(a[1].p*0.2)},ids);
 await page.evaluate(()=>{document.querySelector('[data-t=more],#tmore')&&0;more()});
 ok(await page.$('#pck'),'More has the Price check card');
 await page.click('#pck');await page.waitForSelector('[data-pc]');
 const prow=await page.$$eval('[data-pc]',b=>b.map(x=>x.textContent));ok(prow.length===1,'only the drink below the margin is listed ('+prow.length+')');
 ok(/target 50%/.test(prow[0])&&/profit 20%/.test(prow[0]),'row shows profit and target: '+prow[0]);
 ok(/no cost yet/.test(await page.textContent('#shc')),'the sheet says how many items have no cost');
 await page.screenshot({path:OUT+'/08-price-check.png'});
 await page.click('[data-pc]');await page.waitForSelector('#ep');
 ok(/cost/.test(await page.textContent('#ecs')),'tapping a row opens the drink with the suggested price chip');
 await page.close();
 console.log('\npage errors:',errs.length?errs:'none');ok(!errs.length,'no page errors');
 await br.close();srv.close();console.log(`\n${pass} passed, ${fail} failed`);process.exit(fail?1:0)})().catch(e=>{console.error(e);process.exit(1)});
