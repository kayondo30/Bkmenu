-- Undo BK menu v9.13: removes the function (the from_sitting column is kept, harmless).
drop function if exists guest_send_togo(uuid,jsonb);
