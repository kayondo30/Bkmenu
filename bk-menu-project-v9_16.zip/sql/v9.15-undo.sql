-- Undo BK menu v9.15: puts back the v9.14 database (functions of v9.3, v9.3.1, v9.12.1, v9.13 and v7.0).
-- Run once in Supabase > SQL Editor. Orders that were still waiting for a host, or were declined, never reached a waiter;
-- they are deleted so the old order steps fit again. Link guests stay as ordinary guests of their table.
-- Check: select count(*) from pg_proc where proname in ('guest_link','guest_host_decide');  -> 0
drop function if exists guest_link(uuid);
drop function if exists guest_host_decide(uuid,int,bool);
drop function if exists guest_pair(text,text);
drop function if exists guest_join_key(text,text);

create or replace function guest_pair(cd text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare s sittings%rowtype; g sitting_guests%rowtype; k int; c text := regexp_replace(coalesce(cd,''),'\D','','g');
begin
 delete from join_tries where at<now()-interval '10 minutes';
 select count(*) into k from join_tries where at>now()-interval '1 minute';
 if k>=30 then return jsonb_build_object('r','slow_down'); end if;
 select * into s from sittings where code=c and status='open';
 if not found then insert into join_tries default values; return jsonb_build_object('r','bad_code'); end if;
 if exists(select 1 from sitting_guests where sitting_id=s.id and is_master and not removed) then
  insert into join_tries default values; return jsonb_build_object('r','code_used');
 end if;
 select coalesce(max(num),0)+1 into k from sitting_guests where sitting_id=s.id;
 insert into sitting_guests(sitting_id,num,is_master) values(s.id,k,true) returning * into g;
 return jsonb_build_object('r','ok','gtoken',g.token,'num',g.num,'table',s.table_label,'kind',s.kind,'master',true,'join_key',s.join_key);
exception when unique_violation then
 return jsonb_build_object('r','code_used');
end $$;

create or replace function guest_join_key(jk text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare s sittings%rowtype; g sitting_guests%rowtype; k int; n int; j text := lower(regexp_replace(coalesce(jk,''),'[^0-9a-fA-F]','','g'));
begin
 delete from join_tries where at<now()-interval '10 minutes';
 select count(*) into k from join_tries where at>now()-interval '1 minute';
 if k>=30 then return jsonb_build_object('r','slow_down'); end if;
 select * into s from sittings where join_key=j and status='open'
   and exists(select 1 from sitting_guests m where m.sitting_id=sittings.id and m.is_master and not m.removed);
 if not found then insert into join_tries default values; return jsonb_build_object('r','bad_key'); end if;
 select count(*) into k from sitting_guests where sitting_id=s.id and not removed;
 select coalesce(max(num),0) into n from sitting_guests where sitting_id=s.id;
 if k>=5 or n>=99 then return jsonb_build_object('r','full'); end if;
 insert into sitting_guests(sitting_id,num) values(s.id,n+1) returning * into g;
 return jsonb_build_object('r','ok','gtoken',g.token,'num',g.num,'table',s.table_label,'kind',s.kind,'master',false);
exception when unique_violation then
 return jsonb_build_object('r','slow_down');
end $$;

create or replace function guest_join(cd text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare s sittings%rowtype; g sitting_guests%rowtype; k int; n int; c text := regexp_replace(coalesce(cd,''),'\D','','g');
begin
 delete from join_tries where at<now()-interval '10 minutes';
 select count(*) into k from join_tries where at>now()-interval '1 minute';
 if k>=30 then return jsonb_build_object('r','slow_down'); end if;
 select * into s from sittings where code=c and status='open';
 if not found then insert into join_tries default values; return jsonb_build_object('r','bad_code'); end if;
 if exists(select 1 from sitting_guests where sitting_id=s.id and is_master and not removed) then
  insert into join_tries default values; return jsonb_build_object('r','code_used');
 end if;
 select count(*) into k from sitting_guests where sitting_id=s.id and not removed;
 select coalesce(max(num),0) into n from sitting_guests where sitting_id=s.id;
 if k>=5 or n>=99 then return jsonb_build_object('r','full'); end if;
 insert into sitting_guests(sitting_id,num) values(s.id,n+1) returning * into g;
 return jsonb_build_object('r','ok','gtoken',g.token,'num',g.num,'table',s.table_label,'kind',s.kind);
exception when unique_violation then
 return jsonb_build_object('r','slow_down');
end $$;

create or replace function guest_remove(gt uuid, gnum int)
returns text language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype; n int;
begin
 if g_of(gt) is null then return 'not_connected'; end if;
 select * into g from sitting_guests where token=gt;
 if not g.is_master then return 'not_master'; end if;
 if gnum=g.num then return 'self'; end if;
 update sitting_guests set removed=true where sitting_id=g.sitting_id and num=gnum and not removed and not is_master;
 get diagnostics n=row_count;
 return case when n=1 then 'ok' else 'not_found' end;
end $$;

create or replace function waiter_remove_guest(tok uuid, sid int, gnum int)
returns text language plpgsql security definer set search_path=public as $$
declare w int; g sitting_guests%rowtype;
begin
 w:=w_of(tok); if w is null then return 'no_login'; end if;
 if not exists(select 1 from sittings where id=sid and waiter_id=w and status='open') then return 'not_found'; end if;
 select * into g from sitting_guests where sitting_id=sid and num=gnum and not removed;
 if not found then return 'not_found'; end if;
 if g.is_master then return 'is_master'; end if;
 update sitting_guests set removed=true where id=g.id;
 return 'ok';
end $$;

create or replace function guest_set_share(gt uuid, v bool)
returns text language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype;
begin
 if g_of(gt) is null then return 'not_connected'; end if;
 select * into g from sitting_guests where token=gt;
 if not g.is_master then return 'not_master'; end if;
 if coalesce(v,false) then
  update sittings set share_qr=true where id=g.sitting_id;
 else
  update sittings set share_qr=false, join_key=substr(replace(gen_random_uuid()::text,'-',''),1,12) where id=g.sitting_id;
 end if;
 return 'ok';
end $$;

create or replace function waiter_new_master(tok uuid, sid int)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; c text; k int := 0;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 if not exists(select 1 from sittings where id=sid and waiter_id=w and status='open') then return jsonb_build_object('r','not_found'); end if;
 update sitting_guests set removed=true where sitting_id=sid and is_master and not removed;
 loop
  c:=lpad((floor(random()*10000))::int::text,4,'0');
  begin
   update sittings set code=c, share_qr=false, join_key=substr(replace(gen_random_uuid()::text,'-',''),1,12) where id=sid;
   return jsonb_build_object('r','ok','code',c);
  exception when unique_violation then
   k:=k+1; if k>25 then return jsonb_build_object('r','try_again'); end if;
  end;
 end loop;
end $$;

create or replace function guest_send_order(gt uuid, lines jsonb)
returns text language plpgsql security definer set search_path=public as $$
declare g int; sid int; x jsonb; it int; q int; tg boolean; pr int; nm text; new_id int; cnt int;
begin
 g:=g_of(gt); if g is null then return 'not_connected'; end if;
 if lines is null or jsonb_typeof(lines)<>'array' or jsonb_array_length(lines)=0 then return 'empty'; end if;
 if jsonb_array_length(lines)>30 then return 'bad_line'; end if;
 select count(*) into cnt from orders where guest_id=g; if cnt>=20 then return 'too_many'; end if;
 select sitting_id into sid from sitting_guests where id=g;
 insert into orders(sitting_id,guest_id) values(sid,g) returning id into new_id;
 begin
  for x in select * from jsonb_array_elements(lines) loop
   it:=(x->>'item_id')::int; q:=(x->>'qty')::int; pr:=(x->>'price')::int;
   if x ? 'togo' then if jsonb_typeof(x->'togo')<>'boolean' then raise exception 'bad'; end if; tg:=(x->>'togo')::boolean; else tg:=false; end if;
   if q is null or q<1 or q>20 or pr is null or pr<=0 then raise exception 'bad'; end if;
   select m.name||case when coalesce(m.variant,'')<>'' then ' ('||m.variant||')' else '' end into nm
    from menu_items m
    where m.id=it and not coalesce(m.hidden,false) and not coalesce(m.sold_out,false)
      and exists(select 1 from regexp_matches(replace(coalesce(m.price,''),',',''),'\d+','g') r where r[1]::int=pr);
   if nm is null then raise exception 'bad'; end if;
   insert into order_lines(order_id,item_id,name,price,qty,togo) values(new_id,it,nm,pr,q,tg);
  end loop;
 exception when others then
  delete from orders where id=new_id;
  return 'bad_line';
 end;
 return 'ok';
end $$;

create or replace function guest_status(gt uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype; s sittings%rowtype;
begin
 select * into g from sitting_guests where token=gt;
 if not found then return jsonb_build_object('connected',false); end if;
 if g.removed then return jsonb_build_object('connected',false,'removed',true); end if;
 select * into s from sittings where id=g.sitting_id;
 return jsonb_build_object('connected',s.status='open','closed',s.status='closed','num',g.num,'table',s.table_label,'kind',s.kind,'pay',g.pay,
  'master',g.is_master,'share',s.share_qr,
  'join_key',case when (g.is_master or s.share_qr) and s.status='open' then s.join_key end,
  'guests',case when g.is_master then (select coalesce(jsonb_agg(jsonb_build_object('num',x.num) order by x.num),'[]'::jsonb)
      from sitting_guests x where x.sitting_id=s.id and not x.removed and x.id<>g.id) end,
  'total',(select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.guest_id=g.id),
  'orders',(select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'lines',
      (select coalesce(jsonb_agg(jsonb_build_object('id',l.id,'name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote,'togo',l.togo) order by l.id),'[]'::jsonb)
       from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb) from orders o where o.guest_id=g.id));
end $$;

create or replace function waiter_tables(tok uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; r jsonb;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 select coalesce(jsonb_agg(to_jsonb(t) order by t.opened_at),'[]'::jsonb) into r from (
  select s.id, s.table_label, s.kind, s.code, s.opened_at,
   exists(select 1 from sitting_guests m where m.sitting_id=s.id and m.is_master and not m.removed) as paired,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('num',g.num,'pay',g.pay,'master',g.is_master,'removed',g.removed,'orders',
      (select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'at',o.created_at,'lines',
         (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote,'togo',l.togo) order by l.id),'[]'::jsonb)
          from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb)
       from orders o where o.guest_id=g.id)) order by g.num),'[]'::jsonb)
    from sitting_guests g where g.sitting_id=s.id) as guests
  from sittings s where s.waiter_id=w and s.status='open') t;
 return jsonb_build_object('r','ok','tables',r);
end $$;

create or replace function admin_closed_tables(n int default 50)
returns jsonb language plpgsql security definer set search_path=public as $$
begin
 if not is_staff() then return '[]'::jsonb; end if;
 return (select coalesce(jsonb_agg(to_jsonb(t) order by t.closed_at desc),'[]'::jsonb) from (
  select s.id, s.table_label, s.kind, s.waiter_name, s.opened_at, s.closed_at,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote,'togo',l.togo) order by l.id),'[]'::jsonb)
      from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as lines
  from sittings s where s.status='closed' order by s.closed_at desc limit least(coalesce(n,50),200)) t);
end $$;

create or replace function guest_send_togo(gt uuid, lines jsonb)
returns jsonb language plpgsql security definer set search_path=public as $$
declare g int; s sittings%rowtype; x jsonb; it int; q int; pr int; nm text; c text; sid int; gid int; oid int; k int:=0; cnt int;
begin
 g:=g_of(gt); if g is null then return jsonb_build_object('r','not_connected'); end if;
 if lines is null or jsonb_typeof(lines)<>'array' or jsonb_array_length(lines)=0 then return jsonb_build_object('r','empty'); end if;
 if jsonb_array_length(lines)>30 then return jsonb_build_object('r','bad_line'); end if;
 select t.* into s from sittings t join sitting_guests m on m.sitting_id=t.id where m.id=g;
 if s.status<>'open' then return jsonb_build_object('r','not_connected'); end if;
 select count(*) into cnt from sittings where from_sitting=s.id and status='open'; if cnt>=10 then return jsonb_build_object('r','too_many'); end if;
 begin
  loop
   c:=lpad((floor(random()*10000))::int::text,4,'0');
   begin
    insert into sittings(waiter_id,waiter_name,table_label,code,kind,from_sitting)
     values(s.waiter_id,s.waiter_name,'Take away '||c,c,'takeaway',s.id) returning id into sid;
    exit;
   exception when unique_violation then
    k:=k+1; if k>25 then return jsonb_build_object('r','try_again'); end if;
   end;
  end loop;
  insert into sitting_guests(sitting_id,num,is_master) values(sid,1,true) returning id into gid;
  insert into orders(sitting_id,guest_id) values(sid,gid) returning id into oid;
  for x in select * from jsonb_array_elements(lines) loop
   it:=(x->>'item_id')::int; q:=(x->>'qty')::int; pr:=(x->>'price')::int;
   if q is null or q<1 or q>20 or pr is null or pr<=0 then raise exception 'bad'; end if;
   nm:=null;
   select m.name||case when coalesce(m.variant,'')<>'' then ' ('||m.variant||')' else '' end into nm
    from menu_items m
    where m.id=it and not coalesce(m.hidden,false) and not coalesce(m.sold_out,false)
      and exists(select 1 from regexp_matches(replace(coalesce(m.price,''),',',''),'\d+','g') r where r[1]::int=pr);
   if nm is null then raise exception 'bad'; end if;
   insert into order_lines(order_id,item_id,name,price,qty,togo) values(oid,it,nm,pr,q,true);
  end loop;
 exception when others then
  if sid is not null then delete from sittings where id=sid; end if;
  return jsonb_build_object('r','bad_line');
 end;
 return jsonb_build_object('r','ok','code',c);
end $$;

create or replace function waiter_order_step(tok uuid, ord_id int, st text)
returns text language plpgsql security definer set search_path=public as $$
declare w int; n int;
begin
 w:=w_of(tok); if w is null then return 'no_login'; end if;
 if st not in ('received','preparing','on_the_way','served') then return 'bad_step'; end if;
 update orders o set status=st, updated_at=now()
  from sittings s where o.id=ord_id and s.id=o.sitting_id and s.waiter_id=w and s.status='open';
 get diagnostics n=row_count;
 if n=0 then return 'not_found'; end if;
 return 'ok';
end $$;


delete from orders where status in ('awaiting_host','declined');
alter table orders drop constraint if exists orders_status_check;
alter table orders add constraint orders_status_check check (status in ('sent','received','preparing','on_the_way','served'));
alter table orders drop column if exists pickup;
alter table sitting_guests drop column if exists via;
alter table sitting_guests drop column if exists remote;
drop table if exists join_keys;
drop function if exists join_slow(text);
drop function if exists join_fail(text);
drop function if exists join_ip();
drop function if exists join_dev(text);
drop function if exists new_key();
alter table join_tries drop column if exists dev;
alter table join_tries drop column if exists ip;
alter function is_staff() reset search_path;

revoke all on function guest_pair(text), guest_join_key(text), guest_join(text), guest_remove(uuid,int), waiter_remove_guest(uuid,int,int),
  guest_set_share(uuid,bool), waiter_new_master(uuid,int), guest_send_order(uuid,jsonb), guest_status(uuid), waiter_tables(uuid),
  admin_closed_tables(int), guest_send_togo(uuid,jsonb), waiter_order_step(uuid,int,text) from public;
grant execute on function guest_pair(text), guest_join_key(text), guest_join(text), guest_remove(uuid,int), waiter_remove_guest(uuid,int,int),
  guest_set_share(uuid,bool), waiter_new_master(uuid,int), guest_send_order(uuid,jsonb), guest_status(uuid), waiter_tables(uuid),
  guest_send_togo(uuid,jsonb), waiter_order_step(uuid,int,text) to anon, authenticated;
grant execute on function admin_closed_tables(int) to authenticated;
notify pgrst, 'reload schema';
