-- BK menu v9.13: a joined guest sends his To go lines as a SEPARATE To go order with its own 4-digit code.
-- Run once in the Supabase SQL editor (after v9.12.1.sql). Undo: v9.13-undo.sql
alter table sittings add column if not exists from_sitting int;

create or replace function guest_send_togo(gt uuid, lines jsonb)
returns jsonb language plpgsql security definer set search_path=public as $$
declare g int; s sittings%rowtype; x jsonb; it int; q int; pr int; nm text; c text; sid int; gid int; oid int; k int:=0; cnt int;
begin
 g:=g_of(gt); if g is null then return jsonb_build_object('r','not_connected'); end if;
 if lines is null or jsonb_typeof(lines)<>'array' or jsonb_array_length(lines)=0 then return jsonb_build_object('r','empty'); end if;
 if jsonb_array_length(lines)>30 then return jsonb_build_object('r','bad_line'); end if;
 select t.* into s from sittings t join sitting_guests m on m.sitting_id=t.id where m.id=g;
 if s.status<>'open' then return jsonb_build_object('r','not_connected'); end if;
 select count(*) into cnt from sittings where from_sitting=s.id and status='open'; if cnt>=10 then return jsonb_build_object('r','too_many'); end if;
 begin
  loop
   c:=lpad((floor(random()*10000))::int::text,4,'0');
   begin
    insert into sittings(waiter_id,waiter_name,table_label,code,kind,from_sitting)
     values(s.waiter_id,s.waiter_name,'Take away '||c,c,'takeaway',s.id) returning id into sid;
    exit;
   exception when unique_violation then
    k:=k+1; if k>25 then return jsonb_build_object('r','try_again'); end if;
   end;
  end loop;
  insert into sitting_guests(sitting_id,num,is_master) values(sid,1,true) returning id into gid;
  insert into orders(sitting_id,guest_id) values(sid,gid) returning id into oid;
  for x in select * from jsonb_array_elements(lines) loop
   it:=(x->>'item_id')::int; q:=(x->>'qty')::int; pr:=(x->>'price')::int;
   if q is null or q<1 or q>20 or pr is null or pr<=0 then raise exception 'bad'; end if;
   nm:=null;
   select m.name||case when coalesce(m.variant,'')<>'' then ' ('||m.variant||')' else '' end into nm
    from menu_items m
    where m.id=it and not coalesce(m.hidden,false) and not coalesce(m.sold_out,false)
      and exists(select 1 from regexp_matches(replace(coalesce(m.price,''),',',''),'\d+','g') r where r[1]::int=pr);
   if nm is null then raise exception 'bad'; end if;
   insert into order_lines(order_id,item_id,name,price,qty,togo) values(oid,it,nm,pr,q,true);
  end loop;
 exception when others then
  if sid is not null then delete from sittings where id=sid; end if;
  return jsonb_build_object('r','bad_line');
 end;
 return jsonb_build_object('r','ok','code',c);
end $$;

revoke all on function guest_send_togo(uuid,jsonb) from public;
grant execute on function guest_send_togo(uuid,jsonb) to anon, authenticated;
