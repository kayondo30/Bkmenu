-- Undo BK menu v9.3.1: puts back the v9.3 guest_status and waiter_new_master, removes guest_set_share and the share_qr column.
drop function if exists guest_set_share(uuid,bool);
create or replace function guest_status(gt uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype; s sittings%rowtype;
begin
 select * into g from sitting_guests where token=gt;
 if not found then return jsonb_build_object('connected',false); end if;
 if g.removed then return jsonb_build_object('connected',false,'removed',true); end if;
 select * into s from sittings where id=g.sitting_id;
 return jsonb_build_object('connected',s.status='open','closed',s.status='closed','num',g.num,'table',s.table_label,'kind',s.kind,'pay',g.pay,
  'master',g.is_master,
  'join_key',case when g.is_master and s.status='open' then s.join_key end,
  'guests',case when g.is_master then (select coalesce(jsonb_agg(jsonb_build_object('num',x.num) order by x.num),'[]'::jsonb)
      from sitting_guests x where x.sitting_id=s.id and not x.removed and x.id<>g.id) end,
  'total',(select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.guest_id=g.id),
  'orders',(select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'lines',
      (select coalesce(jsonb_agg(jsonb_build_object('id',l.id,'name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote) order by l.id),'[]'::jsonb)
       from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb) from orders o where o.guest_id=g.id));
end $$;

create or replace function waiter_new_master(tok uuid, sid int)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; c text; k int := 0;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 if not exists(select 1 from sittings where id=sid and waiter_id=w and status='open') then return jsonb_build_object('r','not_found'); end if;
 update sitting_guests set removed=true where sitting_id=sid and is_master and not removed;
 loop
  c:=lpad((floor(random()*10000))::int::text,4,'0');
  begin
   update sittings set code=c, join_key=substr(replace(gen_random_uuid()::text,'-',''),1,12) where id=sid;
   return jsonb_build_object('r','ok','code',c);
  exception when unique_violation then
   k:=k+1; if k>25 then return jsonb_build_object('r','try_again'); end if;
  end;
 end loop;
end $$;

revoke all on function guest_status(uuid), waiter_new_master(uuid,int) from public;
grant execute on function guest_status(uuid), waiter_new_master(uuid,int) to anon, authenticated;
alter table sittings drop column if exists share_qr;
