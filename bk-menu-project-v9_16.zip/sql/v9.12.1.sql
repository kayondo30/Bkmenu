-- BK menu v9.12.1: To go per order line. Run once in Supabase SQL editor. Undo: v9.12.1-undo.sql
alter table order_lines add column if not exists togo boolean not null default false;

create or replace function guest_send_order(gt uuid, lines jsonb)
returns text language plpgsql security definer set search_path=public as $$
declare g int; sid int; x jsonb; it int; q int; tg boolean; pr int; nm text; new_id int; cnt int;
begin
 g:=g_of(gt); if g is null then return 'not_connected'; end if;
 if lines is null or jsonb_typeof(lines)<>'array' or jsonb_array_length(lines)=0 then return 'empty'; end if;
 if jsonb_array_length(lines)>30 then return 'bad_line'; end if;
 select count(*) into cnt from orders where guest_id=g; if cnt>=20 then return 'too_many'; end if;
 select sitting_id into sid from sitting_guests where id=g;
 insert into orders(sitting_id,guest_id) values(sid,g) returning id into new_id;
 begin
  for x in select * from jsonb_array_elements(lines) loop
   it:=(x->>'item_id')::int; q:=(x->>'qty')::int; pr:=(x->>'price')::int;
   if x ? 'togo' then if jsonb_typeof(x->'togo')<>'boolean' then raise exception 'bad'; end if; tg:=(x->>'togo')::boolean; else tg:=false; end if;
   if q is null or q<1 or q>20 or pr is null or pr<=0 then raise exception 'bad'; end if;
   select m.name||case when coalesce(m.variant,'')<>'' then ' ('||m.variant||')' else '' end into nm
    from menu_items m
    where m.id=it and not coalesce(m.hidden,false) and not coalesce(m.sold_out,false)
      and exists(select 1 from regexp_matches(replace(coalesce(m.price,''),',',''),'\d+','g') r where r[1]::int=pr);
   if nm is null then raise exception 'bad'; end if;
   insert into order_lines(order_id,item_id,name,price,qty,togo) values(new_id,it,nm,pr,q,tg);
  end loop;
 exception when others then
  delete from orders where id=new_id;
  return 'bad_line';
 end;
 return 'ok';
end $$;

create or replace function guest_status(gt uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype; s sittings%rowtype;
begin
 select * into g from sitting_guests where token=gt;
 if not found then return jsonb_build_object('connected',false); end if;
 if g.removed then return jsonb_build_object('connected',false,'removed',true); end if;
 select * into s from sittings where id=g.sitting_id;
 return jsonb_build_object('connected',s.status='open','closed',s.status='closed','num',g.num,'table',s.table_label,'kind',s.kind,'pay',g.pay,
  'master',g.is_master,'share',s.share_qr,
  'join_key',case when (g.is_master or s.share_qr) and s.status='open' then s.join_key end,
  'guests',case when g.is_master then (select coalesce(jsonb_agg(jsonb_build_object('num',x.num) order by x.num),'[]'::jsonb)
      from sitting_guests x where x.sitting_id=s.id and not x.removed and x.id<>g.id) end,
  'total',(select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.guest_id=g.id),
  'orders',(select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'lines',
      (select coalesce(jsonb_agg(jsonb_build_object('id',l.id,'name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote,'togo',l.togo) order by l.id),'[]'::jsonb)
       from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb) from orders o where o.guest_id=g.id));
end $$;

create or replace function waiter_tables(tok uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; r jsonb;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 select coalesce(jsonb_agg(to_jsonb(t) order by t.opened_at),'[]'::jsonb) into r from (
  select s.id, s.table_label, s.kind, s.code, s.opened_at,
   exists(select 1 from sitting_guests m where m.sitting_id=s.id and m.is_master and not m.removed) as paired,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('num',g.num,'pay',g.pay,'master',g.is_master,'removed',g.removed,'orders',
      (select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'at',o.created_at,'lines',
         (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote,'togo',l.togo) order by l.id),'[]'::jsonb)
          from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb)
       from orders o where o.guest_id=g.id)) order by g.num),'[]'::jsonb)
    from sitting_guests g where g.sitting_id=s.id) as guests
  from sittings s where s.waiter_id=w and s.status='open') t;
 return jsonb_build_object('r','ok','tables',r);
end $$;

create or replace function admin_closed_tables(n int default 50)
returns jsonb language plpgsql security definer set search_path=public as $$
begin
 if not is_staff() then return '[]'::jsonb; end if;
 return (select coalesce(jsonb_agg(to_jsonb(t) order by t.closed_at desc),'[]'::jsonb) from (
  select s.id, s.table_label, s.kind, s.waiter_name, s.opened_at, s.closed_at,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote,'togo',l.togo) order by l.id),'[]'::jsonb)
      from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as lines
  from sittings s where s.status='closed' order by s.closed_at desc limit least(coalesce(n,50),200)) t);
end $$;

revoke all on function guest_send_order(uuid,jsonb), guest_status(uuid), waiter_tables(uuid), admin_closed_tables(int) from public;
grant execute on function guest_send_order(uuid,jsonb), guest_status(uuid), waiter_tables(uuid) to anon, authenticated;
grant execute on function admin_closed_tables(int) to authenticated;
