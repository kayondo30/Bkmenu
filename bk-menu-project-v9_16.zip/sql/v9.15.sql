-- BK menu v9.15: JOINING AND SECURITY. Run once in Supabase > SQL Editor (new query tab), AFTER v9.13.sql. Safe to run again.
-- Undo = sql/v9.15-undo.sql.  "Success. No rows returned" is normal.
-- Check:  select (select count(*) from pg_proc where proname in ('guest_link','guest_host_decide','join_slow','join_fail')) as v9_15,
--                (select count(*) from information_schema.tables where table_name='join_keys') as keys_table;   -> 4 and 1
--
-- WHAT CHANGES (owner rules L13, L14, L16, and the is_staff() fix)
-- 1. ONE SCAN = ONE PHONE. Every QR on a phone carries its own key that works ONCE, then that phone shows a new one by itself.
--    Each joined phone at the table shows its own QR (host always; the others while the host has Let on).
-- 2. SENT LINK = TO GO GUEST. "Send the link" makes a different, one-time key. Whoever joins through it is NOT at the table:
--    no seat (the 5 seats are for phones at the table), everything they order is To go, and it goes FIRST to the phone that
--    sent the link ("Send to the host"). That phone taps Approve or Decline. Approved: it goes to the waiter as To go with a
--    pickup code, BILLED ON THE TABLE. Declined: nothing reaches the waiter. Waiting or declined orders are in no total.
-- 3. Hold stops every unused QR and link at once. Removing a guest stops the keys that guest made (L14).
-- 4. "Slow down" now counts wrong tries per phone (and per internet address), not for the whole bar (L13).
-- 5. is_staff() gets its fixed search path. The old guest_join(code) door from v9.2, unused since v9.5, is removed.
-- Nothing in your menu, prices or closed tables is changed or deleted.

-- ===== 5. is_staff fix =====
alter function is_staff() set search_path = public;

-- ===== tables =====
alter table join_tries add column if not exists dev text;
alter table join_tries add column if not exists ip text;

create table if not exists join_keys(
  k text primary key,
  sitting_id int not null references sittings(id) on delete cascade,
  made_by int not null references sitting_guests(id) on delete cascade,
  kind text not null check (kind in ('qr','link')),
  made_at timestamptz not null default now(),
  used_at timestamptz);
create index if not exists join_keys_open on join_keys(made_by, kind) where used_at is null;
alter table join_keys enable row level security;      -- no policies: only the functions below can read or write it
revoke all on join_keys from anon, authenticated;

alter table sitting_guests add column if not exists remote bool not null default false;   -- joined by a sent link
alter table sitting_guests add column if not exists via int;                               -- the guest whose link it was
alter table orders add column if not exists pickup text;                                   -- pickup code of an approved link order
alter table orders drop constraint if exists orders_status_check;
alter table orders add constraint orders_status_check
  check (status in ('awaiting_host','declined','sent','received','preparing','on_the_way','served'));

-- ===== brake helpers (not callable from the app) =====
create or replace function join_ip() returns text language plpgsql stable security definer set search_path=public as $$
declare h json; v text;
begin
 begin h:=current_setting('request.headers',true)::json; exception when others then return null; end;
 if h is null then return null; end if;
 v:=coalesce(h->>'cf-connecting-ip', split_part(coalesce(h->>'x-forwarded-for',''),',',1));
 return nullif(left(trim(coalesce(v,'')),60),'');
end $$;

create or replace function join_dev(dv text) returns text language sql immutable set search_path=public as $$
 select nullif(left(regexp_replace(coalesce(dv,''),'[^0-9A-Za-z]','','g'),40),'') $$;

-- true = too many wrong tries: this phone 8 a minute, this internet address 40 a minute, everyone 200 a minute,
-- tries with no phone id and no address (old site) 30 a minute as before
create or replace function join_slow(dv text) returns boolean language plpgsql security definer set search_path=public as $$
declare vd text:=join_dev(dv); vi text:=join_ip(); k int;
begin
 delete from join_tries where at<now()-interval '10 minutes';
 if vd is not null then
  select count(*) into k from join_tries where dev=vd and at>now()-interval '1 minute'; if k>=8 then return true; end if;
 end if;
 if vi is not null then
  select count(*) into k from join_tries where ip=vi and at>now()-interval '1 minute'; if k>=40 then return true; end if;
 end if;
 if vd is null and vi is null then
  select count(*) into k from join_tries where dev is null and ip is null and at>now()-interval '1 minute'; if k>=30 then return true; end if;
 end if;
 select count(*) into k from join_tries where at>now()-interval '1 minute'; if k>=200 then return true; end if;
 return false;
end $$;

create or replace function join_fail(dv text) returns void language sql security definer set search_path=public as $$
 insert into join_tries(at,dev,ip) values(now(), join_dev(dv), join_ip()) $$;

create or replace function new_key() returns text language sql volatile set search_path=public as $$
 select substr(replace(gen_random_uuid()::text,'-',''),1,12) $$;

revoke all on function join_ip(), join_dev(text), join_slow(text), join_fail(text), new_key() from public, anon, authenticated;

-- ===== GUEST: first phone types the waiter's code and becomes the host (dev = the phone's own id) =====
-- Replies {"r":"ok",..,"master":true} | bad_code | code_used | slow_down
drop function if exists guest_pair(text);
create or replace function guest_pair(cd text, dev text default null)
returns jsonb language plpgsql security definer set search_path=public as $$
declare s sittings%rowtype; g sitting_guests%rowtype; k int; c text := regexp_replace(coalesce(cd,''),'\D','','g');
begin
 if join_slow(dev) then return jsonb_build_object('r','slow_down'); end if;
 select * into s from sittings where code=c and status='open';
 if not found then perform join_fail(dev); return jsonb_build_object('r','bad_code'); end if;
 if exists(select 1 from sitting_guests where sitting_id=s.id and is_master and not removed) then
  perform join_fail(dev); return jsonb_build_object('r','code_used');
 end if;
 select coalesce(max(num),0)+1 into k from sitting_guests where sitting_id=s.id;
 insert into sitting_guests(sitting_id,num,is_master) values(s.id,k,true) returning * into g;
 return jsonb_build_object('r','ok','gtoken',g.token,'num',g.num,'table',s.table_label,'kind',s.kind,'master',true);
exception when unique_violation then
 return jsonb_build_object('r','code_used');
end $$;

-- ===== GUEST: join with a QR or a sent link. Each key works ONCE. =====
-- Replies {"r":"ok",..,"remote":false|true} | bad_key | full (5 phones at the table) | full_link (5 link guests) | slow_down
drop function if exists guest_join_key(text);
create or replace function guest_join_key(jk text, dev text default null)
returns jsonb language plpgsql security definer set search_path=public as $$
declare kk join_keys%rowtype; s sittings%rowtype; g sitting_guests%rowtype; cnt int; n int;
        j text := lower(regexp_replace(coalesce(jk,''),'[^0-9a-fA-F]','','g'));
begin
 if join_slow(dev) then return jsonb_build_object('r','slow_down'); end if;
 select * into kk from join_keys jk2 where jk2.k=j and jk2.used_at is null for update;
 if not found then perform join_fail(dev); return jsonb_build_object('r','bad_key'); end if;
 select * into s from sittings where id=kk.sitting_id and status='open'
   and exists(select 1 from sitting_guests m where m.sitting_id=sittings.id and m.is_master and not m.removed);
 if not found then perform join_fail(dev); return jsonb_build_object('r','bad_key'); end if;
 if not exists(select 1 from sitting_guests v where v.id=kk.made_by and not v.removed) then
  perform join_fail(dev); return jsonb_build_object('r','bad_key');
 end if;
 select coalesce(max(num),0) into n from sitting_guests where sitting_id=s.id;
 if n>=99 then return jsonb_build_object('r','full'); end if;
 if kk.kind='qr' then
  select count(*) into cnt from sitting_guests where sitting_id=s.id and not removed and not remote;
  if cnt>=5 then return jsonb_build_object('r','full'); end if;
  insert into sitting_guests(sitting_id,num) values(s.id,n+1) returning * into g;
 else
  select count(*) into cnt from sitting_guests where sitting_id=s.id and not removed and remote;
  if cnt>=5 then return jsonb_build_object('r','full_link'); end if;
  insert into sitting_guests(sitting_id,num,remote,via) values(s.id,n+1,true,kk.made_by) returning * into g;
 end if;
 update join_keys jk3 set used_at=now() where jk3.k=j;
 return jsonb_build_object('r','ok','gtoken',g.token,'num',g.num,'table',s.table_label,'kind',s.kind,'master',false,'remote',g.remote);
exception when unique_violation then
 return jsonb_build_object('r','slow_down');
end $$;

-- the old v9.2 door (join by code without a host): unused by the site since v9.5
drop function if exists guest_join(text);

-- ===== GUEST: make a one-time link to send. Host always; the others while Let is on; never a link guest. =====
-- Replies {"r":"ok","key":".."} | not_connected | not_allowed | too_many (5 unused links)
create or replace function guest_link(gt uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype; s sittings%rowtype; nk text; n int;
begin
 if g_of(gt) is null then return jsonb_build_object('r','not_connected'); end if;
 select * into g from sitting_guests where token=gt;
 select * into s from sittings where id=g.sitting_id;
 if g.remote or not (g.is_master or s.share_qr) then return jsonb_build_object('r','not_allowed'); end if;
 select count(*) into n from join_keys where made_by=g.id and kind='link' and used_at is null;
 if n>=5 then return jsonb_build_object('r','too_many'); end if;
 nk:=new_key();
 insert into join_keys(k,sitting_id,made_by,kind) values(nk,s.id,g.id,'link');
 return jsonb_build_object('r','ok','key',nk);
end $$;

-- ===== GUEST: the phone that sent the link approves or declines its link guest's order =====
-- (if that phone left the table, the host decides). Replies {"r":"ok","pickup":"1234"} | {"r":"ok"} (declined)
-- | {"r":"done","status":..} (already decided) | not_connected | not_found | not_yours
create or replace function guest_host_decide(gt uuid, ord_id int, ok bool)
returns jsonb language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype; o orders%rowtype; r sitting_guests%rowtype; pc text;
begin
 if g_of(gt) is null then return jsonb_build_object('r','not_connected'); end if;
 select * into g from sitting_guests where token=gt;
 if g.remote then return jsonb_build_object('r','not_yours'); end if;
 select * into o from orders where id=ord_id for update;
 if not found or o.sitting_id<>g.sitting_id then return jsonb_build_object('r','not_found'); end if;
 select * into r from sitting_guests where id=o.guest_id;
 if not r.remote then return jsonb_build_object('r','not_found'); end if;
 if not (r.via=g.id or (g.is_master and not exists(select 1 from sitting_guests v where v.id=r.via and not v.removed))) then
  return jsonb_build_object('r','not_yours');
 end if;
 if o.status<>'awaiting_host' then return jsonb_build_object('r','done','status',o.status); end if;
 if coalesce(ok,false) then
  pc:=lpad((floor(random()*10000))::int::text,4,'0');
  update orders set status='sent', pickup=pc, updated_at=now() where id=o.id;
  return jsonb_build_object('r','ok','pickup',pc);
 end if;
 update orders set status='declined', updated_at=now() where id=o.id;
 return jsonb_build_object('r','ok');
end $$;

-- ===== GUEST: send an order. A link guest's order is all To go and waits for its host. =====
create or replace function guest_send_order(gt uuid, lines jsonb)
returns text language plpgsql security definer set search_path=public as $$
declare g int; sid int; rm bool; x jsonb; it int; q int; tg boolean; pr int; nm text; new_id int; cnt int;
begin
 g:=g_of(gt); if g is null then return 'not_connected'; end if;
 if lines is null or jsonb_typeof(lines)<>'array' or jsonb_array_length(lines)=0 then return 'empty'; end if;
 if jsonb_array_length(lines)>30 then return 'bad_line'; end if;
 select count(*) into cnt from orders where guest_id=g; if cnt>=20 then return 'too_many'; end if;
 select sitting_id, remote into sid, rm from sitting_guests where id=g;
 if rm then
  select count(*) into cnt from orders where guest_id=g and status='awaiting_host'; if cnt>=3 then return 'too_many'; end if;
 end if;
 insert into orders(sitting_id,guest_id,status) values(sid,g,case when rm then 'awaiting_host' else 'sent' end) returning id into new_id;
 begin
  for x in select * from jsonb_array_elements(lines) loop
   it:=(x->>'item_id')::int; q:=(x->>'qty')::int; pr:=(x->>'price')::int;
   if x ? 'togo' then if jsonb_typeof(x->'togo')<>'boolean' then raise exception 'bad'; end if; tg:=(x->>'togo')::boolean; else tg:=false; end if;
   if rm then tg:=true; end if;
   if q is null or q<1 or q>20 or pr is null or pr<=0 then raise exception 'bad'; end if;
   nm:=null;
   select m.name||case when coalesce(m.variant,'')<>'' then ' ('||m.variant||')' else '' end into nm
    from menu_items m
    where m.id=it and not coalesce(m.hidden,false) and not coalesce(m.sold_out,false)
      and exists(select 1 from regexp_matches(replace(coalesce(m.price,''),',',''),'\d+','g') r where r[1]::int=pr);
   if nm is null then raise exception 'bad'; end if;
   insert into order_lines(order_id,item_id,name,price,qty,togo) values(new_id,it,nm,pr,q,tg);
  end loop;
 exception when others then
  delete from orders where id=new_id;
  return 'bad_line';
 end;
 return 'ok';
end $$;

-- ===== GUEST: the v9.13 separate To go order, now refused for link guests (their orders go to the host) =====
create or replace function guest_send_togo(gt uuid, lines jsonb)
returns jsonb language plpgsql security definer set search_path=public as $$
declare g int; s sittings%rowtype; x jsonb; it int; q int; pr int; nm text; c text; sid int; gid int; oid int; k int:=0; cnt int;
begin
 g:=g_of(gt); if g is null then return jsonb_build_object('r','not_connected'); end if;
 if exists(select 1 from sitting_guests where id=g and remote) then return jsonb_build_object('r','remote'); end if;
 if lines is null or jsonb_typeof(lines)<>'array' or jsonb_array_length(lines)=0 then return jsonb_build_object('r','empty'); end if;
 if jsonb_array_length(lines)>30 then return jsonb_build_object('r','bad_line'); end if;
 select t.* into s from sittings t join sitting_guests m on m.sitting_id=t.id where m.id=g;
 if s.status<>'open' then return jsonb_build_object('r','not_connected'); end if;
 select count(*) into cnt from sittings where from_sitting=s.id and status='open'; if cnt>=10 then return jsonb_build_object('r','too_many'); end if;
 begin
  loop
   c:=lpad((floor(random()*10000))::int::text,4,'0');
   begin
    insert into sittings(waiter_id,waiter_name,table_label,code,kind,from_sitting)
     values(s.waiter_id,s.waiter_name,'Take away '||c,c,'takeaway',s.id) returning id into sid;
    exit;
   exception when unique_violation then
    k:=k+1; if k>25 then return jsonb_build_object('r','try_again'); end if;
   end;
  end loop;
  insert into sitting_guests(sitting_id,num,is_master) values(sid,1,true) returning id into gid;
  insert into orders(sitting_id,guest_id) values(sid,gid) returning id into oid;
  for x in select * from jsonb_array_elements(lines) loop
   it:=(x->>'item_id')::int; q:=(x->>'qty')::int; pr:=(x->>'price')::int;
   if q is null or q<1 or q>20 or pr is null or pr<=0 then raise exception 'bad'; end if;
   nm:=null;
   select m.name||case when coalesce(m.variant,'')<>'' then ' ('||m.variant||')' else '' end into nm
    from menu_items m
    where m.id=it and not coalesce(m.hidden,false) and not coalesce(m.sold_out,false)
      and exists(select 1 from regexp_matches(replace(coalesce(m.price,''),',',''),'\d+','g') r where r[1]::int=pr);
   if nm is null then raise exception 'bad'; end if;
   insert into order_lines(order_id,item_id,name,price,qty,togo) values(oid,it,nm,pr,q,true);
  end loop;
 exception when others then
  if sid is not null then delete from sittings where id=sid; end if;
  return jsonb_build_object('r','bad_line');
 end;
 return jsonb_build_object('r','ok','code',c);
end $$;

-- ===== GUEST: status. join_key = this phone's own one-time QR key (made here when it has none). =====
create or replace function guest_status(gt uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype; s sittings%rowtype; qk text; can bool;
begin
 select * into g from sitting_guests where token=gt;
 if not found then return jsonb_build_object('connected',false); end if;
 if g.removed then return jsonb_build_object('connected',false,'removed',true); end if;
 select * into s from sittings where id=g.sitting_id;
 can := s.status='open' and not g.remote and (g.is_master or s.share_qr);
 if can then
  select k into qk from join_keys where made_by=g.id and kind='qr' and used_at is null order by made_at desc limit 1;
  if qk is null then
   qk:=new_key();
   insert into join_keys(k,sitting_id,made_by,kind) values(qk,s.id,g.id,'qr');
  end if;
 end if;
 return jsonb_build_object('connected',s.status='open','closed',s.status='closed','num',g.num,'table',s.table_label,'kind',s.kind,'pay',g.pay,
  'master',g.is_master,'share',s.share_qr,'remote',g.remote,'link_ok',can,'join_key',qk,
  'guests',case when g.is_master then (select coalesce(jsonb_agg(jsonb_build_object('num',x.num,'remote',x.remote) order by x.num),'[]'::jsonb)
      from sitting_guests x where x.sitting_id=s.id and not x.removed and x.id<>g.id) end,
  'total',(select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id join sitting_guests og on og.id=o.guest_id
      where o.status not in ('awaiting_host','declined')
        and (o.guest_id=g.id or (og.remote and not g.remote and (og.via=g.id
             or (g.is_master and not exists(select 1 from sitting_guests v where v.id=og.via and not v.removed)))))),
  'orders',(select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'pickup',o.pickup,'lines',
      (select coalesce(jsonb_agg(jsonb_build_object('id',l.id,'name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote,'togo',l.togo) order by l.id),'[]'::jsonb)
       from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb) from orders o where o.guest_id=g.id),
  'link_orders',case when g.remote then '[]'::jsonb else
     (select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'pickup',o.pickup,'guest',r.num,'lines',
       (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price) order by l.id),'[]'::jsonb)
        from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb)
      from orders o join sitting_guests r on r.id=o.guest_id
      where o.sitting_id=s.id and r.remote and o.status<>'declined'
        and (r.via=g.id or (g.is_master and not exists(select 1 from sitting_guests v where v.id=r.via and not v.removed)))) end);
end $$;

-- ===== GUEST: host's Hold / Let. Hold stops every unused QR and link of the table at once. =====
create or replace function guest_set_share(gt uuid, v bool)
returns text language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype;
begin
 if g_of(gt) is null then return 'not_connected'; end if;
 select * into g from sitting_guests where token=gt;
 if not g.is_master then return 'not_master'; end if;
 if coalesce(v,false) then
  update sittings set share_qr=true where id=g.sitting_id;
 else
  update sittings set share_qr=false, join_key=new_key() where id=g.sitting_id;
  delete from join_keys where sitting_id=g.sitting_id and used_at is null;
 end if;
 return 'ok';
end $$;

-- ===== GUEST: host removes another guest; that guest's unused QR and links stop at once (L14) =====
create or replace function guest_remove(gt uuid, gnum int)
returns text language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype; n int;
begin
 if g_of(gt) is null then return 'not_connected'; end if;
 select * into g from sitting_guests where token=gt;
 if not g.is_master then return 'not_master'; end if;
 if gnum=g.num then return 'self'; end if;
 update sitting_guests set removed=true where sitting_id=g.sitting_id and num=gnum and not removed and not is_master;
 get diagnostics n=row_count;
 delete from join_keys where used_at is null and made_by in (select id from sitting_guests where sitting_id=g.sitting_id and num=gnum);
 return case when n=1 then 'ok' else 'not_found' end;
end $$;

-- ===== WAITER: remove a guest (same key rule) =====
create or replace function waiter_remove_guest(tok uuid, sid int, gnum int)
returns text language plpgsql security definer set search_path=public as $$
declare w int; g sitting_guests%rowtype;
begin
 w:=w_of(tok); if w is null then return 'no_login'; end if;
 if not exists(select 1 from sittings where id=sid and waiter_id=w and status='open') then return 'not_found'; end if;
 select * into g from sitting_guests where sitting_id=sid and num=gnum and not removed;
 if not found then return 'not_found'; end if;
 if g.is_master then return 'is_master'; end if;
 update sitting_guests set removed=true where id=g.id;
 delete from join_keys where made_by=g.id and used_at is null;
 return 'ok';
end $$;

-- ===== WAITER: new host code; every unused QR and link of the table stops =====
create or replace function waiter_new_master(tok uuid, sid int)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; c text; k int := 0;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 if not exists(select 1 from sittings where id=sid and waiter_id=w and status='open') then return jsonb_build_object('r','not_found'); end if;
 update sitting_guests set removed=true where sitting_id=sid and is_master and not removed;
 delete from join_keys where sitting_id=sid and used_at is null;
 loop
  c:=lpad((floor(random()*10000))::int::text,4,'0');
  begin
   update sittings set code=c, share_qr=false, join_key=new_key() where id=sid;
   return jsonb_build_object('r','ok','code',c);
  exception when unique_violation then
   k:=k+1; if k>25 then return jsonb_build_object('r','try_again'); end if;
  end;
 end loop;
end $$;

-- ===== WAITER: move an order a step. Never an order still waiting for its host, or declined. =====
create or replace function waiter_order_step(tok uuid, ord_id int, st text)
returns text language plpgsql security definer set search_path=public as $$
declare w int; n int;
begin
 w:=w_of(tok); if w is null then return 'no_login'; end if;
 if st not in ('received','preparing','on_the_way','served') then return 'bad_step'; end if;
 update orders o set status=st, updated_at=now()
  from sittings s where o.id=ord_id and s.id=o.sitting_id and s.waiter_id=w and s.status='open'
   and o.status not in ('awaiting_host','declined');
 get diagnostics n=row_count;
 if n=0 then return 'not_found'; end if;
 return 'ok';
end $$;

-- ===== WAITER: tables. Link guests are marked (remote, via = the guest number whose link it was); orders waiting for
-- their host or declined are not shown and not counted; an approved link order carries its pickup code =====
create or replace function waiter_tables(tok uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; r jsonb;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 select coalesce(jsonb_agg(to_jsonb(t) order by t.opened_at),'[]'::jsonb) into r from (
  select s.id, s.table_label, s.kind, s.code, s.opened_at,
   exists(select 1 from sitting_guests m where m.sitting_id=s.id and m.is_master and not m.removed) as paired,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id
     where o.sitting_id=s.id and o.status not in ('awaiting_host','declined')) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('num',g.num,'pay',g.pay,'master',g.is_master,'removed',g.removed,'remote',g.remote,
       'via',(select v.num from sitting_guests v where v.id=g.via),'orders',
      (select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'at',o.created_at,'pickup',o.pickup,'lines',
         (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote,'togo',l.togo) order by l.id),'[]'::jsonb)
          from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb)
       from orders o where o.guest_id=g.id and o.status not in ('awaiting_host','declined'))) order by g.num),'[]'::jsonb)
    from sitting_guests g where g.sitting_id=s.id) as guests
  from sittings s where s.waiter_id=w and s.status='open') t;
 return jsonb_build_object('r','ok','tables',r);
end $$;

-- ===== ADMIN: closed tables leave out orders that waited for a host or were declined =====
create or replace function admin_closed_tables(n int default 50)
returns jsonb language plpgsql security definer set search_path=public as $$
begin
 if not is_staff() then return '[]'::jsonb; end if;
 return (select coalesce(jsonb_agg(to_jsonb(t) order by t.closed_at desc),'[]'::jsonb) from (
  select s.id, s.table_label, s.kind, s.waiter_name, s.opened_at, s.closed_at,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id
     where o.sitting_id=s.id and o.status not in ('awaiting_host','declined')) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote,'togo',l.togo) order by l.id),'[]'::jsonb)
      from order_lines l join orders o on o.id=l.order_id
      where o.sitting_id=s.id and o.status not in ('awaiting_host','declined')) as lines
  from sittings s where s.status='closed' order by s.closed_at desc limit least(coalesce(n,50),200)) t);
end $$;

-- ===== who may call what =====
revoke all on function guest_pair(text,text), guest_join_key(text,text), guest_link(uuid), guest_host_decide(uuid,int,bool),
  guest_send_order(uuid,jsonb), guest_send_togo(uuid,jsonb), guest_status(uuid), guest_set_share(uuid,bool), guest_remove(uuid,int),
  waiter_remove_guest(uuid,int,int), waiter_new_master(uuid,int), waiter_order_step(uuid,int,text), waiter_tables(uuid),
  admin_closed_tables(int) from public;
grant execute on function guest_pair(text,text), guest_join_key(text,text), guest_link(uuid), guest_host_decide(uuid,int,bool),
  guest_send_order(uuid,jsonb), guest_send_togo(uuid,jsonb), guest_status(uuid), guest_set_share(uuid,bool), guest_remove(uuid,int),
  waiter_remove_guest(uuid,int,int), waiter_new_master(uuid,int), waiter_order_step(uuid,int,text), waiter_tables(uuid)
  to anon, authenticated;
grant execute on function admin_closed_tables(int) to authenticated;

-- PostgREST: reload so the new function signatures are seen at once
notify pgrst, 'reload schema';
