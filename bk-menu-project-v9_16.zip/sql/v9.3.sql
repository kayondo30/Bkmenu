-- BK menu v9.3 part H1 of 4 (HOST PHONE + ORDERING QR). DATABASE ONLY. Optional feature.
-- Run once in Supabase > SQL Editor (new query tab). Safe to run again. "Success. No rows returned" is normal.
-- Needs v7.0, v7.5, v7.7 and v9.0 run first. Nothing in your menu, prices, orders or closed tables is changed or deleted.
-- Check:  select proname from pg_proc where proname in ('guest_pair','guest_join_key','guest_remove','waiter_new_master','waiter_remove_guest');  -> 5 rows
-- Undo = sql/v9.3-undo.sql.
--
-- HOW IT WORKS
-- The waiter makes the 4-digit code as today. The FIRST guest types it (guest_pair) and becomes the MASTER phone.
-- The code then works ONCE: a second guest typing it is told code_used. The master phone shows the ORDERING QR (it carries join_key).
-- Other guests scan that QR (guest_join_key) and join the same table, up to 5 phones in all, each with his own list.
-- The venue's menu QR on the tables is untouched: it only opens the menu, no code, no ordering.
-- If the master leaves or the phone dies, the waiter calls waiter_new_master: the old master is removed, a FRESH code and a fresh
-- join_key are made (the old QR stops working) and the next guest who types the code is the new master. Other guests stay.
-- Remove a guest: the master (guest_remove) or the waiter (waiter_remove_guest). A removed guest's orders stay on the table.
-- The old guest_join(code) (v9.2 site, up to 5 phones on one code) still works until the site of part H3 replaces it, but it
-- refuses a table that already has a master, so the code can not be used to bypass the QR.
-- Replies are listed above each function. Guests still see no totals in the app.

alter table sitting_guests add column if not exists is_master bool not null default false;
alter table sitting_guests add column if not exists removed bool not null default false;
alter table sittings add column if not exists join_key text default substr(replace(gen_random_uuid()::text,'-',''),1,12);
update sittings set join_key=substr(replace(gen_random_uuid()::text,'-',''),1,12) where join_key is null and status='open';
create unique index if not exists sittings_open_join_key on sittings(join_key) where status='open';
-- only ONE active master per table (also stops two phones pairing at the same moment)
create unique index if not exists guests_one_master on sitting_guests(sitting_id) where is_master and not removed;
-- guest numbers may now go above 5 because removed guests keep their number; the cap of 5 counts ACTIVE guests only
alter table sitting_guests drop constraint if exists sitting_guests_num_check;
alter table sitting_guests add constraint sitting_guests_num_check check (num between 1 and 99);

-- a removed guest's key stops working at once
create or replace function g_of(tok uuid) returns int language sql security definer stable set search_path=public as $$
 select g.id from sitting_guests g join sittings s on s.id=g.sitting_id where g.token=tok and s.status='open' and not g.removed $$;
revoke all on function g_of(uuid) from public, anon, authenticated;

-- ===== GUEST =====
-- First guest types the waiter's code and becomes the master phone.
-- Replies {"r":"ok","gtoken":"..","num":1,"table":"..","kind":"..","master":true,"join_key":".."} or {"r":"bad_code"|"code_used"|"slow_down"}.
create or replace function guest_pair(cd text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare s sittings%rowtype; g sitting_guests%rowtype; k int; c text := regexp_replace(coalesce(cd,''),'\D','','g');
begin
 delete from join_tries where at<now()-interval '10 minutes';
 select count(*) into k from join_tries where at>now()-interval '1 minute';
 if k>=30 then return jsonb_build_object('r','slow_down'); end if;
 select * into s from sittings where code=c and status='open';
 if not found then insert into join_tries default values; return jsonb_build_object('r','bad_code'); end if;
 if exists(select 1 from sitting_guests where sitting_id=s.id and is_master and not removed) then
  insert into join_tries default values; return jsonb_build_object('r','code_used');
 end if;
 select coalesce(max(num),0)+1 into k from sitting_guests where sitting_id=s.id;
 insert into sitting_guests(sitting_id,num,is_master) values(s.id,k,true) returning * into g;
 return jsonb_build_object('r','ok','gtoken',g.token,'num',g.num,'table',s.table_label,'kind',s.kind,'master',true,'join_key',s.join_key);
exception when unique_violation then
 return jsonb_build_object('r','code_used');
end $$;

-- Other guests scan the master's ordering QR. Replies {"r":"ok","gtoken":"..","num":2,"table":"..","kind":"..","master":false}
-- or {"r":"bad_key"|"full"|"slow_down"}. A table with no master yet can not be joined this way.
create or replace function guest_join_key(jk text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare s sittings%rowtype; g sitting_guests%rowtype; k int; n int; j text := lower(regexp_replace(coalesce(jk,''),'[^0-9a-fA-F]','','g'));
begin
 delete from join_tries where at<now()-interval '10 minutes';
 select count(*) into k from join_tries where at>now()-interval '1 minute';
 if k>=30 then return jsonb_build_object('r','slow_down'); end if;
 select * into s from sittings where join_key=j and status='open'
   and exists(select 1 from sitting_guests m where m.sitting_id=sittings.id and m.is_master and not m.removed);
 if not found then insert into join_tries default values; return jsonb_build_object('r','bad_key'); end if;
 select count(*) into k from sitting_guests where sitting_id=s.id and not removed;
 select coalesce(max(num),0) into n from sitting_guests where sitting_id=s.id;
 if k>=5 or n>=99 then return jsonb_build_object('r','full'); end if;
 insert into sitting_guests(sitting_id,num) values(s.id,n+1) returning * into g;
 return jsonb_build_object('r','ok','gtoken',g.token,'num',g.num,'table',s.table_label,'kind',s.kind,'master',false);
exception when unique_violation then
 return jsonb_build_object('r','slow_down');
end $$;

-- Old way (v9.2 site): type the code to join, up to 5 phones. Refuses a table that has a master (use the ordering QR instead).
create or replace function guest_join(cd text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare s sittings%rowtype; g sitting_guests%rowtype; k int; n int; c text := regexp_replace(coalesce(cd,''),'\D','','g');
begin
 delete from join_tries where at<now()-interval '10 minutes';
 select count(*) into k from join_tries where at>now()-interval '1 minute';
 if k>=30 then return jsonb_build_object('r','slow_down'); end if;
 select * into s from sittings where code=c and status='open';
 if not found then insert into join_tries default values; return jsonb_build_object('r','bad_code'); end if;
 if exists(select 1 from sitting_guests where sitting_id=s.id and is_master and not removed) then
  insert into join_tries default values; return jsonb_build_object('r','code_used');
 end if;
 select count(*) into k from sitting_guests where sitting_id=s.id and not removed;
 select coalesce(max(num),0) into n from sitting_guests where sitting_id=s.id;
 if k>=5 or n>=99 then return jsonb_build_object('r','full'); end if;
 insert into sitting_guests(sitting_id,num) values(s.id,n+1) returning * into g;
 return jsonb_build_object('r','ok','gtoken',g.token,'num',g.num,'table',s.table_label,'kind',s.kind);
exception when unique_violation then
 return jsonb_build_object('r','slow_down');
end $$;

-- The master removes ANOTHER guest by his number. Replies ok | not_connected | not_master | self | not_found
create or replace function guest_remove(gt uuid, gnum int)
returns text language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype; n int;
begin
 if g_of(gt) is null then return 'not_connected'; end if;
 select * into g from sitting_guests where token=gt;
 if not g.is_master then return 'not_master'; end if;
 if gnum=g.num then return 'self'; end if;
 update sitting_guests set removed=true where sitting_id=g.sitting_id and num=gnum and not removed and not is_master;
 get diagnostics n=row_count;
 return case when n=1 then 'ok' else 'not_found' end;
end $$;

-- The guest's own screen (v9.0 version plus: removed, master, and for the MASTER only the ordering QR key and the other guests).
create or replace function guest_status(gt uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype; s sittings%rowtype;
begin
 select * into g from sitting_guests where token=gt;
 if not found then return jsonb_build_object('connected',false); end if;
 if g.removed then return jsonb_build_object('connected',false,'removed',true); end if;
 select * into s from sittings where id=g.sitting_id;
 return jsonb_build_object('connected',s.status='open','closed',s.status='closed','num',g.num,'table',s.table_label,'kind',s.kind,'pay',g.pay,
  'master',g.is_master,
  'join_key',case when g.is_master and s.status='open' then s.join_key end,
  'guests',case when g.is_master then (select coalesce(jsonb_agg(jsonb_build_object('num',x.num) order by x.num),'[]'::jsonb)
      from sitting_guests x where x.sitting_id=s.id and not x.removed and x.id<>g.id) end,
  'total',(select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.guest_id=g.id),
  'orders',(select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'lines',
      (select coalesce(jsonb_agg(jsonb_build_object('id',l.id,'name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote) order by l.id),'[]'::jsonb)
       from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb) from orders o where o.guest_id=g.id));
end $$;

-- ===== WAITER =====
-- New master phone: the old master is removed, a fresh code and a fresh ordering-QR key are made (the old QR stops working),
-- the other guests stay. Replies {"r":"ok","code":".."} | {"r":"no_login"|"not_found"|"try_again"}
create or replace function waiter_new_master(tok uuid, sid int)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; c text; k int := 0;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 if not exists(select 1 from sittings where id=sid and waiter_id=w and status='open') then return jsonb_build_object('r','not_found'); end if;
 update sitting_guests set removed=true where sitting_id=sid and is_master and not removed;
 loop
  c:=lpad((floor(random()*10000))::int::text,4,'0');
  begin
   update sittings set code=c, join_key=substr(replace(gen_random_uuid()::text,'-',''),1,12) where id=sid;
   return jsonb_build_object('r','ok','code',c);
  exception when unique_violation then
   k:=k+1; if k>25 then return jsonb_build_object('r','try_again'); end if;
  end;
 end loop;
end $$;

-- The waiter removes a guest (not the master: use waiter_new_master for that). Replies ok | no_login | not_found | is_master
create or replace function waiter_remove_guest(tok uuid, sid int, gnum int)
returns text language plpgsql security definer set search_path=public as $$
declare w int; g sitting_guests%rowtype;
begin
 w:=w_of(tok); if w is null then return 'no_login'; end if;
 if not exists(select 1 from sittings where id=sid and waiter_id=w and status='open') then return 'not_found'; end if;
 select * into g from sitting_guests where sitting_id=sid and num=gnum and not removed;
 if not found then return 'not_found'; end if;
 if g.is_master then return 'is_master'; end if;
 update sitting_guests set removed=true where id=g.id;
 return 'ok';
end $$;

-- The waiter's tables (v9.0 version plus: paired, and per guest master and removed).
create or replace function waiter_tables(tok uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; r jsonb;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 select coalesce(jsonb_agg(to_jsonb(t) order by t.opened_at),'[]'::jsonb) into r from (
  select s.id, s.table_label, s.kind, s.code, s.opened_at,
   exists(select 1 from sitting_guests m where m.sitting_id=s.id and m.is_master and not m.removed) as paired,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('num',g.num,'pay',g.pay,'master',g.is_master,'removed',g.removed,'orders',
      (select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'at',o.created_at,'lines',
         (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote) order by l.id),'[]'::jsonb)
          from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb)
       from orders o where o.guest_id=g.id)) order by g.num),'[]'::jsonb)
    from sitting_guests g where g.sitting_id=s.id) as guests
  from sittings s where s.waiter_id=w and s.status='open') t;
 return jsonb_build_object('r','ok','tables',r);
end $$;

revoke all on function guest_pair(text), guest_join_key(text), guest_join(text), guest_remove(uuid,int), guest_status(uuid),
  waiter_new_master(uuid,int), waiter_remove_guest(uuid,int,int), waiter_tables(uuid) from public;
grant execute on function guest_pair(text), guest_join_key(text), guest_join(text), guest_remove(uuid,int), guest_status(uuid),
  waiter_new_master(uuid,int), waiter_remove_guest(uuid,int,int), waiter_tables(uuid) to anon, authenticated;
