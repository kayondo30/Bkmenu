-- Undo BK menu v9.16: closing a table no longer asks for the PIN (puts back the v7.0 close door).
-- Check: select pg_get_function_identity_arguments(oid) from pg_proc where proname='waiter_close_table';  -> tok uuid, sid integer
drop function if exists waiter_close_table(uuid,int,text);
create or replace function waiter_close_table(tok uuid, sid int)
returns text language plpgsql security definer set search_path=public as $$
declare w int; n int;
begin
 w:=w_of(tok); if w is null then return 'no_login'; end if;
 update sittings set status='closed', closed_at=now() where id=sid and waiter_id=w and status='open';
 get diagnostics n=row_count;
 if n=0 then return 'not_found'; end if;
 return 'ok';
end $$;
revoke all on function waiter_close_table(uuid,int) from public;
grant execute on function waiter_close_table(uuid,int) to anon, authenticated;
notify pgrst, 'reload schema';
