-- BK menu v9.16: CLOSING A TABLE ASKS FOR THE WAITER'S PIN, THEN THE PHONE LOCKS (owner's choice 2026-11-06).
-- Run once in Supabase > SQL Editor, AFTER v9.15.sql. Safe to run again. Undo = sql/v9.16-undo.sql.
-- Check:  select pg_get_function_identity_arguments(oid) from pg_proc where proname='waiter_close_table';  -> 1 row: tok uuid, sid integer, pin text
-- The old close door without a PIN is removed, so nobody can close a table without the PIN, even outside the app.
-- Wrong PIN: "bad_pin", the table stays open. 3 wrong PINs (counted together with wrong logins): the waiter is locked
-- for 15 minutes and every phone logged in as that waiter is logged out, so a stranger holding the phone loses the page.
-- After a table is closed, THAT PHONE IS LOGGED OUT (owner's choice): the next use needs the PIN again (name is remembered).
-- Closing a To go or room card works the same way (they are tables too).
drop function if exists waiter_close_table(uuid,int);
create or replace function waiter_close_table(tok uuid, sid int, pin text)
returns text language plpgsql security definer set search_path=public,extensions as $$
declare w waiters%rowtype; wid int; n int;
begin
 wid:=w_of(tok); if wid is null then return 'no_login'; end if;
 select * into w from waiters where id=wid;
 if w.locked_until>now() then delete from waiter_sessions where waiter_id=w.id; return 'locked'; end if;
 if w.pin_hash<>crypt(coalesce(pin,''),w.pin_hash) then
  update waiters set locked_until=case when tries+1>=3 then now()+interval '15 minutes' end,
         tries=case when tries+1>=3 then 0 else tries+1 end where id=w.id;
  if w.tries+1>=3 then delete from waiter_sessions where waiter_id=w.id; return 'locked'; end if;
  return 'bad_pin';
 end if;
 update waiters set tries=0, locked_until=null where id=w.id;
 update sittings set status='closed', closed_at=now() where id=sid and waiter_id=wid and status='open';
 get diagnostics n=row_count;
 if n=0 then return 'not_found'; end if;
 delete from waiter_sessions where token=tok;
 return 'ok';
end $$;
revoke all on function waiter_close_table(uuid,int,text) from public;
grant execute on function waiter_close_table(uuid,int,text) to anon, authenticated;
notify pgrst, 'reload schema';
