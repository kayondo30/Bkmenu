-- BK menu v9.3.1 (HOLD or LET the ordering QR). DATABASE ONLY. Run once in Supabase > SQL Editor (new query tab). Safe to run again.
-- Needs v9.3.sql run first. Nothing in your menu, prices, orders or closed tables is changed.
-- Check:  select proname from pg_proc where proname='guest_set_share';  -> 1 row
--         select column_name from information_schema.columns where table_name='sittings' and column_name='share_qr';  -> 1 row
-- Undo = sql/v9.3.1-undo.sql.
--
-- HOW IT WORKS
-- HOLD (default): only the master phone gets the ordering QR key. LET: the master taps a switch (guest_set_share) and every joined
-- guest phone also gets the key, so guests can bring in their own friends (still 5 active phones at most).
-- Back to HOLD: the key is changed, so an old QR or a screenshot stops working; guests already in stay in.
-- Removing guests stays with the master and the waiter only. A new master pair (waiter_new_master) also puts the table back to HOLD.
-- Replies of guest_set_share(gtoken, on): ok | not_connected | not_master. guest_status also returns share (true or false).

alter table sittings add column if not exists share_qr bool not null default false;

-- Master only. Turning it OFF makes a fresh key.
create or replace function guest_set_share(gt uuid, v bool)
returns text language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype;
begin
 if g_of(gt) is null then return 'not_connected'; end if;
 select * into g from sitting_guests where token=gt;
 if not g.is_master then return 'not_master'; end if;
 if coalesce(v,false) then
  update sittings set share_qr=true where id=g.sitting_id;
 else
  update sittings set share_qr=false, join_key=substr(replace(gen_random_uuid()::text,'-',''),1,12) where id=g.sitting_id;
 end if;
 return 'ok';
end $$;

-- guest_status: adds share, and gives the key to every guest while share is on
create or replace function guest_status(gt uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype; s sittings%rowtype;
begin
 select * into g from sitting_guests where token=gt;
 if not found then return jsonb_build_object('connected',false); end if;
 if g.removed then return jsonb_build_object('connected',false,'removed',true); end if;
 select * into s from sittings where id=g.sitting_id;
 return jsonb_build_object('connected',s.status='open','closed',s.status='closed','num',g.num,'table',s.table_label,'kind',s.kind,'pay',g.pay,
  'master',g.is_master,'share',s.share_qr,
  'join_key',case when (g.is_master or s.share_qr) and s.status='open' then s.join_key end,
  'guests',case when g.is_master then (select coalesce(jsonb_agg(jsonb_build_object('num',x.num) order by x.num),'[]'::jsonb)
      from sitting_guests x where x.sitting_id=s.id and not x.removed and x.id<>g.id) end,
  'total',(select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.guest_id=g.id),
  'orders',(select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'lines',
      (select coalesce(jsonb_agg(jsonb_build_object('id',l.id,'name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote) order by l.id),'[]'::jsonb)
       from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb) from orders o where o.guest_id=g.id));
end $$;

-- waiter_new_master: also puts the table back to HOLD
create or replace function waiter_new_master(tok uuid, sid int)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; c text; k int := 0;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 if not exists(select 1 from sittings where id=sid and waiter_id=w and status='open') then return jsonb_build_object('r','not_found'); end if;
 update sitting_guests set removed=true where sitting_id=sid and is_master and not removed;
 loop
  c:=lpad((floor(random()*10000))::int::text,4,'0');
  begin
   update sittings set code=c, share_qr=false, join_key=substr(replace(gen_random_uuid()::text,'-',''),1,12) where id=sid;
   return jsonb_build_object('r','ok','code',c);
  exception when unique_violation then
   k:=k+1; if k>25 then return jsonb_build_object('r','try_again'); end if;
  end;
 end loop;
end $$;

revoke all on function guest_set_share(uuid,bool), guest_status(uuid), waiter_new_master(uuid,int) from public;
grant execute on function guest_set_share(uuid,bool), guest_status(uuid), waiter_new_master(uuid,int) to anon, authenticated;
