-- Undo BK menu v9.3: puts back the v7.0 guest_join and g_of and the v9.0 guest_status and waiter_tables, drops the new functions,
-- indexes and columns. Orders, prices and closed tables are untouched. Guests removed by v9.3 are simply gone from the host columns
-- (their orders stay). A table that already has more than 5 numbered guests keeps them; the old limit is put back without checking old rows.
drop function if exists guest_pair(text);
drop function if exists guest_join_key(text);
drop function if exists guest_remove(uuid,int);
drop function if exists waiter_new_master(uuid,int);
drop function if exists waiter_remove_guest(uuid,int,int);
create or replace function g_of(tok uuid) returns int language sql security definer stable set search_path=public as $$
 select g.id from sitting_guests g join sittings s on s.id=g.sitting_id where g.token=tok and s.status='open' $$;
revoke all on function g_of(uuid) from public, anon, authenticated;

create or replace function guest_join(cd text)
returns jsonb language plpgsql security definer set search_path=public as $$
declare s sittings%rowtype; g sitting_guests%rowtype; k int; c text := regexp_replace(coalesce(cd,''),'\D','','g');
begin
 delete from join_tries where at<now()-interval '10 minutes';
 select count(*) into k from join_tries where at>now()-interval '1 minute';
 if k>=30 then return jsonb_build_object('r','slow_down'); end if;
 select * into s from sittings where code=c and status='open';
 if not found then insert into join_tries default values; return jsonb_build_object('r','bad_code'); end if;
 select count(*) into k from sitting_guests where sitting_id=s.id;
 if k>=5 then return jsonb_build_object('r','full'); end if;
 insert into sitting_guests(sitting_id,num) values(s.id,k+1) returning * into g;
 return jsonb_build_object('r','ok','gtoken',g.token,'num',g.num,'table',s.table_label);
exception when unique_violation then
 return jsonb_build_object('r','slow_down');
end $$;

create or replace function guest_status(gt uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare g sitting_guests%rowtype; s sittings%rowtype;
begin
 select * into g from sitting_guests where token=gt;
 if not found then return jsonb_build_object('connected',false); end if;
 select * into s from sittings where id=g.sitting_id;
 return jsonb_build_object('connected',s.status='open','closed',s.status='closed','num',g.num,'table',s.table_label,'kind',s.kind,'pay',g.pay,
  'total',(select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.guest_id=g.id),
  'orders',(select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'lines',
      (select coalesce(jsonb_agg(jsonb_build_object('id',l.id,'name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote) order by l.id),'[]'::jsonb)
       from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb) from orders o where o.guest_id=g.id));
end $$;

create or replace function waiter_tables(tok uuid)
returns jsonb language plpgsql security definer set search_path=public as $$
declare w int; r jsonb;
begin
 w:=w_of(tok); if w is null then return jsonb_build_object('r','no_login'); end if;
 select coalesce(jsonb_agg(to_jsonb(t) order by t.opened_at),'[]'::jsonb) into r from (
  select s.id, s.table_label, s.kind, s.code, s.opened_at,
   (select coalesce(sum(l.price*l.qty),0) from order_lines l join orders o on o.id=l.order_id where o.sitting_id=s.id) as total,
   (select coalesce(jsonb_agg(jsonb_build_object('num',g.num,'pay',g.pay,'orders',
      (select coalesce(jsonb_agg(jsonb_build_object('id',o.id,'status',o.status,'at',o.created_at,'lines',
         (select coalesce(jsonb_agg(jsonb_build_object('name',l.name,'qty',l.qty,'price',l.price,'vote',l.vote) order by l.id),'[]'::jsonb)
          from order_lines l where l.order_id=o.id)) order by o.id),'[]'::jsonb)
       from orders o where o.guest_id=g.id)) order by g.num),'[]'::jsonb)
    from sitting_guests g where g.sitting_id=s.id) as guests
  from sittings s where s.waiter_id=w and s.status='open') t;
 return jsonb_build_object('r','ok','tables',r);
end $$;

revoke all on function guest_join(text), guest_status(uuid), waiter_tables(uuid) from public;
grant execute on function guest_join(text), guest_status(uuid), waiter_tables(uuid) to anon, authenticated;
drop index if exists guests_one_master;
drop index if exists sittings_open_join_key;
alter table sitting_guests drop constraint if exists sitting_guests_num_check;
alter table sitting_guests add constraint sitting_guests_num_check check (num between 1 and 5) not valid;
alter table sitting_guests drop column if exists is_master;
alter table sitting_guests drop column if exists removed;
alter table sittings drop column if exists join_key;
