# Simu Works (v11)
Phone-first menus and apps for Ugandan businesses.

- site/ : the website. Upload ONLY the files inside this folder (zipped at top level) to Cloudflare Pages. Never upload this whole project.
- docs/ : the project prompt (upload it at the start of each new Claude chat).
- database/ : the Supabase .sql files (no secret keys, ever).

Never commit passwords, the Supabase secret key or the service_role key.
