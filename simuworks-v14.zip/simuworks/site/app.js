// ================================================================
// SIMU WORKS - app.js
// Reads config.js and fills the page. You normally never edit this.
// ================================================================
(function () {
  var C = window.SIMU;
  var ugx = function (n) { return "UGX " + Number(n).toLocaleString("en-US"); };
  var esc = function (s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); };
  var get = function (path) { return path.split(".").reduce(function (o, k) { return o && o[k]; }, C); };
  var waLink = function (which) {
    var n = which === "second" ? C.whatsappSecond : C.whatsappMain;
    return "https://wa.me/" + n.link + "?text=" + encodeURIComponent(C.whatsappHello);
  };

  // 1. Simple texts
  document.querySelectorAll("[data-text]").forEach(function (el) {
    var v = get(el.dataset.text); if (v) el.textContent = v;
  });

  // 2. WhatsApp, call and email links
  document.querySelectorAll("[data-wa]").forEach(function (a) {
    a.href = waLink(a.dataset.wa); a.target = "_blank"; a.rel = "noopener";
  });
  document.querySelectorAll("[data-call]").forEach(function (a) {
    var n = a.dataset.call === "second" ? C.whatsappSecond : C.whatsappMain;
    a.href = "tel:+" + n.link;
  });
  document.querySelectorAll("[data-mail]").forEach(function (a) {
    a.href = "mailto:" + C.email + "?subject=" + encodeURIComponent("Enquiry from the website");
  });

  // 3. Benefits
  document.querySelector(".benefits").innerHTML = C.benefits.map(function (b) {
    return '<div class="benefit"><h3>' + esc(b.title) + "</h3><p>" + esc(b.text) + "</p></div>";
  }).join("");

  // 4. Work
  document.querySelector(".work-list").innerHTML = C.work.map(function (w) {
    return '<article class="work"><div><p class="work-type">' + esc(w.type) + "</p><h3>" + esc(w.name) +
      "</h3><p>" + esc(w.text) + '</p></div>' + (w.link
        ? '<a class="btn btn-ghost" href="' + esc(w.link) + '" target="_blank" rel="noopener">' + esc(w.button || "Open it") + '</a>'
        : '<p class="soon">In progress</p>') + '</article>';
  }).join("");

  // 4b. Digital menu product (features, extras, add-ons, coming soon)
  (function () {
    var M = C.menuProduct, box = document.querySelector(".menu-product");
    if (!M || !box) return;
    var list = function (title, items, cls) {
      if (!items || !items.length) return "";
      return '<div class="mp ' + (cls || "") + '"><h3>' + esc(title) + "</h3><ul>" +
        items.map(function (i) { return "<li>" + esc(i) + "</li>"; }).join("") + "</ul></div>";
    };
    box.innerHTML = list("Every menu has", M.included) + list("Extras", M.extras) +
      list("Add-ons for venues that allow staff phones", M.addons, "addon") +
      list("Coming soon", M.soon, "later") + '<p class="mp-note">' + esc(M.note) + "</p>";
  })();

  // 5. Prices (shillings; the Show $ button swaps to about-dollars)
  var FX = (C.usd && C.usd.rate) || 4350, inUsd = false;
  try { inUsd = localStorage.getItem("simu-cur") === "usd"; } catch (e) {}
  var usd = function (n) {
    var d = n / FX; d = d < 100 ? Math.round(d) : Math.round(d / 5) * 5;
    return "about $" + d.toLocaleString("en-US");
  };
  var money = function (n) { return inUsd ? usd(n) : ugx(n); };
  function drawPrices() {
    document.querySelector(".packages").innerHTML = C.packages.map(function (p) {
      return '<article class="pack' + (p.highlight ? " pick" : "") + '">' +
        (p.highlight ? '<p class="pick-tag">Recommended</p>' : "") +
        "<h3>" + esc(p.name) + '</h3><p class="amount">' + money(p.price) + '</p><p class="note">' + esc(p.note) +
        "</p><ul>" + p.items.map(function (i) { return "<li>" + esc(i) + "</li>"; }).join("") + "</ul>" +
        '<a class="btn btn-ghost pack-book" href="#book" data-pkg="' + esc(p.name) + '">Book ' + esc(p.name) + "</a></article>";
    }).join("");
    document.querySelector(".care").innerHTML =
      "<div><h3>" + esc(C.care.name) + "</h3><p>" + esc(C.care.text) + '</p></div><p class="care-price"><b>' +
      money(C.care.price) + "</b> " + esc(C.care.per) + "<br><span>or " + money(C.care.yearly) + " a year</span></p>";
    var b = document.getElementById("cur");
    b.textContent = inUsd ? "Show UGX" : "Show $"; b.setAttribute("aria-pressed", inUsd ? "true" : "false");
    var n = document.getElementById("cur-note");
    if (n) n.hidden = !inUsd;
  }
  drawPrices();
  document.getElementById("cur").addEventListener("click", function () {
    inUsd = !inUsd;
    try { localStorage.setItem("simu-cur", inUsd ? "usd" : "ugx"); } catch (e) {}
    drawPrices();
  });
  if (C.usd && C.usd.live) {
    fetch("https://open.er-api.com/v6/latest/USD").then(function (r) { return r.json(); }).then(function (j) {
      var r = j && j.rates && +j.rates.UGX;
      if (r > 1000 && r < 20000) { FX = r; drawPrices(); }
    }).catch(function () {});
  }

  // 6. Steps
  document.querySelector(".steps").innerHTML = C.steps.map(function (s) {
    return "<li><h3>" + esc(s.title) + "</h3><p>" + esc(s.text) + "</p></li>";
  }).join("");

  // 7. Footer year
  document.getElementById("year").textContent = "© " + new Date().getFullYear() + "  ·  v" + C.version;

  // 8. Light / dark switch (remembers the choice on this phone)
  document.getElementById("theme").addEventListener("click", function () {
    var root = document.documentElement;
    var dark = root.dataset.theme ? root.dataset.theme === "dark" : matchMedia("(prefers-color-scheme: dark)").matches;
    root.dataset.theme = dark ? "light" : "dark";
    try { localStorage.setItem("simu-theme", root.dataset.theme); } catch (e) {}
  });
})();
