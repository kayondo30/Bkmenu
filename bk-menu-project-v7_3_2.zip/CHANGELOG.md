# BK Beverage Menu - change log
Short list, newest first. Full detail for each version is in README.md. "SQL" = a file to run once in Supabase.

| Version | Date | What changed | SQL |
|---|---|---|---|
| v7.3.2 | 2026-11-04 | Guests: Your waiter sheet shows sent orders as one card per order (Order 1, 2...) with a status pill and one line per drink (qty + name). No money totals shown to guests (List total and Total ordered removed). Site files index.html, sw.js. | none |
| v7.3.1 | 2026-11-04 | Guests: Call waiter button, Your table box and the table card removed from the Waiter sheet (calling a waiter by phone made service reluctant). The sheet is now Your waiter: Table ordering + Ways to pay. Site files index.html, sw.js. | none |
| v7.3 | 2026-11-04 | Guest bottom bar: the Admin button is now Staff and asks "Log in as Waiter or Admin" (Waiter opens the waiter page for name + PIN; shown on phones with a staff or waiter login saved; five taps on the brand line open the same chooser on a new waiter phone). After a guest joins a table the Waiter sheet closes by itself. Guests no longer have Leave this table (staff phones only). Site files index.html, sw.js. | none |
| v7.1 (part 7b of 7) | 2026-11-04 | Table ordering: staff add waiters in More > Waiters (name + PIN, pause, new PIN); new waiter.html page (login, table number, 4-digit code, own open tables, close table). Admin acts as a waiter with his own tables. Site now 20 files. | none (uses v7.0.sql) |
| v7.0 (part 7a of 7) | 2026-11-04 | Table ordering, database only: waiters (name + PIN added by admin), seating codes, guest join (up to 5 phones), orders with progress steps, closed tables locked, admin sees closed tables only. No site change. | sql/v7.0.sql |
| v6.6 (part 1 of 4) | 2026-11-03 | Happy hour, database only: tables happy_hours and happy_hour_rules (days, times, % per page or item, or fixed price per item) plus PIN-checked functions to save, pause and delete. The app does not use it yet (parts 2 to 4: staff screen, guest menu, tests). Site files unchanged, cache stays bk-menu-v6.5 | sql/v6.6.sql (undo: v6.6-undo.sql) |
| v6.5 | 2026-11-03 | Guests: new Waiter button in the bottom bar (table number from the QR address ?t=5, or typed; Call waiter opens WhatsApp to the venue if a number is set in config.js, else shows a big table card to show a waiter) and a Ways to pay list (Cash, MTN MoMo, Airtel Money; tap a number to copy). Settings says Version 6.5, cache bk-menu-v6.5 | none |
| v6.4.2 | 2026-11-03 | How-to video updated (126 s, 14 steps): now shows Scan a bottle, Cost, Margin % and Price check; new video file in the site zip, Settings says Version 6.4.2 | none |
| v6.4.1 | 2026-11-03 | Prompt only: Mobile Money simplified to a list of payment methods that a waiter confirms by hand (ships with ordering, no payment provider); fixed stale text (site zip is 19 files, not 11; roadmap item 6 tag) | none |
| v6.4 | 2026-11-03 | More > Price check: items with a cost whose profit is below the page margin, with the suggested price; tap to open and apply (read-only list, needs the v6.2 cost tables) | none |
| v6.3.2 | 2026-11-03 | Prompt only: saved the roadmap of features that sell, with Claude's recommended order first (nothing built) | none |
| v6.3.1 | 2026-11-03 | Prompt only: saved the plan to update the how-to video with the cost, margin and scan features (not done yet) | none |
| v6.3 | 2026-11-03 | Add a drink or food: "Scan a bottle" (photo of the barcode, read on the phone, looked up in Open Food Facts, fills name and size; staff check before saving) | none |
| v6.2 | 2026-11-03 | Cost + margin price suggestions: staff-only Cost per item (Add a drink and the tap-a-drink sheet), a cost chip in FRONT of the usual price chips, Profit line, Margin % in More (one default, optional per page) | v6.2.sql (run once) |
| v6.1.2 | 2026-11-03 | Prompt only: decided that the current price chips stay and the cost chip is added in front | none |
| v6.1.1 | 2026-11-03 | Prompt only: cost + margin price suggestions saved as PLANNED (not built, waiting for my answers) | none |
| v6.1 | 2026-11-03 | Staff how-to video updated to the current features (97 s, 11 steps) and built into the staff screen: More > Watch the how-to video | none |
| v6.0 | 2026-11-03 | Hiding an item needs a REASON; the reason, who and when show in Who changed what (HIDDEN / shown again) | v6.0.sql (run once) |
| v5.9 | 2026-11-03 | Item name now at the top of the tap-a-drink sheet and saved with the main Save; price hint reworded | none |
| v5.8 | 2026-11-03 | Staff page, More: "Who changed what" = who (login name), what and when, newest first, See all 100 | v5.8.sql (read-only, run once) |
| v5.7.1 | 2026-11-03 | This change log added (project zip only, site files unchanged) | none |
| v5.7 | 2026-11-03 | Price suggestion chips in Add a drink or food (closest relative, most used prices in the section) | none |
| v5.6 | 2026-11-03 | Add drink OR food with automatic page/section; shake to celebrate; Admin test (23 checks); staff how-to video. Confirmed live on my phone | none |
| v5.5 | 2026-11-01 | Richer special card; ONE config.js per client (template); NEW-CLIENT.md | none |
| v5.4 | 2026-11-01 | Staff messages visible over sheets; login renewed on save. Confirmed deployed | none |
| v5.3 | 2026-11-01 | Specials follow the language switch; Suggest Tigrinya button (machine translation, to be checked) | none |
| v5.2 | 2026-11-01 | Celebrations by the Eritrean and Gregorian calendar; featured carousel; deco.js | none |
| v5.1 | 2026-11-01 | Simple staff page (4 tabs); add drinks in the app; prices written 4,000/= | v5.1.sql (run 2026-11-01) |
| v5.0 | 2026-11-01 | Whole menu and staff screen remade to the FHG Calm standard | none |
| v4.1 | 2026-10-29 | USD/UGX switch | none |
| v4.0 | 2026-10-29 | Leading icons on chips and rows | none |
| v3.9 | 2026-10-29 | Hotel-style menu reorganisation (9 pages) | v3.9.sql (optional, not run; undo file exists) |
| v3.8 | 2026-10-29 | Bottom toolbar, calm look | none |
| v3.7 | 2026-10-29 | Follows phone light/dark; logo header; cover photo removed | none |
| v3.6 | 2026-10-26 | Decoration, photo carousel and photo slots | none |
| v3.5 | 2026-10-26 | Today tiles, staff list, scheduled specials, seasons | v3.5.sql (run 2026-10-26) |
| v3.4 | 2026-10-26 | Customer vs staff detection | none |
| v3.3 | 2026-10-26 | PIN-only lock screen | none |
| v3.2 | 2026-10-26 | Staff view on the same address | none |
| v3.1 | 2026-10-26 | Logout, signed-in bar | v3.1.sql (run 2026-10-26) |
| v3 | 2026-10-25 | Specials and share | v3.sql (run) |
| v2.2 | 2026-10-25 | Config file | none |
| v2.1 | 2026-10-25 | Key fix | none |
| v2 | 2026-10-25 | Staff control (login, prices, Sold out, Hold, PIN, banner) | v2.sql (run) |
| v1.1 | 2026-10-25 | Logo | none |
| v1 | 2026-10-25 | First menu | none |

RULE: add a line here at every version (together with README.md and the prompt).

## v6.5.1 (2026-11-04)
- config.js waiter.whatsapp set; cache bk-menu-v6.5.1.
- Prompt only: saved owner design for ordering (4-digit table code, two-tap order, waiter confirms by mouth, My orders with total, thumbs up/down with nudge, admin quality view) as line 13; state as line 14.

v7.2 (2026-11-04) Part 7c: guest joins with the waiter's 4-digit code, two-tap ordering (tap drink, tap Add), My list, Send to my waiter, order progress, pay choice sent to waiter; Admin button on the bottom bar for staff phones only. Files: index.html, sw.js (cache bk-menu-v7.2). No new SQL. tools/test_guest.js added.
